package kankan.wheel;

public final class R {
	public static final class drawable {
		public static final int wheel_bg = 2130837591;
		public static final int wheel_val = 2130837592;
	}
}
