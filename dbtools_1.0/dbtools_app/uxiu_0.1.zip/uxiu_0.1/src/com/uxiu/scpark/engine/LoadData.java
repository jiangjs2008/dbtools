package com.uxiu.scpark.engine;

import android.util.Log;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class LoadData {
	public BufferedReader bufread;
	private File filename = null;
	private StringBuilder readStr = new StringBuilder();

	public Track GetTrack(String paramString) {
		this.filename = new File(paramString);
		String str = readTxtFile();
		if (str != null)
			return new Track(str);
		return null;
	}

	public String readTxtFile() {
		if (!filename.exists()) {
			return null;
		}
//		try {
//			Runtime.getRuntime().exec("chmod 777 " + this.filename.toString());
//		} catch (IOException localIOException2) {
//			localIOException2.printStackTrace();
//		}
		try {
			this.bufread = new BufferedReader(new FileReader(this.filename));

			while (true) {
				String str = this.bufread.readLine();
				if (str == null) {

					return this.readStr.toString().replace("\r\n", "");
				}
				this.readStr.append(str);
			}
		} catch (Exception localFileNotFoundException) {
			localFileNotFoundException.printStackTrace();
		}
		return null;
	}
}
