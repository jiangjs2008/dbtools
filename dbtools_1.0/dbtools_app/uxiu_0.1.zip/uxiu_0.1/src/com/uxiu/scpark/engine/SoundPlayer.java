package com.uxiu.scpark.engine;


import java.util.Random;

import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.media.SoundPool.OnLoadCompleteListener;
import android.util.Log;
import android.util.SparseIntArray;

import com.uxiu.activity.R;

/**
 * ����������
 * @author wyf
 *
 */
public class SoundPlayer {

	private static SoundPool soundPool;

	private static Context context;
	
	private static final int[] musicId = { R.raw.a0_a, R.raw.a1a, R.raw.a2_f, R.raw.a3_g };
	private static SparseIntArray soundMap; //��Ч��Դid����ع������Դid��ӳ���ϵ��
	
	/**
	 * ��ʼ������
	 * @param c
	 */
	public static void init(Context c)
	{
		context = c;
		
		soundPool = new SoundPool(10, AudioManager.STREAM_SYSTEM, 100);
		soundMap = new SparseIntArray();
		soundMap.put(R.raw.a0_a, soundPool.load(context, R.raw.a0_a, 1));
		soundMap.put(R.raw.a1a, soundPool.load(context, R.raw.a1a, 1));
		soundMap.put(R.raw.a2_f, soundPool.load(context, R.raw.a2_f, 1));
		soundMap.put(R.raw.a3_g, soundPool.load(context, R.raw.a3_g, 1));
		
	     soundPool.setOnLoadCompleteListener(new OnLoadCompleteListener() {
             
	           public void onLoadComplete(SoundPool soundPool, int sampleId, int status) {
	                    // TODO Auto-generated method stub
	        	   SoundPlayer.boom();
	              }
	     });
	}
	
	/**
	 * ������Ч
	 * @param resId ��Ч��Դid
	 */
	public static void playSound(int resId)
	{
		Integer soundId = soundMap.get(resId);
		Log.i("playSound", "@" + soundId);
		if (soundId != null)
			soundPool.play(soundId, 1, 1, 1, 0, 1);
	}

	/**
	 * �������������
	 */
	public static void boom()
	{
		playSound(R.raw.a0_a);
//		playSound(R.raw.a1a);
//		playSound(R.raw.a2_f);
//		playSound(R.raw.a3_g);
	}
}
