package com.uxiu.scpark.engine;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.uxiu.activity.MusicActivity;

public class Track {

	private static Logger logger = new Logger(Track.class);

  public static Track me;
  private static Xiaojie xiaojie = null;
  List<Note> LAnotes = new ArrayList();
  List<Note> LBnotes = new ArrayList();
  List<Note> RAnotes = new ArrayList();
  List<Note> RBnotes = new ArrayList();
  private String aDAuthor = "";
  private String author = "";
  private String contentString = "";
  private String des = "";
  private int jiepai = 60;
  private int jiepaiTime = 1000;
  public int mLAnownoteindex = 0;
  public int mLBnownoteindex = 0;
  public int mRAnownoteindex = 0;
  public int mRBnownoteindex = 0;
  private Note[] notes;
  List<String> phtoList = new ArrayList();
  private int phythm = 4;
  private int rowslength = 0;
  private String title = "";
  private int xiaoJieNum = 1;
  public int xiaojieIndex = 1;

  public Track(String paramString)
  {
	  logger.debug("create Track start");
    String[] arrayOfString1 = paramString.split("\\|");
    String[] arrayOfString2 = arrayOfString1[0].split(";");
    int i = arrayOfString2.length;
    int j = 0;

        this.title = arrayOfString2[0].replace("TITLAE=", "");
          this.author = arrayOfString2[1].replace("AUTHORA=", "");
          this.phythm = Integer.valueOf(arrayOfString2[2].replace("RHYTHM=", "").split("/")[0]).intValue();
          this.jiepai = Integer.valueOf(arrayOfString2[3].replace("JIEPAI=", "")).intValue();
          this.xiaoJieNum = Integer.valueOf(arrayOfString2[4].replace("MAXSECTION=", "")).intValue();
          this.aDAuthor = arrayOfString2[5].replace("ADAPTOR=", "");
          this.des = arrayOfString2[6].replace("DES=", "");

    String[] arrayOfString3 = arrayOfString1[1].split(";");
    this.rowslength = arrayOfString3.length;
    this.notes = new Note[this.rowslength];

//    int k = 0;
//    if (k >= this.rowslength)
//    {
//      this.phtoList.remove("");
      me = this;
//    }
    Note localNote = new Note();
    for (int k = 0; i < this.rowslength; k ++) {
    	if (k == rowslength) {
    		logger.debug("k == rowslength");
    		break;
    	}
        this.notes[k] = new Note(arrayOfString3[k], localNote);
        localNote = this.notes[k];

        if (!this.phtoList.contains(this.notes[k].getImage()))
          this.phtoList.add(this.notes[k].getImage());

        if ((this.notes[k].getZuoyou() == 0) && (this.notes[k].getAb() == 0) && (!this.LAnotes.contains(this.notes[k])))
          this.LAnotes.add(this.notes[k]);

          if ((this.notes[k].getZuoyou() == 0) && (this.notes[k].getAb() == 1) && (!this.LBnotes.contains(this.notes[k])))
            this.LBnotes.add(this.notes[k]);
          else if ((this.notes[k].getZuoyou() == 1) && (this.notes[k].getAb() == 0) && (!this.RAnotes.contains(this.notes[k])))
            this.RAnotes.add(this.notes[k]);
          else if ((this.notes[k].getZuoyou() == 1) && (this.notes[k].getAb() == 1) && (!this.RBnotes.contains(this.notes[k])))
            this.RBnotes.add(this.notes[k]);
    }
    logger.debug("create Track end");
  }

  public void Clean()
  {
    this.xiaojieIndex = 1;
    this.mLAnownoteindex = 0;
    this.mLBnownoteindex = 0;
    this.mRAnownoteindex = 0;
    this.mRBnownoteindex = 0;
    this.mLAnownoteindex = 0;
    this.mLBnownoteindex = 0;
    this.mRAnownoteindex = 0;
    this.mRBnownoteindex = 0;
  }

	public void Pause() {
		if (xiaojie == null) {
			return;
		}

		while (true) {
			if (!xiaojie.isAlive()) {
				return;
			}
			xiaojie.Stop();
			try {
				xiaojie.join(30L);
			} catch (InterruptedException localInterruptedException) {
				localInterruptedException.printStackTrace();
			}
		}
	}

  public void Pause1()
  {
    while ((xiaojie != null) && (xiaojie.isAlive()));
  }

  public void Start(MusicActivity paramMusicActivity, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    if ((Xiaojie.getInstance() == null) || (xiaojie == null) || (!xiaojie.isAlive())) {
      xiaojie = new Xiaojie(paramMusicActivity, me, this.LAnotes, this.LBnotes, this.RAnotes, this.RBnotes, paramInt1, this.mLAnownoteindex, this.mLBnownoteindex, this.mRAnownoteindex, this.mRBnownoteindex, paramInt2, paramBoolean);
 
    } else {

      xiaojie = Xiaojie.getInstance();
      xiaojie.SetXiaojie(paramMusicActivity, me, this.LAnotes, this.LBnotes, this.RAnotes, this.RBnotes, paramInt1, this.mLAnownoteindex, this.mLBnownoteindex, this.mRAnownoteindex, this.mRBnownoteindex, paramInt2, paramBoolean);
    }
    xiaojie.setPriority(7);
    xiaojie.start();
  }

  public void Update(int paramInt)
  {
    xiaojie.jiepaiNUm = paramInt;
  }

  public String getAuthor()
  {
    return this.author;
  }

  public String getContentString()
  {
    return this.contentString;
  }

  public String getDes()
  {
    return this.des;
  }

  public int getJiepai()
  {
      return this.jiepai;
  }

  public int getJiepaiTime()
  {
    return this.jiepaiTime;
  }

  public List<Note> getLAnotes()
  {
    return this.LAnotes;
  }

  public List<Note> getLBnotes()
  {
    return this.LBnotes;
  }

  public Note[] getNotes()
  {
    return this.notes;
  }

  public List<String> getPhtoList()
  {
    return this.phtoList;
  }

  public int getPhythm()
  {
    return this.phythm;
  }

  public List<Note> getRAnotes()
  {
    return this.RAnotes;
  }

  public List<Note> getRBnotes()
  {
    return this.RBnotes;
  }

  public int getRowslength()
  {
    return this.rowslength;
  }

  public String getTitle()
  {
    return this.title;
  }

  public int getXiaoJieNum()
  {
    return this.xiaoJieNum;
  }

  public Xiaojie getXiaojie()
  {
    return xiaojie;
  }

  public int getXiaojieIndex()
  {
    return this.xiaojieIndex;
  }

  public String getaDAuthor()
  {
    return this.aDAuthor;
  }

  public void setAuthor(String paramString)
  {
    this.author = paramString;
  }

  public void setContentString(String paramString)
  {
    this.contentString = paramString;
  }

  public void setDes(String paramString)
  {
    this.des = paramString;
  }

  public void setJiepai(int paramInt)
  {
      this.jiepai = paramInt;
  }

  public void setJiepaiTime(int paramInt)
  {
    this.jiepaiTime = paramInt;
  }

  public void setLAnotes(List<Note> paramList)
  {
    this.LAnotes = paramList;
  }

  public void setLBnotes(List<Note> paramList)
  {
    this.LBnotes = paramList;
  }

  public void setNotes(Note[] paramArrayOfNote)
  {
    this.notes = paramArrayOfNote;
  }

  public void setPhtoList(List<String> paramList)
  {
    this.phtoList = paramList;
  }

  public void setPhythm(int paramInt)
  {
    this.phythm = paramInt;
  }

  public void setRAnotes(List<Note> paramList)
  {
    this.RAnotes = paramList;
  }

  public void setRBnotes(List<Note> paramList)
  {
    this.RBnotes = paramList;
  }

  public void setRowslength(int paramInt)
  {
    this.rowslength = paramInt;
  }

  public void setTitle(String paramString)
  {
    this.title = paramString;
  }

  public void setXiaoJieNum(int paramInt)
  {
    this.xiaoJieNum = paramInt;
  }

  public void setXiaojie(Xiaojie paramXiaojie)
  {
    xiaojie = paramXiaojie;
  }

  public void setXiaojieIndex(int paramInt)
  {
    this.xiaojieIndex = paramInt;
  }

  public void setaDAuthor(String paramString)
  {
    this.aDAuthor = paramString;
  }
}

/* Location:           C:\Downloads\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.uxiu.scpark.engine.Track
 * JD-Core Version:    0.6.2
 */