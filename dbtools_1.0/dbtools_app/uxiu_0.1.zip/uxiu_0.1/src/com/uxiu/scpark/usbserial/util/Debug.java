package com.uxiu.scpark.usbserial.util;

import java.io.PrintStream;

public class Debug
{
  public static void OutMsg(String paramString)
  {
    System.out.println(paramString);
  }
}

/* Location:           C:\Downloads\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.uxiu.scpark.usbserial.util.Debug
 * JD-Core Version:    0.6.2
 */