package com.uxiu.scpark.view;

import java.io.IOException;

import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.MediaController;

public class VideoView extends SurfaceView
  implements MediaController.MediaPlayerControl
{
  private String TAG = "VideoView";
  public Handler handler = new Handler()
  {
    public void handleMessage(Message paramAnonymousMessage)
    {
      if (paramAnonymousMessage.arg1 == 1)
      {
        mMediaPlayer.start();
        return;
      }
      mMediaPlayer.pause();
    }
  };
  private MediaPlayer.OnBufferingUpdateListener mBufferingUpdateListener = new MediaPlayer.OnBufferingUpdateListener()
  {
    public void onBufferingUpdate(MediaPlayer paramAnonymousMediaPlayer, int paramAnonymousInt)
    {
      mCurrentBufferPercentage = paramAnonymousInt;
    }
  };
  private MediaPlayer.OnCompletionListener mCompletionListener = new MediaPlayer.OnCompletionListener()
  {
    public void onCompletion(MediaPlayer paramAnonymousMediaPlayer)
    {
      if (mMediaController != null)
        mMediaController.hide();
      if (mOnCompletionListener != null)
        mOnCompletionListener.onCompletion(mMediaPlayer);
    }
  };
  private Context mContext;
  private int mCurrentBufferPercentage;
  private int mDuration;
  private MediaPlayer.OnErrorListener mErrorListener = new MediaPlayer.OnErrorListener()
  {
    public boolean onError(MediaPlayer paramAnonymousMediaPlayer, int paramAnonymousInt1, int paramAnonymousInt2)
    {
      Log.d(TAG, "Error: " + paramAnonymousInt1 + "," + paramAnonymousInt2);
      if (mMediaController != null)
        mMediaController.hide();
      if ((mOnErrorListener != null) && (mOnErrorListener.onError(mMediaPlayer, paramAnonymousInt1, paramAnonymousInt2)));
      while (getWindowToken() == null)
        return true;
      mContext.getResources();
      return true;
    }
  };
  private boolean mIsPrepared;
  private MediaController mMediaController;
  private MediaPlayer mMediaPlayer = null;
  private MySizeChangeLinstener mMyChangeLinstener;
  private MediaPlayer.OnCompletionListener mOnCompletionListener;
  private MediaPlayer.OnErrorListener mOnErrorListener;
  private MediaPlayer.OnPreparedListener mOnPreparedListener;
  MediaPlayer.OnPreparedListener mPreparedListener = new MediaPlayer.OnPreparedListener()
  {
    public void onPrepared(MediaPlayer paramAnonymousMediaPlayer)
    {
      mIsPrepared = true;
      if (mOnPreparedListener != null)
        mOnPreparedListener.onPrepared(mMediaPlayer);
      if (mMediaController != null)
        mMediaController.setEnabled(true);
      mVideoWidth = paramAnonymousMediaPlayer.getVideoWidth();
      mVideoHeight = paramAnonymousMediaPlayer.getVideoHeight();
      if ((mVideoWidth != 0) && (mVideoHeight != 0))
      {
        getHolder().setFixedSize(mVideoWidth, mVideoHeight);
        if ((mSurfaceWidth == mVideoWidth) && (mSurfaceHeight == mVideoHeight))
        {
          if (mSeekWhenPrepared != 0)
          {
            mMediaPlayer.seekTo(mSeekWhenPrepared);
            mSeekWhenPrepared = 0;
          }
          if (!mStartWhenPrepared) {
        	  // TODO --  break label244;
             // label244: 
                  do
                  {
                  //  do
                     // return;
                  //  while ((isPlaying()) || ((mSeekWhenPrepared == 0) && (getCurrentPosition() <= 0)) || (mMediaController == null));
                    mMediaController.show(0);
                  //  return;
                    if (mSeekWhenPrepared != 0)
                    {
                      mMediaPlayer.seekTo(mSeekWhenPrepared);
                      mSeekWhenPrepared = 0;
                    }
                  }
                  while (!mStartWhenPrepared);
                  mMediaPlayer.start();
                  mStartWhenPrepared = false;
          } else {

	          mMediaPlayer.start();
	          mStartWhenPrepared = false;
	          if (mMediaController != null) {
	            mMediaController.show();
	          }
          }
        }
      }

    }
  };
  SurfaceHolder.Callback mSHCallback = new SurfaceHolder.Callback()
  {
    public void surfaceChanged(SurfaceHolder paramAnonymousSurfaceHolder, int paramAnonymousInt1, int paramAnonymousInt2, int paramAnonymousInt3)
    {
      mSurfaceWidth = paramAnonymousInt2;
      mSurfaceHeight = paramAnonymousInt3;
      if ((mMediaPlayer != null) && (mIsPrepared) && (mVideoWidth == paramAnonymousInt2) && (mVideoHeight == paramAnonymousInt3))
      {
        if (mSeekWhenPrepared != 0)
        {
          mMediaPlayer.seekTo(mSeekWhenPrepared);
          mSeekWhenPrepared = 0;
        }
        mMediaPlayer.start();
        if (mMediaController != null)
          mMediaController.show();
      }
    }

    public void surfaceCreated(SurfaceHolder paramAnonymousSurfaceHolder)
    {
      mSurfaceHolder = paramAnonymousSurfaceHolder;
      openVideo();
    }

    public void surfaceDestroyed(SurfaceHolder paramAnonymousSurfaceHolder)
    {
      mSurfaceHolder = null;
      if (mMediaController != null)
        mMediaController.hide();
      if (mMediaPlayer != null)
      {
        mMediaPlayer.reset();
        mMediaPlayer.release();
        mMediaPlayer = null;
      }
    }
  };
  private int mSeekWhenPrepared;
  MediaPlayer.OnVideoSizeChangedListener mSizeChangedListener = new MediaPlayer.OnVideoSizeChangedListener()
  {
    public void onVideoSizeChanged(MediaPlayer paramAnonymousMediaPlayer, int paramAnonymousInt1, int paramAnonymousInt2)
    {
      mVideoWidth = paramAnonymousMediaPlayer.getVideoWidth();
      mVideoHeight = paramAnonymousMediaPlayer.getVideoHeight();
      if (mMyChangeLinstener != null)
        mMyChangeLinstener.doMyThings();
      if ((mVideoWidth != 0) && (mVideoHeight != 0))
        getHolder().setFixedSize(mVideoWidth, mVideoHeight);
    }
  };
  private boolean mStartWhenPrepared;
  private int mSurfaceHeight;
  private SurfaceHolder mSurfaceHolder = null;
  private int mSurfaceWidth;
  private Uri mUri;
  private int mVideoHeight;
  private int mVideoWidth;
  public int now = -1;
  public VideoStart videoStart = null;

  public VideoView(Context paramContext)
  {
    super(paramContext);
    this.mContext = paramContext;
    initVideoView();
  }

  public VideoView(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
    this.mContext = paramContext;
    initVideoView();
  }

  public VideoView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    this.mContext = paramContext;
    initVideoView();
  }

  private void attachMediaController()
  {
    if ((this.mMediaPlayer != null) && (this.mMediaController != null))
    {
      this.mMediaController.setMediaPlayer(this);
      if (!(getParent() instanceof View)) {
    	  // TODO --
    	    label60: for (Object localObject = (View)getParent(); ; localObject = this)
    	    {
    	      this.mMediaController.setAnchorView((View)localObject);
    	      this.mMediaController.setEnabled(this.mIsPrepared);
    	      return;
    	    }
      }
    }

  }

  private void initVideoView()
  {
    this.mVideoWidth = 0;
    this.mVideoHeight = 0;
    getHolder().addCallback(this.mSHCallback);
    getHolder().setType(3);
    setFocusable(true);
    setFocusableInTouchMode(true);
    requestFocus();
  }

  private void openVideo()
  {
    if ((this.mUri == null) || (this.mSurfaceHolder == null))
      return;
    Intent localIntent = new Intent("com.android.music.musicservicecommand");
    localIntent.putExtra("command", "pause");
    this.mContext.sendBroadcast(localIntent);
    if (this.mMediaPlayer != null)
    {
      this.mMediaPlayer.reset();
      this.mMediaPlayer.release();
      this.mMediaPlayer = null;
    }
    try
    {
      this.mMediaPlayer = new MediaPlayer();
      this.mMediaPlayer.setOnPreparedListener(this.mPreparedListener);
      this.mMediaPlayer.setOnVideoSizeChangedListener(this.mSizeChangedListener);
      this.mIsPrepared = false;
      Log.v(this.TAG, "reset duration to -1 in openVideo");
      this.mDuration = -1;
      this.mMediaPlayer.setOnCompletionListener(this.mCompletionListener);
      this.mMediaPlayer.setOnErrorListener(this.mErrorListener);
      this.mMediaPlayer.setOnBufferingUpdateListener(this.mBufferingUpdateListener);
      this.mCurrentBufferPercentage = 0;
      this.mMediaPlayer.setDataSource(this.mContext, this.mUri);
      this.mMediaPlayer.setDisplay(this.mSurfaceHolder);
      this.mMediaPlayer.setAudioStreamType(3);
      this.mMediaPlayer.setScreenOnWhilePlaying(true);
      this.mMediaPlayer.prepareAsync();
      attachMediaController();
      return;
    }
    catch (IOException localIOException)
    {
      Log.w(this.TAG, "Unable to open content: " + this.mUri, localIOException);
      return;
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      Log.w(this.TAG, "Unable to open content: " + this.mUri, localIllegalArgumentException);
    }
  }

  private void toggleMediaControlsVisiblity()
  {
    if (this.mMediaController.isShowing())
    {
      this.mMediaController.hide();
      return;
    }
    this.mMediaController.show();
  }

  public boolean canPause()
  {
    return false;
  }

  public boolean canSeekBackward()
  {
    return false;
  }

  public boolean canSeekForward()
  {
    return false;
  }

  public int getBufferPercentage()
  {
    if (this.mMediaPlayer != null)
      return this.mCurrentBufferPercentage;
    return 0;
  }

  public int getCurrentPosition()
  {
      if ((this.mMediaPlayer != null) && (this.mIsPrepared))
      {
    	  return this.mMediaPlayer.getCurrentPosition();
      } else {
    	  return 0;
      }
  }

  public int getDuration()
  {
    if ((this.mMediaPlayer != null) && (this.mIsPrepared))
    {
      if (this.mDuration > 0)
        return this.mDuration;
      this.mDuration = this.mMediaPlayer.getDuration();
      return this.mDuration;
    }
    this.mDuration = -1;
    return this.mDuration;
  }

  public int getVideoHeight()
  {
    return this.mVideoHeight;
  }

  public int getVideoWidth()
  {
    return this.mVideoWidth;
  }

  public boolean isPlaying()
  {
    if ((this.mMediaPlayer != null) && (this.mIsPrepared))
      return this.mMediaPlayer.isPlaying();
    return false;
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if ((this.mIsPrepared) && (paramInt != 4) && (paramInt != 24) && (paramInt != 25) && (paramInt != 82) && (paramInt != 5) && (paramInt != 6) && (this.mMediaPlayer != null) && (this.mMediaController != null))
    {
      if ((paramInt == 79) || (paramInt == 85))
      {
        if (this.mMediaPlayer.isPlaying())
        {
          pause();
          this.mMediaController.show();
          
        } else {
          
          start();
          this.mMediaController.hide();
        }
        return true;
      }
      if(paramInt == 86 && mMediaPlayer.isPlaying())
      {
          pause();
          mMediaController.show();
      } else
      {
          toggleMediaControlsVisiblity();
      }
    }
      return super.onKeyDown(paramInt, paramKeyEvent);

  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    setMeasuredDimension(getDefaultSize(this.mVideoWidth, paramInt1), getDefaultSize(this.mVideoHeight, paramInt2));
  }

  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    if ((this.mIsPrepared) && (this.mMediaPlayer != null) && (this.mMediaController != null))
      toggleMediaControlsVisiblity();
    return false;
  }

  public boolean onTrackballEvent(MotionEvent paramMotionEvent)
  {
    if ((this.mIsPrepared) && (this.mMediaPlayer != null) && (this.mMediaController != null))
      toggleMediaControlsVisiblity();
    return false;
  }

  public void pause()
  {
    while (true)
    {
      if ((this.videoStart == null) || (!this.videoStart.isAlive()))
      {
        if ((this.mMediaPlayer != null) && (this.mIsPrepared) && (this.mMediaPlayer.isPlaying()))
          this.mMediaPlayer.pause();
        this.mStartWhenPrepared = false;
        return;
      }
      this.videoStart.Stop();
    }
  }

  public int resolveAdjustedSize(int paramInt1, int paramInt2)
  {
    int i = View.MeasureSpec.getMode(paramInt2);
    int j = View.MeasureSpec.getSize(paramInt2);
    switch (i)
    {
    default:
      return paramInt1;
    case 0:
      return paramInt1;
    case -2147483648:
      return Math.min(paramInt1, j);
    case 1073741824:
    }
    return j;
  }

  public void seekTo(int paramInt)
  {
    if ((this.mMediaPlayer != null) && (this.mIsPrepared))
    {
      this.mMediaPlayer.seekTo(paramInt);
      return;
    }
    this.mSeekWhenPrepared = paramInt;
  }

  public void setMediaController(MediaController paramMediaController)
  {
    if (this.mMediaController != null)
      this.mMediaController.hide();
    this.mMediaController = paramMediaController;
    attachMediaController();
  }

  public void setMySizeChangeLinstener(MySizeChangeLinstener paramMySizeChangeLinstener)
  {
    this.mMyChangeLinstener = paramMySizeChangeLinstener;
  }

  public void setOnCompletionListener(MediaPlayer.OnCompletionListener paramOnCompletionListener)
  {
    this.mOnCompletionListener = paramOnCompletionListener;
  }

  public void setOnErrorListener(MediaPlayer.OnErrorListener paramOnErrorListener)
  {
    this.mOnErrorListener = paramOnErrorListener;
  }

  public void setOnPreparedListener(MediaPlayer.OnPreparedListener paramOnPreparedListener)
  {
    this.mOnPreparedListener = paramOnPreparedListener;
  }

  public void setVideoPath(String paramString)
  {
    setVideoURI(Uri.parse(paramString));
  }

  public void setVideoScale(int paramInt1, int paramInt2)
  {
    ViewGroup.LayoutParams localLayoutParams = getLayoutParams();
    localLayoutParams.height = paramInt2;
    localLayoutParams.width = paramInt1;
    setLayoutParams(localLayoutParams);
  }

  public void setVideoURI(Uri paramUri)
  {
    this.mUri = paramUri;
    this.mStartWhenPrepared = false;
    this.mSeekWhenPrepared = 0;
    openVideo();
    requestLayout();
    invalidate();
  }

  public void start()
  {
    if ((this.mMediaPlayer != null) && (this.mIsPrepared))
    {
      this.mMediaPlayer.start();
      this.mStartWhenPrepared = false;
      return;
    }
    this.mStartWhenPrepared = true;
  }

  public void start(int paramInt)
  {
    System.out.println("start(size)");
    while (true)
    {
      if ((this.videoStart == null) || (!this.videoStart.isAlive()))
      {
        System.out.println("size" + paramInt);
        this.videoStart = new VideoStart(paramInt);
        this.videoStart.start();
        return;
      }
      System.out.println("videoStart.Stop()");
      this.videoStart.Stop();
    }
  }

  public void start(int paramInt, boolean paramBoolean)
  {
    System.out.println("start(size)");
    while (true)
    {
      if ((this.videoStart == null) || (!this.videoStart.isAlive()))
      {
        System.out.println("size" + paramInt);
        this.videoStart = new VideoStart(paramInt, paramBoolean);
        this.videoStart.start();
        return;
      }
      System.out.println("videoStart.Stop()");
      this.videoStart.Stop();
    }
  }

  public void stopPlayback()
  {
    if (this.mMediaPlayer != null)
    {
      this.mMediaPlayer.stop();
      this.mMediaPlayer.release();
      this.mMediaPlayer = null;
    }
  }

  public static abstract interface MySizeChangeLinstener
  {
    public abstract void doMyThings();
  }

  public class VideoStart extends Thread
  {
    boolean OneFlg = false;
    boolean flg = true;
    int size = 0;
    int sleeptimeA = 0;
    int sleeptimeB = 0;

    VideoStart(int arg2)
    {
      int i = arg2;
      System.out.println("size" + i);
      this.size = i;
      if ((i <= 10) && (i > 0))
      {
        this.sleeptimeA = i;
        this.sleeptimeB = (10 - i);
      }
    }

    VideoStart(int paramBoolean, boolean arg3)
    {
    	int i = paramBoolean;
      System.out.println("size" + paramBoolean);
      this.size = paramBoolean;
      if ((i <= 10) && (i > 0))
      {
        this.sleeptimeA = i;
        this.sleeptimeB = (10 - i);
      }

      this.OneFlg = arg3;
    }

    public void Stop()
    {
      this.flg = false;
    }

    public void run()
    {
      super.run();
      if (this.size == 10)
        if ((mMediaPlayer != null) && (mIsPrepared))
        {
          mMediaPlayer.start();
          mStartWhenPrepared = false;
          return;
        //  break label253;
        }
      while (true)
      {
        mStartWhenPrepared = true;
       // return;
        if ((this.size < 10) && (this.size > 0))
          while (this.flg)
          {
            mIsPrepared = true;
            if ((mMediaPlayer != null) && (mIsPrepared))
            {
              mMediaPlayer.start();
              mStartWhenPrepared = false;
              label130: System.gc();
            }
            try
            {
              sleep(this.sleeptimeA);
              if ((mMediaPlayer != null) && (mIsPrepared) && (mMediaPlayer.isPlaying()))
                mMediaPlayer.pause();
              System.gc();
            }
            catch (InterruptedException localInterruptedException4)
            {
              try
              {
                sleep(3 * (this.sleeptimeB * this.sleeptimeB));
                if (mMediaPlayer == null)
                {
                 // return;
                  mStartWhenPrepared = true;
                //  break label130;
                  localInterruptedException4 = localInterruptedException4;
                  localInterruptedException4.printStackTrace();
                }
              }
              catch (InterruptedException localInterruptedException5)
              {
                while (true)
                  localInterruptedException5.printStackTrace();
              }
            }
          }
        if (this.size > 10)
        {
          label253: if (!this.flg)
            continue;
          mIsPrepared = true;
          if ((mMediaPlayer != null) && (mIsPrepared))
          {
            mMediaPlayer.start();
            mStartWhenPrepared = false;
            System.gc();
          }
          try
          {
            sleep(10L);
            if (mMediaPlayer == null)
              continue;
            now = mMediaPlayer.getCurrentPosition();
            if (now + 100 * (-10 + this.size) > mMediaPlayer.getDuration())
            {
              mMediaPlayer.seekTo(mMediaPlayer.getDuration());
             // return;
              mStartWhenPrepared = true;
            }
          }
          catch (InterruptedException localInterruptedException3)
          {
           // while (true)
              localInterruptedException3.printStackTrace();
            mMediaPlayer.seekTo(now + 100 * (-10 + this.size));
          }
          if (!this.OneFlg)
            break;
          return;
        }
        if (this.size == -10)
        {
          label460: if (!this.flg)
            continue;
          mIsPrepared = true;
          if ((mMediaPlayer != null) && (mIsPrepared))
          {
            mMediaPlayer.start();
            mStartWhenPrepared = false;
            System.gc();
          }
          try
          {
            sleep(10L);
            if (mMediaPlayer == null)
              continue;
            now = mMediaPlayer.getCurrentPosition();
            VideoView localVideoView2 = VideoView.this;
            localVideoView2.now = (-1000 + localVideoView2.now);
            if (now <= 0)
              now = 0;
            mMediaPlayer.seekTo(now);
            if (!this.OneFlg) {
            	
            }
             // break label460;
           // return;
            mStartWhenPrepared = true;
          }
          catch (InterruptedException localInterruptedException2)
          {
            while (true)
              localInterruptedException2.printStackTrace();
          }
        }
        label640: if ((this.size >= -10) || (!this.flg))
          continue;
        mIsPrepared = true;
        if ((mMediaPlayer != null) && (mIsPrepared))
        {
          mMediaPlayer.start();
          mStartWhenPrepared = false;
          System.gc();
        }
        try
        {
          sleep(10L);
          if (mMediaPlayer == null)
            continue;
          now = mMediaPlayer.getCurrentPosition();
          VideoView localVideoView1 = VideoView.this;
          localVideoView1.now = (-3000 + localVideoView1.now);
          if (now <= 0)
            now = 0;
          mMediaPlayer.seekTo(now);
          if (!this.OneFlg) {
          //  break label640;
          }
         // return;
          mStartWhenPrepared = true;
        }
        catch (InterruptedException localInterruptedException1)
        {
          while (true)
            localInterruptedException1.printStackTrace();
        }
      }
    }
  }
}

/* Location:           C:\Downloads\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.uxiu.scpark.view.VideoView
 * JD-Core Version:    0.6.2
 */