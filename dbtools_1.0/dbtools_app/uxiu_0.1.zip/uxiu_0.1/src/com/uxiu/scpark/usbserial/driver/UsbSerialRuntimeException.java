package com.uxiu.scpark.usbserial.driver;

public class UsbSerialRuntimeException extends RuntimeException
{
  public UsbSerialRuntimeException()
  {
  }

  public UsbSerialRuntimeException(String paramString)
  {
    super(paramString);
  }

  public UsbSerialRuntimeException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }

  public UsbSerialRuntimeException(Throwable paramThrowable)
  {
    super(paramThrowable);
  }
}

/* Location:           C:\Downloads\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.uxiu.scpark.usbserial.driver.UsbSerialRuntimeException
 * JD-Core Version:    0.6.2
 */