package com.uxiu.scpark.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

public class AnimationTabHost extends TabHost
{
  private boolean isOpenAnimation;
  private int mTabCount;
  private Animation slideLeftIn;
  private Animation slideLeftOut;
  private Animation slideRightIn;
  private Animation slideRightOut;

  public AnimationTabHost(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    this.slideLeftIn = AnimationUtils.loadAnimation(paramContext, 2130968576);
    this.slideLeftOut = AnimationUtils.loadAnimation(paramContext, 2130968577);
    this.slideRightIn = AnimationUtils.loadAnimation(paramContext, 2130968578);
    this.slideRightOut = AnimationUtils.loadAnimation(paramContext, 2130968579);
    this.isOpenAnimation = false;
  }

  public void addTab(TabHost.TabSpec paramTabSpec)
  {
    this.mTabCount = (1 + this.mTabCount);
    super.addTab(paramTabSpec);
  }

  public int getTabCount()
  {
    return this.mTabCount;
  }

  public void setCurrentTab(int paramInt)
  {
    int i = getCurrentTab();
    if ((getCurrentView() != null) && (this.isOpenAnimation))
    {
      if ((i == -1 + this.mTabCount) && (paramInt == 0))
        getCurrentView().startAnimation(this.slideLeftOut);
    }
    else
    {
      super.setCurrentTab(paramInt);
      if (this.isOpenAnimation)
      {
        if ((i != -1 + this.mTabCount) || (paramInt != 0)) {
            do
            {
              if ((i == 0) && (paramInt == -1 + this.mTabCount))
              {
                getCurrentView().startAnimation(this.slideRightOut);
                break;
              }
              if (paramInt > i)
              {
                getCurrentView().startAnimation(this.slideLeftOut);
                break;
              }
              if (paramInt >= i)
                break;
              getCurrentView().startAnimation(this.slideRightOut);

              if ((i == 0) && (paramInt == -1 + this.mTabCount))
              {
                getCurrentView().startAnimation(this.slideRightIn);
                return;
              }
              if (paramInt > i)
              {
                getCurrentView().startAnimation(this.slideLeftIn);
                return;
              }
            }
            while (paramInt >= i);
            getCurrentView().startAnimation(this.slideRightIn);

        } else {
        	getCurrentView().startAnimation(this.slideLeftIn);
        }
      }
    }
  }

  public void setOpenAnimation(boolean paramBoolean)
  {
    this.isOpenAnimation = paramBoolean;
  }

  public boolean setTabAnimation(int[] paramArrayOfInt)
  {
    if (3 == paramArrayOfInt.length)
    {
      this.slideLeftIn = AnimationUtils.loadAnimation(getContext(), paramArrayOfInt[0]);
      this.slideLeftOut = AnimationUtils.loadAnimation(getContext(), paramArrayOfInt[1]);
      this.slideRightIn = AnimationUtils.loadAnimation(getContext(), paramArrayOfInt[2]);
      this.slideRightOut = AnimationUtils.loadAnimation(getContext(), paramArrayOfInt[3]);
      return true;
    }
    return false;
  }
}

/* Location:           C:\Downloads\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.uxiu.scpark.view.AnimationTabHost
 * JD-Core Version:    0.6.2
 */