package com.uxiu.scpark.engine;

import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Message;
import com.uxiu.activity.MusicActivity;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

public class Xiaojie extends Thread {
	private static Xiaojie instance = null;
	List<Note> LAnotes = new ArrayList();
	List<Note> LBnotes = new ArrayList();
	MediaPlayer MediaPlayer1;
	MediaPlayer MediaPlayer2;
	MediaPlayer MediaPlayer3;
	MediaPlayer MediaPlayer4;
	List<Note> RAnotes = new ArrayList();
	List<Note> RBnotes = new ArrayList();
	private boolean ZhuBuFlg = false;
	MusicActivity ap;
	public Bofang[] bofangs;
	List<Bofang> bofangs1;
	int endindex = 0;
	private boolean flg = true;
	int jiepaiNUm = 0;
	long jiepaitime = 0L;
	Bofang mLAbofang = new Bofang();
	List<Note> mLAnotes = new ArrayList();
	int mLAnownoteindex = 0;
	Bofang mLBbofang = new Bofang();
	List<Note> mLBnotes = new ArrayList();
	int mLBnownoteindex = 0;
	Bofang mRAbofang = new Bofang();
	List<Note> mRAnotes = new ArrayList();
	int mRAnownoteindex = 0;
	Bofang mRBbofang = new Bofang();
	List<Note> mRBnotes = new ArrayList();
	int mRBnownoteindex = 0;
	Track track;
	private int xiaojieIndex = 1;

	public Xiaojie(MusicActivity paramMusicActivity, Track paramTrack, List<Note> paramList1, List<Note> paramList2,
			List<Note> paramList3, List<Note> paramList4, int paramInt1, int paramInt2, int paramInt3, int paramInt4,
			int paramInt5, int paramInt6, boolean paramBoolean) {
		Bofang[] arrayOfBofang = new Bofang[4];
		arrayOfBofang[0] = this.mLAbofang;
		arrayOfBofang[1] = this.mLBbofang;
		arrayOfBofang[2] = this.mRAbofang;
		arrayOfBofang[3] = this.mRBbofang;
		this.bofangs = arrayOfBofang;
		this.bofangs1 = new ArrayList();
		this.track = paramTrack;
		this.LAnotes = paramList1;
		this.LBnotes = paramList2;
		this.RAnotes = paramList3;
		this.RBnotes = paramList4;
		this.ap = paramMusicActivity;
		this.xiaojieIndex = paramInt1;
		this.mLAnownoteindex = paramInt2;
		this.mLBnownoteindex = paramInt3;
		this.mRAnownoteindex = paramInt4;
		this.mRBnownoteindex = paramInt5;
		this.endindex = paramInt6;
		this.ZhuBuFlg = paramBoolean;
		instance = this;
	}

	public static Xiaojie getInstance() {
		return instance;
	}

	public Boolean CheckBofang() {
		int i = this.bofangs1.size();
		for (int j = 0;; j++) {
			if (j >= i) {
				return i != 0;
			}
			Bofang localBofang = (Bofang) this.bofangs1.get(j);
			if (localBofang == null || !localBofang.isAlive()) {
				this.bofangs1.remove(j);
				i = this.bofangs1.size();
			}
		}
	}

	public boolean CheckBofang(Bofang paramBofang1, Bofang paramBofang2, Bofang paramBofang3, Bofang paramBofang4) {
		if (((paramBofang1 == null) || (!paramBofang1.isAlive()))
				&& ((paramBofang2 == null) || (!paramBofang2.isAlive()))
				&& ((paramBofang3 == null) || (!paramBofang3.isAlive()))
				&& ((paramBofang4 == null) || (!paramBofang4.isAlive()))) {
			return false;
		} else {
			return true;
		}
	}

	public void SetXiaojie(MusicActivity paramMusicActivity, Track paramTrack, List<Note> paramList1,
			List<Note> paramList2, List<Note> paramList3, List<Note> paramList4, int paramInt1, int paramInt2,
			int paramInt3, int paramInt4, int paramInt5, int paramInt6, boolean paramBoolean) {
		this.track = paramTrack;
		this.LAnotes = paramList1;
		this.LBnotes = paramList2;
		this.RAnotes = paramList3;
		this.RBnotes = paramList4;
		this.ap = paramMusicActivity;
		this.xiaojieIndex = paramInt1;
		this.mLAnownoteindex = paramInt2;
		this.mLBnownoteindex = paramInt3;
		this.mRAnownoteindex = paramInt4;
		this.mRBnownoteindex = paramInt5;
		this.endindex = paramInt6;
		this.ZhuBuFlg = paramBoolean;
	}

	public void Stop() {
		while (true) {
			if ((!this.mLAbofang.isAlive()) && (!this.mLBbofang.isAlive()) && (!this.mRAbofang.isAlive())
					&& (!this.mRBbofang.isAlive())) {
				this.flg = false;
				return;
			}
			this.mLAbofang.Stop(1);
			this.mLBbofang.Stop(2);
			this.mRAbofang.Stop(3);
			this.mRBbofang.Stop(4);
		}
	}

	public int getJiepaiNUm() {
		return this.jiepaiNUm;
	}

	public Track getTrack() {
		return this.track;
	}

	public int getXiaojieIndex() {
		return this.xiaojieIndex;
	}

	public int getmLAnownoteindex() {
		return this.mLAnownoteindex;
	}

	public int getmLBnownoteindex() {
		return this.mLBnownoteindex;
	}

	public int getmRAnownoteindex() {
		return this.mRAnownoteindex;
	}

	public int getmRBnownoteindex() {
		return this.mRBnownoteindex;
	}

	public void run() {
		super.run();
		System.out.println("xiaojieIndex:" + this.xiaojieIndex);
		System.out.println("endindex:" + this.endindex);
		int i = this.xiaojieIndex;
		if (i > this.endindex) {
			if (this.xiaojieIndex == 1 + this.endindex) {
				this.ap.handler.obtainMessage(13, this.endindex, 0).sendToTarget();
			}
			return;
		}

		System.out.println("Xiaojie start" + this.xiaojieIndex);
		this.jiepaiNUm = this.track.getJiepai();
		this.jiepaitime = (60000 / this.track.getJiepai());
		this.mLAnotes.clear();
		this.mLBnotes.clear();
		this.mRAnotes.clear();
		this.mRBnotes.clear();
		int j = this.LAnotes.size();
		int k = 0;

		int l = 0;
		int i1 = 0;
		// _L13:
		while (true) {
			if (k < j) {
				if (((Note) LAnotes.get(k)).getJieIndex() == i) {
					mLAnotes.add((Note) LAnotes.get(k));
				}
				k++;
				// goto _L13
				continue;
			} else {
				l = this.LBnotes.size();
				i1 = 0;
				break;
			}
		}
		int j1 = 0;
		int k1 = 0;
		// _L14:
		while (true) {
			if (i1 < l) {
				if (((Note) LBnotes.get(i1)).getJieIndex() == i) {
					mLBnotes.add((Note) LBnotes.get(i1));
				}
				i1++;
				// goto _L14
				continue;
			} else {
				j1 = this.RAnotes.size();
				k1 = 0;
				break;
			}
		}

		// _L15:
		int l1 = 0;
		int i2 = 0;
		while (true) {
			if (k1 < j1) {
				if (((Note) RAnotes.get(k1)).getJieIndex() == i) {
					mRAnotes.add((Note) RAnotes.get(k1));
				}
				k1++;
				// goto _L15
				continue;
			} else {
				l1 = this.RBnotes.size();
				i2 = 0;
				break;
			}
		}

		// _L16:
		while (true) {
			if (i2 < l1) {
				if (((Note) RBnotes.get(i2)).getJieIndex() == i) {
					mRBnotes.add((Note) RBnotes.get(i2));
				}
				i2++;
				// goto _L16
				continue;

			} else {
				// _L9:
				if (this.flg) {
					// _L11
					if (j > 0) {
						this.mLAbofang = new Bofang(1, this.track, this.ap, this.mLAnotes, this.jiepaitime,
								this.mLAnownoteindex, this.ZhuBuFlg, this.LAnotes);
						this.mLAbofang.setPriority(6);
						this.mLAbofang.start();
					}
					if (l > 0) {
						this.mLBbofang = new Bofang(2, this.track, this.ap, this.mLBnotes, this.jiepaitime,
								this.mLBnownoteindex, this.ZhuBuFlg);
						this.mLBbofang.setPriority(6);
						this.mLBbofang.start();
					}
					if (j1 > 0) {
						this.mRAbofang = new Bofang(3, this.track, this.ap, this.mRAnotes, this.jiepaitime,
								this.mRAnownoteindex, this.ZhuBuFlg);
						this.mRAbofang.setPriority(6);
						this.mRAbofang.start();
					}
					if (l1 > 0) {
						this.mRBbofang = new Bofang(4, this.track, this.ap, this.mRBnotes, this.jiepaitime,
								this.mRBnownoteindex, this.ZhuBuFlg);
						this.mRBbofang.setPriority(6);
						this.mRBbofang.start();
					}
					this.mLAnownoteindex = 0;
					this.mLBnownoteindex = 0;
					this.mRAnownoteindex = 0;
					this.mRBnownoteindex = 0;

				} else {
					if (!CheckBofang(this.mLAbofang, this.mLBbofang, this.mRAbofang, this.mRBbofang)) {
						if (this.ZhuBuFlg)
							this.flg = false;
						if (this.flg) {
							break;
						}
						this.xiaojieIndex = i;
						this.track.xiaojieIndex = this.xiaojieIndex;
						this.ap.StartIndex = this.xiaojieIndex;
						if (this.mLAnotes.size() == this.track.mLAnownoteindex
								&& this.mLBnotes.size() == this.track.mLBnownoteindex
								&& this.mRAnotes.size() == this.track.mRAnownoteindex
								&& this.mRBnotes.size() == this.track.mRBnownoteindex) {

							this.mLAnownoteindex = 0;
							this.mLBnownoteindex = 0;
							this.mRAnownoteindex = 0;
							this.mRBnownoteindex = 0;
							this.track.mLAnownoteindex = 0;
							this.track.mLBnownoteindex = 0;
							this.track.mRAnownoteindex = 0;
							this.track.mRBnownoteindex = 0;
							this.xiaojieIndex = (1 + this.xiaojieIndex);
							this.track.xiaojieIndex = this.xiaojieIndex;
							this.ap.StartIndex = this.xiaojieIndex;
							System.out.println("bbbSxiaojieIndex" + this.xiaojieIndex);
						}
					}
					try {
						sleep(5L);
					} catch (InterruptedException localInterruptedException) {
						localInterruptedException.printStackTrace();
					}
					//continue;
				}
				break;
			}
		}

	}

	public void setJiepaiNUm(int paramInt) {
		this.jiepaiNUm = paramInt;
	}

	public void setTrack(Track paramTrack) {
		this.track = paramTrack;
	}

	public void setXiaojieIndex(int paramInt) {
		this.xiaojieIndex = paramInt;
	}

	public void setmLAnownoteindex(int paramInt) {
		this.mLAnownoteindex = paramInt;
	}

	public void setmLBnownoteindex(int paramInt) {
		this.mLBnownoteindex = paramInt;
	}

	public void setmRAnownoteindex(int paramInt) {
		this.mRAnownoteindex = paramInt;
	}

	public void setmRBnownoteindex(int paramInt) {
		this.mRBnownoteindex = paramInt;
	}
}
