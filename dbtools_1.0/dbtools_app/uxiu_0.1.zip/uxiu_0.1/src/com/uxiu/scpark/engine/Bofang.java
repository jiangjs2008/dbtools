package com.uxiu.scpark.engine;

import android.content.res.Resources;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Message;
import com.uxiu.activity.MusicActivity;
import com.uxiu.scpark.usbserial.driver.UsbSerialDriver;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Bofang extends Thread {
	List<Note> LAnotes;
	public int Progress = 0;
	private boolean ZhuBuFlg = false;
	MusicActivity ap;
	List<Note> bonotes = new ArrayList();
	int c = 0;
	private boolean flg = true;
	int length = 0;
	long mjiepaitime = 0L;
	private int nownoteindex = 0;
	StringBuilder sBuilder = new StringBuilder();
	HashMap<String, Integer> soundPoolMap;
	String string;
	int thread = 0;
	Track track;

	public Bofang() {
	}

	public Bofang(int paramInt1, Track paramTrack, MusicActivity paramMusicActivity, List<Note> paramList,
			long paramLong, int paramInt2, boolean paramBoolean) {
		this.track = paramTrack;
		this.thread = paramInt1;
		this.bonotes = paramList;
		this.length = paramList.size();
		this.mjiepaitime = paramLong;
		this.nownoteindex = paramInt2;
		this.ap = paramMusicActivity;
		this.ZhuBuFlg = paramBoolean;
	}

	public Bofang(int paramInt1, Track paramTrack, MusicActivity paramMusicActivity, List<Note> paramList1,
			long paramLong, int paramInt2, boolean paramBoolean, List<Note> paramList2) {
		this.track = paramTrack;
		this.thread = paramInt1;
		this.bonotes = paramList1;
		this.bonotes = paramList1;
		this.length = paramList1.size();
		this.mjiepaitime = paramLong;
		this.nownoteindex = paramInt2;
		this.ap = paramMusicActivity;
		this.ZhuBuFlg = paramBoolean;
		this.LAnotes = paramList2;
	}

	private void addProgress(Note paramNote, int paramInt) {
		if ((paramNote.getZuoyou() == 0) && (paramNote.getAb() == 0)) {
			this.Progress = calculate(paramNote.getJieIndex(), paramInt);
			this.ap.handler.obtainMessage(2, this.Progress, 0).sendToTarget();
		}
	}

	private int calculate(int paramInt1, int paramInt2) {
		int i = 0;
		int j = this.LAnotes.size();
		for (int k = 0;; k++) {
			if (k >= j)
				return i + paramInt2;
			if (((Note) this.LAnotes.get(k)).getJieIndex() < paramInt1) {
				i += ((Note) this.LAnotes.get(k)).getNotes().length;
			}
		}
	}

	private void play(String paramString, int paramInt1, int paramInt2) {
		if (!this.ap.voiceflg || "0".equals(paramString)) {
			return;
		}
		if (paramString.contains("/1")) {
			paramString = paramString.replace("/1", "");

		} else {

			if (paramString.contains("/2"))
				paramString = paramString.replace("/2", "");
			else if (paramString.contains("/3"))
				paramString = paramString.replace("/3", "");
			else if (paramString.contains("/4"))
				paramString = paramString.replace("/4", "");
			else if (paramString.contains("/5"))
				paramString = paramString.replace("/5", "");

			String str = "a" + paramString.toLowerCase().replace("#", "_");
			PlayMusc localPlayMusc = new PlayMusc(
					this.ap.getResources().getIdentifier(str, "raw", "com.uxiu.activity"), paramInt2);
			localPlayMusc.setPriority(7);
			localPlayMusc.start();
		}
	}

	public void Stop(int paramInt) {
		this.flg = false;
	}

	public int getNownoteindex() {
		return this.nownoteindex;
	}

	public boolean isFlg() {
		return this.flg;
	}

	public void print(Note paramNote, String paramString, int paramInt) {
		if ("0".equals(paramString)) {
			return;
		}
		if (paramString.contains("TABAN ON")) {
			this.ap.handler.obtainMessage(12, 0, 0).sendToTarget();
			return;
		}
		if (paramString.contains("TABAN OFF")) {
			this.ap.handler.obtainMessage(11, 0, 0).sendToTarget();
			return;
		}
		this.sBuilder = new StringBuilder();
		try {
			if ((paramNote.getZuoyou() == 0) && (this.ap.flgzuo)) {
				this.ap.palyusbZ = true;
				this.sBuilder.append("ST+L+" + paramNote.getIntensity() + "+" + paramNote.getCd() + "+" + paramString + "+OV");
				this.string = (this.sBuilder.toString() + "\n");
				play(paramString, paramInt, (int) (paramNote.getShowJiepai() * (float) this.mjiepaitime));
				this.ap.mSerialDevice.write(this.string.getBytes(), 5);

			} else {
				if ((paramNote.getZuoyou() == 1) && (this.ap.flgyou)) {
					this.ap.palyusbY = true;
					this.sBuilder.append("ST+R+" + paramNote.getIntensity() + "+" + paramNote.getCd() + "+" + paramString + "+OV");
					this.string = (this.sBuilder.toString() + "\n");
					play(paramString, paramInt, (int) (paramNote.getShowJiepai() * (float) this.mjiepaitime));
					this.ap.mSerialDevice.write(this.string.getBytes(), 5);

				} else {
					this.ap.connectflg = true;
					this.ap.handler.obtainMessage(6, 1, 0).sendToTarget();
					this.sBuilder = null;
					return;
				}
				
			}

		} catch (Exception localException) {
		
			this.ap.connectflg = false;
			this.ap.handler.obtainMessage(6, 0, 0).sendToTarget();
			sBuilder = null;
			return;
		}
	}

	public void run() {
		super.run();
		int i = 0;

		for (int j = this.nownoteindex; ; j++) {
			if (j >= this.length) {
				this.length = 0;
				return;
			}
			while (true) {
				this.length = 0;

				Note localNote = null;
				String[] arrayOfString = null;
				int k = 0;
				int m = 0;
				if (this.flg) {
					localNote = (Note) this.bonotes.get(j);
					arrayOfString = localNote.getNotes();
					k = ((Note) this.bonotes.get(j)).getNoteNum();
					showZuoyou(localNote);
					showlocation(localNote);
					if (k > 1) {
						m = 0;
					} else {
						i++;
						addProgress(localNote, i);
						print(localNote, arrayOfString[m], m + 1);
						
						
					}
				
				} else {
					
					this.nownoteindex = (j + 1);
					switch (this.thread) {
					case 1:
						this.track.mLAnownoteindex = this.nownoteindex;
						break;
					case 2:
						this.track.mLBnownoteindex = this.nownoteindex;
						break;
					case 3:
						this.track.mRAnownoteindex = this.nownoteindex;
						break;
					case 4:
						this.track.mRBnownoteindex = this.nownoteindex;
						break;
					default:
						break;
					}
				}
				

//					try {
//						sleep(5L);
//						m++;
//					} catch (InterruptedException localInterruptedException2) {
//						while (true)
//							localInterruptedException2.printStackTrace();
//					}
//					while (true)
//						if (m >= k) {
//							if (this.ZhuBuFlg) {
//								this.flg = false;
//								if (this.flg)
//									break label377;
//								this.nownoteindex = (j + 1);
//							}
//						} else
//
//				}
//				while (true) {
//					try {
//						sleep((long) ((Note) this.bonotes.get(j)).getKeepJiepai() * this.mjiepaitime);
//
//					} catch (InterruptedException localInterruptedException3) {
//						localInterruptedException3.printStackTrace();
//						continue;
//					}
//					i++;
//					addProgress(localNote, i);
//					print(localNote, arrayOfString[0], 1);
//					if (this.ZhuBuFlg) {
//						this.flg = false;
//						break;
//					}
//					try {
//						sleep((long) ((Note) this.bonotes.get(j)).getKeepJiepai() * this.mjiepaitime);
//					} catch (InterruptedException localInterruptedException1) {
//						localInterruptedException1.printStackTrace();
//					}
//				}
//				
//				// continue;
//				
//
//			
//				continue;
			}
		}
	}

	public void setFlg(boolean paramBoolean) {
		this.flg = paramBoolean;
	}

	public void setNownoteindex(int paramInt) {
		this.nownoteindex = paramInt;
	}

	public void showZuoyou(Note paramNote) {
		if (paramNote.getAb() == 0)
			this.ap.handler.obtainMessage(3, paramNote.getZuoyou(),
					(int) (paramNote.getShowJiepai() * (float) this.mjiepaitime)).sendToTarget();
	}

	public void showlocation(Note paramNote) {
		if ((paramNote.getX() == 0) && (paramNote.getY() == 0)) {
			return;
		}
		
		if (paramNote.getAb() == 0) {
			this.ap.handler.obtainMessage(paramNote.getZuoyou(), paramNote.getX(), paramNote.getY()).sendToTarget();
			if (paramNote.getZuoyou() == 1 && !paramNote.getImage().equals(this.ap.nowPhoto)
					&& !"".equals(paramNote.getImage())) {
				int i = Integer.valueOf(paramNote.getImage().replace("PHOTO", "")).intValue();
				this.ap.handler.obtainMessage(4, i, 0).sendToTarget();
			}
		} else {
			if (paramNote.getZuoyou() == 0) {
				this.ap.handler.obtainMessage(10, paramNote.getX(), paramNote.getY()).sendToTarget();
			} else {
				this.ap.handler.obtainMessage(9, paramNote.getX(), paramNote.getY()).sendToTarget();
			}			
		}
	}

	class PlayMusc extends Thread {
		int cd;
		int resourceid;

		PlayMusc(int paramInt1, int arg3) {

			this.cd = arg3;
			this.resourceid = paramInt1;
		}

		public void run() {
			super.run();
			try {
				MediaPlayer localMediaPlayer = MediaPlayer.create(Bofang.this.ap, this.resourceid);
				localMediaPlayer.start();
				sleep(this.cd);
				localMediaPlayer.stop();
				localMediaPlayer.release();
				return;
			} catch (Exception localException) {
				localException.printStackTrace();
			}
		}
	}
}
