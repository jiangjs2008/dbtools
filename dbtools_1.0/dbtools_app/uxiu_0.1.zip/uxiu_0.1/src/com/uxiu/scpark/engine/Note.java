package com.uxiu.scpark.engine;

import java.io.PrintStream;

public class Note {
	private Note PreNote;
	private int ab = 0;
	private String cd = "";
	private String content;
	private String image = "";
	private String intensity = "";
	private int jieIndex = 0;
	private float keepJiepai = 1.0F;
	private String note = "";
	private int noteIndex = 0;
	private int noteNum = 1;
	private String[] notes;
	private float showJiepai = 1.0F;
	private int x = 0;
	private int y = 0;
	private int zuoyou = 0;

	public Note() {
	}

	public Note(String paramString, Note paramNote) {
		System.out.println("content:" + paramString);
		this.content = paramString;
		if ("TABAN ON".equals(paramString) || "TABAN OFF".equals(paramString)) {
			this.notes = new String[1];
			this.notes[0] = paramString;
			this.ab = paramNote.ab;
			this.zuoyou = paramNote.zuoyou;
			this.jieIndex = paramNote.jieIndex;
			this.noteIndex = (1 + paramNote.noteIndex);
			this.keepJiepai = 0.0F;
			this.showJiepai = 0.0F;
			this.noteNum = 1;

		} else {
			String[] arrayOfString1 = paramString.split(",");
			int i = arrayOfString1[0].length();
			if (paramString.charAt(0) == 'R') {
				this.zuoyou = 1;
			}
			if (paramString.charAt(1) == 'B') {
				this.ab = 1;
			}
			this.jieIndex = Integer.valueOf(paramString.substring(2, i)).intValue();
			String[] arrayOfString2 = arrayOfString1[1].split("=");
			this.noteIndex = Integer.valueOf(arrayOfString2[0]).intValue();
			String[] arrayOfString3 = arrayOfString2[1].split("\\+");
			this.intensity = arrayOfString3[0];
			float f1 = Integer.valueOf(arrayOfString3[1].split("/")[0]).intValue();
			float f2 = Integer.valueOf(arrayOfString3[1].split("/")[1]).intValue();
			float f3;
			float f4;
			if (f2 == 0.0F) {
				keepJiepai = f1;
			} else {
				keepJiepai = f1 / f2;
			}
			this.cd = arrayOfString3[2];
			f3 = Integer.valueOf(arrayOfString3[2].split("/")[0]).intValue();
			f4 = Integer.valueOf(arrayOfString3[2].split("/")[1]).intValue();
			if (f4 == 0.0F) {
				this.showJiepai = f3;
			} else {
				this.showJiepai = f3 / f4;
			}
			this.noteNum = Integer.valueOf(arrayOfString3[3]).intValue();
			this.notes = new String[this.noteNum];
			this.notes[0] = arrayOfString3[4];
			if (this.noteNum <= 1) {
				this.image = arrayOfString3[(4 + this.noteNum)];
				this.x = Integer.valueOf(arrayOfString1[2]).intValue();
				this.y = Integer.valueOf(arrayOfString1[3].split("\\+")[0].trim()).intValue();
			} else {
				int j = 1;

				while (j < this.noteNum) {

					if (arrayOfString1[(j + 1)].contains("+")) {

						this.notes[j] = arrayOfString1[(j + 1)].split("\\+")[0];
						this.image = arrayOfString1[(j + 1)].split("\\+")[1];
						this.x = Integer.valueOf(arrayOfString1[(j + 2)]).intValue();
						this.y = Integer.valueOf(arrayOfString1[(j + 3)].split("\\+")[0].trim()).intValue();

					} else {
						this.notes[j] = arrayOfString1[(j + 1)];
					}
					j++;
				}
			}
		}
	}

	private String sendData(String paramString1, String paramString2, String paramString3, int paramInt) {
		if (paramInt == 0) {
			return "ST+L+" + paramString3 + "+" + paramString2 + "+" + paramString1 + "+OV";
		} else {
			return "ST+R+" + paramString3 + "+" + paramString2 + "+" + paramString1 + "+OV";
		}
	}

	public int getAb() {
		return this.ab;
	}

	public String getCd() {
		return this.cd;
	}

	public String getContent() {
		return this.content;
	}

	public String getImage() {
		return this.image;
	}

	public String getIntensity() {
		return this.intensity;
	}

	public int getJieIndex() {
		return this.jieIndex;
	}

	public float getKeepJiepai() {
		return this.keepJiepai;
	}

	public String getNote() {
		return this.note;
	}

	public int getNoteIndex() {
		return this.noteIndex;
	}

	public int getNoteNum() {
		return this.noteNum;
	}

	public String[] getNotes() {
		return this.notes;
	}

	public float getShowJiepai() {
		return this.showJiepai;
	}

	public int getX() {
		return this.x;
	}

	public int getY() {
		return this.y;
	}

	public int getZuoyou() {
		return this.zuoyou;
	}

	public void setAb(int paramInt) {
		this.ab = paramInt;
	}

	public void setCd(String paramString) {
		this.cd = paramString;
	}

	public void setContent(String paramString) {
		this.content = paramString;
	}

	public void setImage(String paramString) {
		this.image = paramString;
	}

	public void setIntensity(String paramString) {
		this.intensity = paramString;
	}

	public void setJieIndex(int paramInt) {
		this.jieIndex = paramInt;
	}

	public void setKeepJiepai(float paramFloat) {
		this.keepJiepai = paramFloat;
	}

	public void setNote(String paramString) {
		this.note = paramString;
	}

	public void setNoteIndex(int paramInt) {
		this.noteIndex = paramInt;
	}

	public void setNoteNum(int paramInt) {
		this.noteNum = paramInt;
	}

	public void setNotes(String[] paramArrayOfString) {
		this.notes = paramArrayOfString;
	}

	public void setShowJiepai(float paramFloat) {
		this.showJiepai = paramFloat;
	}

	public void setX(int paramInt) {
		this.x = paramInt;
	}

	public void setY(int paramInt) {
		this.y = paramInt;
	}

	public void setZuoyou(int paramInt) {
		this.zuoyou = paramInt;
	}
}
