package com.uxiu.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.uxiu.bean.Select1;
import java.io.PrintStream;

public class StudyDataBaseAdapter {
	public static final String DATE = "Date";
	private static final String DB_CREATE = "CREATE TABLE study (_id INTEGER PRIMARY KEY,TrackName TEXT,TrackPath TEXT, Date TEXT)";
	private static final String DB_NAME = "study.db";
	private static final int DB_VERSION = 1;
	public static final String KEY_ID = "_id";
	private static final String TABLE_STUDY = "study";
	public static final String TRACKNAME = "TrackName";
	public static final String TRACKPATH = "TrackPath";
	private Context mContext = null;
	private DatabaseHelper mDatabaseHelper = null;
	private SQLiteDatabase mSQLiteDatabase = null;

	public StudyDataBaseAdapter(Context paramContext) {
		this.mContext = paramContext;
		open();
	}

	public boolean CheckDataByName(String paramString) throws SQLException {
		return this.mSQLiteDatabase.query("study", new String[] { "_id", "TrackName", "TrackPath", "Date" },
				"TrackName='" + paramString + "'", null, null, null, null, null).getCount() > 0;
	}

	public void close() {
		this.mDatabaseHelper.close();
	}

	public boolean deleteData(long paramLong) {
		return this.mSQLiteDatabase.delete("study", "_id=" + paramLong, null) > 0;
	}

	public Cursor fetchAllData() {
		return this.mSQLiteDatabase.query("study", new String[] { "_id", "TrackName", "TrackPath", "Date" }, null,
				null, null, null, "Date desc");
	}

	public Cursor fetchData(long paramLong) throws SQLException {
		Cursor localCursor = this.mSQLiteDatabase.query(true, "study", new String[] { "_id", "TrackName", "TrackPath",
				"Date" }, "_id=" + paramLong, null, null, null, null, null);
		if (localCursor != null)
			localCursor.moveToFirst();
		return localCursor;
	}

	public long insert(Select1 paramSelect1, String paramString) {
		System.out.println("select1.Selectname" + paramSelect1.Selectname);
		if (CheckDataByName(paramSelect1.Selectname)) {
			System.out.println("select2.Selectname" + paramSelect1.Selectname);
			return updateData(paramSelect1, paramString);
		}
		System.out.println("select3.Selectname" + paramSelect1.Selectname);
		return insertData(paramSelect1, paramString);
	}

	public long insertData(Select1 paramSelect1, String paramString) {
		ContentValues localContentValues = new ContentValues();
		localContentValues.put("TrackName", paramSelect1.Selectname);
		localContentValues.put("TrackPath", paramSelect1.Selectpath);
		localContentValues.put("Date", paramString);
		return this.mSQLiteDatabase.insert("study", "_id", localContentValues);
	}

	public void open() throws SQLException {
		this.mDatabaseHelper = new DatabaseHelper(this.mContext);
		this.mSQLiteDatabase = this.mDatabaseHelper.getWritableDatabase();
	}

	public long updateData(Select1 paramSelect1, String paramString) {
		ContentValues localContentValues = new ContentValues();
		localContentValues.put("TrackName", paramSelect1.Selectname);
		localContentValues.put("TrackPath", paramSelect1.Selectpath);
		localContentValues.put("Date", paramString);
		return this.mSQLiteDatabase.update("study", localContentValues, "TrackName='" + paramSelect1.Selectname + "'",
				null);
	}

	private static class DatabaseHelper extends SQLiteOpenHelper {
		DatabaseHelper(Context paramContext) {
			super(paramContext, "study.db", null, 1);
		}

		public void onCreate(SQLiteDatabase paramSQLiteDatabase) {
			paramSQLiteDatabase
					.execSQL("CREATE TABLE study (_id INTEGER PRIMARY KEY,TrackName TEXT,TrackPath TEXT, Date TEXT)");
		}

		public void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2) {
			paramSQLiteDatabase.execSQL("DROP TABLE IF EXISTS notes");
			onCreate(paramSQLiteDatabase);
		}
	}
}
