package com.uxiu.activity;

import java.lang.Thread.UncaughtExceptionHandler;


public interface ExceptionHandler extends UncaughtExceptionHandler {

	public void execute(Throwable ex);

}
