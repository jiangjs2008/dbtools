package com.uxiu.activity;

import android.os.Handler;
import android.os.Message;
import android.widget.ProgressBar;

public class ViewAction extends Thread
{
  ProgressBar ProgressBar;
  Handler handler1 = new Handler()
  {
    public void handleMessage(Message paramAnonymousMessage)
    {
      switch (paramAnonymousMessage.what)
      {
      default:
        return;
      case 0:
      }
      ViewAction.this.ProgressBar.setProgress(paramAnonymousMessage.arg1);
    }
  };
  int max = 0;
  int ran = 10;

  ViewAction(ProgressBar paramProgressBar, int paramInt)
  {
    this.max = paramInt;
    this.ProgressBar = paramProgressBar;
    this.ProgressBar.setMax(paramInt);
  }

  public void run()
  {
    super.run();
    this.ProgressBar.setProgress(0);
    if (this.max <= 0)
      return;
    if (this.max > this.ran);
    while (true)
    {
      try
      {
        sleep(this.ran);
        this.max -= this.ran;
        this.handler1.obtainMessage(0, this.max, -1).sendToTarget();
      }
      catch (InterruptedException localInterruptedException2)
      {
        localInterruptedException2.printStackTrace();
        continue;
      }
      try
      {
        sleep(this.max);
        this.max = 0;
      }
      catch (InterruptedException localInterruptedException1)
      {
        localInterruptedException1.printStackTrace();
      }
    }
  }
}

/* Location:           C:\Downloads\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.uxiu.activity.ViewAction
 * JD-Core Version:    0.6.2
 */