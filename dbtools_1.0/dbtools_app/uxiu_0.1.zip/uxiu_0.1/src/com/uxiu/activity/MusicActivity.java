package com.uxiu.activity;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.usb.UsbManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.uxiu.scpark.engine.LoadData;
import com.uxiu.scpark.engine.Note;
import com.uxiu.scpark.engine.Track;
import com.uxiu.scpark.usbserial.driver.UsbSerialDriver;
import com.uxiu.scpark.usbserial.driver.UsbSerialProber;
import com.uxiu.scpark.usbserial.util.SerialInputOutputManager;
import com.uxiu.scpark.view.SoundView;

public class MusicActivity extends BaseActivity {

	public static final int FLAG_HOMEKEY_DISPATCHED = -2147483648;
	public static final int MusicActivityConnect = 6;
	public static final int MusicActivityMyload = 7;
	public static final int MusicActivityPhotoMsg = 4;
	public static final int MusicActivityPhotoMsg5 = 5;
	public static final int MusicActivitySeekBarumsg = 2;
	public static final int MusicActivityYuoLocationmsg = 1;
	public static final int MusicActivityZuoLocationmsg = 0;
	public static final int MusicActivityZuoyouMsg = 3;
	public static final int MusicBviewZuo = 10;
	public static final int MusicBviewyou = 9;
	public static final int PlayAB = 13;
	private static final int REQUEST_CONNECT_DEVICE = 1;
	public static final int SetSatrtindex = 15;
	public static final int ViewTB1 = 11;
	public static final int ViewTB2 = 12;

	private static Track mtrack;
	ImageButton ButtonAB;
	ImageButton ButtonAdd;
	Button ButtonLast;
	ImageButton ButtonMs;
	Button ButtonNext;
	Button ButtonStart;
	Button ButtonTaobao;
	ImageButton ButtonVoice;
	ImageButton ButtonVoiceFlg;
	ImageButton ButtonYOU;
	ImageButton ButtonZHUOYIN;
	ImageButton ButtonZUO;
	ImageView ImageBViewBlue;
	ImageView ImageBViewRed;
	ImageView ImageViewBlue;
	ImageView ImageViewConn;
	ImageView ImageViewNow;
	ImageView ImageViewPre;
	ImageView ImageViewRed;
	private boolean OnclickAble = false;
	public boolean PlayABFlg = false;
	ProgressBar ProgressBarLeft;
	ProgressBar ProgressBarRight;
	boolean Restart = false;
	int StartAindex = 0;
	int StartBindex = 0;
	public int StartIndex = 1;
	private final String TAG = MusicActivity.class.getSimpleName();
	TextView TextViewAccept;
	TextView TextViewJiepai;
	TextView TextViewTitle;
	float YOffset = 0.8533334F;
	int a = 20;
	Button buttonContents;
	Button buttonshiping;
	//ClickEvent clickEvent;
	public boolean connectflg = true;
	private int currentVolume = 0;
	private View extralSoundView = null;
	File file;
	public boolean flg = true;
	public boolean flgyou = true;
	public boolean flgzuo = true;
	public Handler handler = new Handler() {
		public void handleMessage(Message paramAnonymousMessage) {
			super.handleMessage(paramAnonymousMessage);
			switch (paramAnonymousMessage.what) {

			case 8:
				if (mtrack != null) {
					getApplicationContext().setMaxXiaojie(mtrack.getXiaoJieNum());
					TextViewJiepai.setText(jiepaiMun + "��/����");
					TextViewTitle.setText(file.getName());
					if (temjiepaiMun != 0) {
						jiepaiMun = temjiepaiMun;
						mtrack.setJiepai(jiepaiMun);
						TextViewJiepai.setText(jiepaiMun + "��/����");
					}
					System.out.println("mtrack.getJiepai()" + mtrack.getJiepai());
					seekBar.setMax(max);
					Showphoto(0);
					initSerialDevice();
				}
				OnclickAble = true;
				break;

			case 0:
				break;
			case 1:
				break;
			case 2:
				if (flgzuo) {
					zx = (paramAnonymousMessage.arg1 * YOffset);
					ImageViewRed.setX(18.0F + zx);
					ImageViewRed.setY(paramAnonymousMessage.arg2);
				}
				break;
			case 3:
				if (flgyou) {
					yBx = (paramAnonymousMessage.arg1 * YOffset);
					ImageBViewBlue.setX(18.0F + yBx);
					ImageBViewBlue.setY(paramAnonymousMessage.arg2);
				}
				break;

			case 4:
				seekBar.setProgress(paramAnonymousMessage.arg1);
				if (paramAnonymousMessage.arg1 == max) {
					seekBar.setProgress(0);
					ButtonStart.setBackgroundResource(2130837527);
					flg = true;
					StartIndex = 1;
					mtrack.Clean();
				}
				break;
			case 5:
				nowPhotoIndex = paramAnonymousMessage.arg1 - 1;
				Showphoto(nowPhotoIndex);
				break;

			case 6:
				if (paramAnonymousMessage.obj != null) {
					ShowphotoString(paramAnonymousMessage.obj.toString());
				}
				break;
			case 7:
				if (paramAnonymousMessage.arg1 == 0) {
					ImageViewConn.setImageResource(R.drawable.pic_usb1);
				} else {
					ImageViewConn.setImageResource(R.drawable.pic_usb2);
				}
				break;

			case 9:
				if (flgyou) {
					yx = (paramAnonymousMessage.arg1 * YOffset);
					ImageViewBlue.setX(18.0F + yx);
					ImageViewBlue.setY(paramAnonymousMessage.arg2);
				}
				break;
			case 10:
				if (flgzuo) {
					zx = (paramAnonymousMessage.arg1 * YOffset);
					ImageViewRed.setX(18.0F + zx);
					ImageViewRed.setY(paramAnonymousMessage.arg2);
				}
				break;
			case 11:
				imageViewtb.setImageResource(R.drawable.pic_tb2);
				break;
			case 12:
				imageViewtb.setImageResource(R.drawable.pic_tb1);
				break;
			case 13:

				if (PlayABFlg && !zhuyinflg) {
					mtrack.Pause();
					mtrack.mLAnownoteindex = 0;
					mtrack.mLBnownoteindex = 0;
					mtrack.mRAnownoteindex = 0;
					mtrack.mRBnownoteindex = 0;
					mtrack.Start((MusicActivity) getBaseContext(), StartAindex, StartBindex, false);
					ButtonStart.setBackgroundResource(2130837564);
					flg = false;
				}
				break;

			case 14:
				StartIndex = paramAnonymousMessage.arg1;
				break;

			default:
				break;
			}
		}
	};

	ImageView imageViewtb;
	int inity = 96;
	public int jiepaiMun = 60;
	private AudioManager mAudioManager = null;
	private final ExecutorService mExecutor = Executors.newSingleThreadExecutor();
	private final SerialInputOutputManager.Listener mListener = new SerialInputOutputManager.Listener() {
		public void onNewData(final byte[] paramAnonymousArrayOfByte) {
			runOnUiThread(new Runnable() {
				public void run() {
					updateReceivedData(paramAnonymousArrayOfByte);
				}
			});
		}

		public void onRunError(Exception paramAnonymousException) {
			Log.d(TAG, "Runner stopped.");
		}
	};
	public UsbSerialDriver mSerialDevice;
	private SerialInputOutputManager mSerialIoManager;
	private SoundView mSoundView = null;
	private PopupWindow mSoundWindow = null;
	private UsbManager mUsbManager;
	int max = 0;
	private int maxVolume = 0;
	public String nowPhoto;
	public int nowPhotoIndex = 0;
	public boolean palyusbY = false;
	public boolean palyusbZ = false;
	int plistlength = 0;
	boolean pressDown = false;
	SeekBar seekBar;
	public int temjiepaiMun = 0;
	public boolean voiceflg = true;
	float yBx = 0.0F;
	float yx = 0.0F;
	float zBx = 0.0F;
	boolean zhuyinflg = false;
	float zx = 0.0F;

	private void LoadData() {
		this.plistlength = 0;
		this.file = AppContext.getSelectMusicFile();
		if (file == null || !file.exists()) {
			return;
		}

//		try {
//			Runtime.getRuntime().exec("chmod 777 " + this.file.toString());
//		} catch (IOException localIOException) {
//			localIOException.printStackTrace();
//			Log.e("HCD Download Manager", localIOException.toString());
//		}

		String str = this.file.getAbsolutePath() + "/" + this.file.getName() + ".txt";
		mtrack = new LoadData().GetTrack(str);
		Common.mtrack = mtrack;
		if (mtrack == null) {
			logger.error("can't sound");
		} else {
			initData();
		}
	}

	private void Pause() {
		mtrack.Pause();
		this.StartIndex = mtrack.getXiaojieIndex();
		this.ButtonStart.setBackgroundResource(2130837527);
		this.flg = true;
	}

	private void SendZhuYin() {
		if ((this.flgzuo) && (!this.flgyou))
			if (!this.palyusbZ) {
				return;
			}
		while (true) {
			this.palyusbZ = false;
			this.palyusbY = false;
			this.ButtonStart.setBackgroundResource(2130837527);
			this.flg = true;

			mtrack.Start(this, this.StartIndex, mtrack.getXiaoJieNum(), true);
			mtrack.Pause1();

			if ((!this.flgzuo) && (this.flgyou)) {
				while (!this.palyusbY) {
					mtrack.Start(this, this.StartIndex, mtrack.getXiaoJieNum(), true);
					mtrack.Pause1();
				}
			} else if ((this.flgzuo) && (this.flgyou)) {
				mtrack.Pause();
				mtrack.Start(this, this.StartIndex, mtrack.getXiaoJieNum(), true);
			}
		}
	}

	private void SendZhuYinAndAB(int paramInt1, int paramInt2) {
		mtrack.Pause();
		mtrack.Start(this, paramInt1, paramInt2, true);
		this.ButtonStart.setBackgroundResource(2130837527);
		this.flg = true;
	}

	private void Start() {
		System.out.println("max:______" + this.max);
		System.out.println("StartIndex:______" + this.StartIndex);
		if (this.StartIndex >= mtrack.getXiaoJieNum())
			this.StartIndex = 1;
		this.ImageViewBlue.setVisibility(0);
		this.ImageViewRed.setVisibility(0);
		mtrack.Start(this, this.StartIndex, mtrack.getXiaoJieNum(), false);
		this.ButtonStart.setBackgroundResource(2130837564);
		this.flg = false;
	}

	private void Start(boolean paramBoolean) {
		mtrack.Pause();
		this.StartIndex = mtrack.getXiaojieIndex();
		mtrack.Start(this, this.StartIndex, this.StartBindex, false);
		this.ButtonStart.setBackgroundResource(2130837564);
		this.flg = false;
	}

	private void initData() {
		this.max = 0;
		this.jiepaiMun = mtrack.getJiepai();
		int i = mtrack.getLAnotes().size();
		for (int j = 0;; j++) {
			if (j >= i) {
				this.plistlength = mtrack.getPhtoList().size();
				return;
			}
			this.max += ((Note) mtrack.getLAnotes().get(j)).getNotes().length;
		}
	}

	private void initView() {
		this.ImageViewRed = ((ImageView) findViewById(2131296295));
		this.ImageViewBlue = ((ImageView) findViewById(2131296296));
		this.ImageBViewRed = ((ImageView) findViewById(2131296297));
		this.ImageBViewBlue = ((ImageView) findViewById(2131296298));
		this.ImageViewConn = ((ImageView) findViewById(2131296267));
		this.imageViewtb = ((ImageView) findViewById(2131296303));
		this.ImageViewRed.setX(15.0F);
		this.ImageViewRed.setY(180.0F);
		this.ImageViewBlue.setX(10.0F);
		this.ImageViewBlue.setY(90.0F);
		this.ButtonVoice = ((ImageButton) findViewById(2131296313));
		this.ImageViewNow = ((ImageView) findViewById(2131296294));
		this.ImageViewPre = ((ImageView) findViewById(2131296306));
		this.ButtonVoiceFlg = ((ImageButton) findViewById(2131296312));
		this.ButtonStart = ((Button) findViewById(2131296310));
		this.ButtonAdd = ((ImageButton) findViewById(2131296292));
		this.ButtonMs = ((ImageButton) findViewById(2131296290));
		this.seekBar = ((SeekBar) findViewById(2131296305));

		this.ButtonLast = ((Button) findViewById(2131296309));
		this.ButtonNext = ((Button) findViewById(2131296311));
//		this.ButtonNext.setOnClickListener(this.clickEvent);
//		this.ButtonLast.setOnClickListener(this.clickEvent);
//		this.ButtonStart.setOnClickListener(this.clickEvent);
//		this.ButtonMs.setOnClickListener(this.clickEvent);
//		this.ButtonAdd.setOnClickListener(this.clickEvent);
//		this.ButtonVoiceFlg.setOnClickListener(this.clickEvent);
		this.TextViewTitle = ((TextView) findViewById(2131296289));
		this.TextViewJiepai = ((TextView) findViewById(2131296291));
		this.ProgressBarLeft = ((ProgressBar) findViewById(2131296300));
		this.ProgressBarRight = ((ProgressBar) findViewById(2131296301));
		this.buttonshiping = ((Button) findViewById(2131296283));
		this.buttonContents = ((Button) findViewById(2131296284));
		this.ButtonTaobao = ((Button) findViewById(2131296285));
//		this.ButtonTaobao.setOnClickListener(this.clickEvent);
//		this.buttonContents.setOnClickListener(this.clickEvent);
//		this.buttonshiping.setOnClickListener(this.clickEvent);
		this.ButtonZUO = ((ImageButton) findViewById(2131296302));
		this.ButtonYOU = ((ImageButton) findViewById(2131296304));
		this.ButtonZHUOYIN = ((ImageButton) findViewById(2131296308));
//		this.ButtonZUO.setOnClickListener(this.clickEvent);
//		this.ButtonYOU.setOnClickListener(this.clickEvent);
//		this.ButtonZHUOYIN.setOnClickListener(this.clickEvent);
		this.TextViewAccept = ((TextView) findViewById(2131296288));
		this.ButtonAB = ((ImageButton) findViewById(2131296307));
//		this.ButtonAB.setOnClickListener(this.clickEvent);
	}

	private void onDeviceStateChange() {
		stopIoManager();
		startIoManager();
	}

	private void startIoManager() {
		if (this.mSerialDevice != null) {
			Log.i(this.TAG, "Starting io manager ..");
			this.mSerialIoManager = new SerialInputOutputManager(this.mSerialDevice, this.mListener);
			this.mExecutor.submit(this.mSerialIoManager);
		}
	}

	private void stopIoManager() {
		if (this.mSerialIoManager != null) {
			Log.i(this.TAG, "Stopping io manager ..");
			this.mSerialIoManager.stop();
			this.mSerialIoManager = null;
		}
	}

	public void InitPhoto(String s, String s1) {
		System.out.println((new StringBuilder("now")).append(s).append("next").append(s1).toString());
		if (s == null || "".equals(s)) {
			
			if (s == null) {
				ImageViewNow.setImageResource(R.drawable.track_youxiu);
			}
			
		} else {
			String s3 = new StringBuilder(file.getAbsolutePath()).append("/").append(file.getName()).append("/").append(s).append(".bmp").toString();

			android.graphics.Bitmap bitmap2 = BitmapFactory.decodeFile(s3);
			ImageViewNow.setImageBitmap(bitmap2);
			
			if (s1 == null || "".equals(s1)) {
				if ("null".equals(s1)) {
					System.out.println(new StringBuilder("next1:").append(s1).toString());
					android.graphics.Bitmap bitmap = BitmapFactory.decodeResource(getResources(), 0x7f020056);
					ImageViewPre.setImageBitmap(bitmap);
					return;
				}
			} else {
				String s2 = new StringBuilder(file.getAbsolutePath()).append("/").append(file.getName()).append("/").append(s1).append(".bmp").toString();
				System.out.println(s2);
				android.graphics.Bitmap bitmap1 = BitmapFactory.decodeFile(s2);
				ImageViewPre.setAlpha(50);
				ImageViewPre.setImageBitmap(bitmap1);
				return;
			}
		}
	}

	public void Showphoto(int paramInt) {
		if (paramInt < 0) {
			if (paramInt >= plistlength || paramInt + 1 < plistlength) {
				return;
			}

			nowPhoto = (String) mtrack.getPhtoList().get(paramInt);
			InitPhoto(nowPhoto, null);
			nowPhotoIndex = paramInt;

			InitPhoto(null, null);

		} else {
			if (paramInt >= this.plistlength || paramInt + 1 >= this.plistlength) {
				if (paramInt >= plistlength || paramInt + 1 < plistlength) {
					return;
				}

				nowPhoto = (String) mtrack.getPhtoList().get(paramInt);
				InitPhoto(nowPhoto, null);
				nowPhotoIndex = paramInt;

				InitPhoto(null, null);

			} else {
				this.nowPhoto = ((String) mtrack.getPhtoList().get(paramInt));
				InitPhoto(this.nowPhoto, (String) mtrack.getPhtoList().get(paramInt + 1));
				this.nowPhotoIndex = paramInt;
			}
		}
	}

	public void ShowphotoString(String paramString) {
		int i = mtrack.getPhtoList().indexOf(paramString);
		Showphoto(i);
	}

	public void ZuoyouProgressBar(int paramInt1, int paramInt2) {
		if (paramInt1 == 0)
			if (this.flgzuo)
				new ViewAction(this.ProgressBarLeft, paramInt2).start();
		while (!this.flgyou)
			return;
		new ViewAction(this.ProgressBarRight, paramInt2).start();
	}

	public void finish() {
		super.finish();
		this.PlayABFlg = false;
		if (mtrack != null) {
			mtrack.Pause();
			mtrack.Clean();
		}
	}

	public Common getApplicationContext() {
		return (Common) super.getApplicationContext();
	}

	void initSerialDevice() {
		this.mSerialDevice = UsbSerialProber.acquire(this.mUsbManager);
		Log.d(this.TAG, "Resumed, mSerialDevice=" + this.mSerialDevice);
		if (this.mSerialDevice == null) {
			return;
		}
		try {
			this.mSerialDevice.open();
			if (mtrack != null) {
				sendjiepai(mtrack.getJiepai());
				onDeviceStateChange();
				return;
			}
		} catch (IOException localIOException1) {
			Log.e(this.TAG, "Error setting up device: " + localIOException1.getMessage(), localIOException1);
		} finally {
			try {
				this.mSerialDevice.close();
			} catch (IOException localIOException2) {
				 this.mSerialDevice = null;
			}
		}

	}

	public void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
		switch (paramInt1) {
		default:
		case 1:
		}
//		do
//			return;
//		while (paramInt2 != -1);
		mtrack.Pause();
		this.PlayABFlg = true;
		this.ButtonAB.setBackgroundResource(2130837526);
		int i = paramIntent.getExtras().getInt("startA");
		int j = paramIntent.getExtras().getInt("endB");
		mtrack.mLAnownoteindex = 0;
		mtrack.mLBnownoteindex = 0;
		mtrack.mRAnownoteindex = 0;
		mtrack.mRBnownoteindex = 0;
		this.StartAindex = i;
		this.StartBindex = j;
		mtrack.Start(this, i, j, false);
		mtrack.setJiepai(this.jiepaiMun);
		this.ButtonStart.setBackgroundResource(2130837564);
		this.flg = false;
	}

	@Override
	protected void onCreate(Bundle paramBundle) {
		AppContext.setCurrActivity(this);
		super.onCreate(paramBundle);
		requestWindowFeature(1);
		getWindow().setFlags(128, 128);
		getWindow().setFlags(-2147483648, -2147483648);
		setContentView(R.layout.main);
		this.mUsbManager = ((UsbManager) getSystemService("usb"));

		initView();
		LoadData();
		if (mtrack != null) {
			getApplicationContext().setMaxXiaojie(mtrack.getXiaoJieNum());
			TextViewJiepai.setText(this.jiepaiMun + "��/����");
			TextViewTitle.setText(this.file.getName());
			if (temjiepaiMun != 0) {
				jiepaiMun = this.temjiepaiMun;
				mtrack.setJiepai(this.jiepaiMun);
				TextViewJiepai.setText(this.jiepaiMun + "��/����");
			}

			seekBar.setMax(this.max);
			Showphoto(0);
			initSerialDevice();
		}
		this.OnclickAble = true;
	}

//	@Override
//	public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
//		if (paramInt == 4)
//			toOtherActivity(SelectActivity.class, 3);
//		while (paramInt == 82)
//			return false;
//		return super.onKeyDown(paramInt, paramKeyEvent);
//	}

	@Override
	protected void onPause() {
		super.onPause();
		stopIoManager();
		if (this.mSerialDevice == null) {
			return;
		}
		try {
			this.mSerialDevice.close();
		} catch (IOException localIOException) {
			this.mSerialDevice = null;
		}
	}

	protected void onRestart() {
		super.onRestart();
		this.Restart = true;
	}

	protected void onResume() {
		super.onResume();
		if (this.Restart) {
			getApplicationContext();
			mtrack = Common.mtrack;
			initSerialDevice();
			return;
		}
	}

	protected void onStop() {
		super.onStop();
		System.out.println("--------onStop----------------");
		this.PlayABFlg = false;
		this.ButtonAB.setBackgroundResource(2130837524);
		if (mtrack != null) {
			System.out.println("--------onStop--1--------------");
			mtrack.Pause();
			mtrack.Clean();
		}
	}

	public void onWindowFocusChanged(boolean paramBoolean) {
		super.onWindowFocusChanged(paramBoolean);
		this.inity = this.ButtonMs.getHeight();
		this.buttonshiping.getHeight();
		this.ImageViewRed.setX(10.0F);
		this.ImageViewRed.setY(180.0F);
		this.ImageViewBlue.setX(10.0F);
		this.ImageViewBlue.setY(90.0F);
	}

	void sendjiepai(int paramInt) {
		String str = "ST+JP=" + 60000 / paramInt + "M+OV" + "\n";
		System.out.println("abc" + paramInt);
		try {
			this.mSerialDevice.write(str.getBytes(), 5);
			this.ImageViewConn.setImageResource(2130837568);
			return;
		} catch (Exception localException) {
			localException.printStackTrace();
			this.ImageViewConn.setImageResource(2130837567);
		}
	}

	void toOtherActivity(Class<?> paramClass, int paramInt) {
		Intent localIntent = new Intent();
		localIntent.setClass(this, paramClass);
		localIntent.putExtra("ViewID", paramInt);
		if (paramInt != 4) {
			startActivity(localIntent);
			finish();
			return;
		}
		startActivityForResult(localIntent, 1);
	}

	public void updateReceivedData(byte[] paramArrayOfByte) {
//		String str;
//		if (paramArrayOfByte.length > 0) {
//			str = new String(paramArrayOfByte);
//			this.TextViewAccept.setText(str);
//			if (!Constant.FW.equals(str))
//				break label411;
//			if ((!this.zhuyinflg) || (this.PlayABFlg))
//				break label51;
//			SendZhuYin();
//		}
//		label51: do {
//			do {
//				do {
//					return;
//					if ((!this.zhuyinflg) && (!this.PlayABFlg)) {
//						if (this.flg) {
//							Start();
//							return;
//						}
//						mtrack.Pause();
//						this.StartIndex = mtrack.getXiaojieIndex();
//						this.StartIndex = (1 + this.StartIndex);
//						if (this.StartIndex > mtrack.getXiaoJieNum())
//							this.StartIndex = mtrack.getXiaoJieNum();
//						mtrack.mLAnownoteindex = 0;
//						mtrack.mLBnownoteindex = 0;
//						mtrack.mRAnownoteindex = 0;
//						mtrack.mRBnownoteindex = 0;
//						mtrack.Start(this, this.StartIndex, mtrack.getXiaoJieNum(), false);
//						this.ButtonStart.setBackgroundResource(2130837564);
//						this.flg = false;
//						return;
//					}
//					if ((this.zhuyinflg) && (this.PlayABFlg)) {
//						this.StartIndex = mtrack.getXiaojieIndex();
//						if (this.StartIndex > mtrack.getXiaoJieNum())
//							this.StartIndex = mtrack.getXiaoJieNum();
//						if (this.StartIndex > this.StartBindex)
//							this.StartIndex = this.StartAindex;
//						SendZhuYinAndAB(this.StartIndex, this.StartBindex);
//						return;
//					}
//				} while ((this.zhuyinflg) || (!this.PlayABFlg));
//				mtrack.Pause();
//				this.StartIndex = mtrack.getXiaojieIndex();
//				this.StartIndex = (1 + this.StartIndex);
//				if (this.StartIndex > mtrack.getXiaoJieNum())
//					this.StartIndex = mtrack.getXiaoJieNum();
//				mtrack.mLAnownoteindex = 0;
//				mtrack.mLBnownoteindex = 0;
//				mtrack.mRAnownoteindex = 0;
//				mtrack.mRBnownoteindex = 0;
//				if (this.StartIndex > this.StartBindex)
//					this.StartIndex = this.StartAindex;
//				mtrack.Start(ap, this.StartIndex, this.StartBindex, false);
//				this.ButtonStart.setBackgroundResource(2130837564);
//				this.flg = false;
//				return;
//			} while (!Constant.BK.equals(str));
//			if ((!this.zhuyinflg) && (!this.PlayABFlg)) {
//				mtrack.Pause();
//				this.StartIndex = mtrack.getXiaojieIndex();
//				this.StartIndex = (-1 + this.StartIndex);
//				if (this.StartIndex <= 0)
//					this.StartIndex = 1;
//				mtrack.mLAnownoteindex = 0;
//				mtrack.mLBnownoteindex = 0;
//				mtrack.mRAnownoteindex = 0;
//				mtrack.mRBnownoteindex = 0;
//				System.out.println("StartIndexStartIndexStartIndexStartIndexStartIndex" + this.StartIndex);
//				mtrack.Start(ap, this.StartIndex, mtrack.getXiaoJieNum(), false);
//				this.ButtonStart.setBackgroundResource(2130837564);
//				this.flg = false;
//				return;
//			}
//		} while (!this.PlayABFlg);
//		label411: mtrack.Pause();
//		this.StartIndex = mtrack.getXiaojieIndex();
//		this.StartIndex = (-1 + this.StartIndex);
//		if (this.StartIndex <= 0)
//			this.StartIndex = 1;
//		mtrack.mLAnownoteindex = 0;
//		mtrack.mLBnownoteindex = 0;
//		mtrack.mRAnownoteindex = 0;
//		mtrack.mRBnownoteindex = 0;
//		if (this.StartIndex < this.StartAindex)
//			this.StartIndex = this.StartAindex;
//		mtrack.Start(ap, this.StartIndex, this.StartBindex, false);
//		this.ButtonStart.setBackgroundResource(2130837564);
//		this.flg = false;
	}

	/**
	 * ���水ť�����¼�����
	 *
	 * @param v ���水ť����
	 */
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.ButtonStart :
			// ����/��ͣ
			if (this.flg) {
				this.Start();
				return;
			} else {
				this.Pause();
			}
			break;
		
		case R.id.ButtonLast :
			// ��������һ��
			
			
			break;
			
		case R.id.ButtonNext :
			// ǰ������һ��
			
			
			break;

		case R.id.ButtonMs :
			// ������Ƶ�����ٶ� - ����
			MusicActivity localMusicActivity8 = this;
			localMusicActivity8.jiepaiMun = (-1 + localMusicActivity8.jiepaiMun);
			if (this.jiepaiMun <= 0)
				this.jiepaiMun = 1;
			this.temjiepaiMun = this.jiepaiMun;
			mtrack.setJiepai(this.jiepaiMun);
			this.sendjiepai(mtrack.getJiepai());

			this.TextViewJiepai.setText(this.jiepaiMun + "��/����");
			break;

		case R.id.ButtonAdd :
			// ������Ƶ�����ٶ� - ����
			MusicActivity localMusicActivity7 = this;
			localMusicActivity7.jiepaiMun = (1 + localMusicActivity7.jiepaiMun);
			if (this.jiepaiMun > 300)
				this.jiepaiMun = 300;
			this.temjiepaiMun = this.jiepaiMun;
			mtrack.setJiepai(this.jiepaiMun);
			this.sendjiepai(mtrack.getJiepai());
			System.out.println("jiepaiMunjiepaiM111unjiepaiMunViewJiepai"
					+ this.jiepaiMun);
			this.TextViewJiepai.setText(this.jiepaiMun + "��/����");
			break;

		case R.id.buttonshiping :
			// ���Ÿ���Ŀ����Ƶ
			this.toOtherActivity(VideoPlayerActivity.class, 3);
			this.finish();
			break;

		case R.id.buttonContents :
			// �ص���Ŀѡ����
			this.toOtherActivity(SelectActivity.class, 3);
			break;

		case R.id.ButtonTaobao :
			// ת���Ա���ҳ
			Intent localIntent = new Intent();
			localIntent.setAction("android.intent.action.VIEW");
			localIntent.setData(Uri.parse("http://ushowpiano.taobao.com/"));
			this.startActivity(localIntent);
			break;

		case R.id.ButtonZUO :
			// �������ֵ������
			if (this.flgzuo) {
				this.ButtonZUO.setBackgroundResource(2130837543);
				this.flgzuo = false;
				return;
			}
			this.flgzuo = true;
			this.ButtonZUO.setBackgroundResource(2130837544);
			return;

		case R.id.ButtonYOU :
			// �������ֵ������
			if (this.flgyou) {
				this.flgyou = false;
				this.ButtonYOU.setBackgroundResource(2130837553);
				return;
			}
			this.flgyou = true;
			this.ButtonYOU.setBackgroundResource(2130837554);
			return;

		case R.id.ButtonZHUOYIN :
			// ������ڲ���
			MusicActivity localMusicActivity2;
			boolean bool4;
			if (this.zhuyinflg) {
				this.ButtonLast.setClickable(true);
				this.ButtonStart.setClickable(true);
				this.ButtonZHUOYIN.setBackgroundResource(2130837575);
				localMusicActivity2 = this;
				boolean bool3 = this.zhuyinflg;
				bool4 = false;
//				if (!bool3)
//					break label1671;
			}
			while (true) {
			//	localMusicActivity2.zhuyinflg = bool4;
				//return;
				this.ButtonZHUOYIN.setBackgroundResource(2130837576);
				this.ButtonLast.setClickable(false);
				this.ButtonStart.setClickable(false);
				mtrack.Pause();
				this.StartIndex = mtrack.getXiaojieIndex();
				this.ButtonStart.setBackgroundResource(2130837527);
				this.flg = true;
			//	break;
				bool4 = true;
			}

		case R.id.ButtonAB :
			// ABѭ������
			if (!this.PlayABFlg) {
				mtrack.Pause();
				this.ButtonStart.setBackgroundResource(2130837527);
				this.flg = true;
				this.getApplicationContext().setNowXiaojie(this.StartIndex);
				this.toOtherActivity(ABActivity.class, 4);
				return;
			}
			this.PlayABFlg = false;
			this.ButtonAB.setBackgroundResource(2130837524);
			return;

		case R.id.ButtonVoiceFlg :
			// �������� - ����/����
			
			
			break;
		
		default :
			break;
		}
//							if (paramView != this.ButtonLast)
//								break;
//							if ((!this.zhuyinflg) && (!this.PlayABFlg)) {
//								mtrack.Pause();
//								this.StartIndex = mtrack.getXiaojieIndex();
//								MusicActivity localMusicActivity6 = this;
//								localMusicActivity6.StartIndex = (-1 + localMusicActivity6.StartIndex);
//								if (this.StartIndex <= 0)
//									this.StartIndex = 1;
//								mtrack.mLAnownoteindex = 0;
//								mtrack.mLBnownoteindex = 0;
//								mtrack.mRAnownoteindex = 0;
//								mtrack.mRBnownoteindex = 0;
//								System.out.println("StartIndexStartIndexStartIndexStartIndexStartIndex"
//										+ this.StartIndex);
//								mtrack.Start(ap, this.StartIndex,
//										mtrack.getXiaoJieNum(), false);
//								this.ButtonStart.setBackgroundResource(2130837564);
//								this.flg = false;
//								return;
//							}
//						} while (!this.PlayABFlg);
//						mtrack.Pause();
//						this.StartIndex = mtrack.getXiaojieIndex();
//						MusicActivity localMusicActivity5 = this;
//						localMusicActivity5.StartIndex = (-1 + localMusicActivity5.StartIndex);
//						if (this.StartIndex <= 0)
//							this.StartIndex = 1;
//						mtrack.mLAnownoteindex = 0;
//						mtrack.mLBnownoteindex = 0;
//						mtrack.mRAnownoteindex = 0;
//						mtrack.mRBnownoteindex = 0;
//						if (this.StartIndex < this.StartAindex)
//							this.StartIndex = this.StartAindex;
//						mtrack.Start(ap, this.StartIndex,
//								this.StartBindex, false);
//						this.ButtonStart.setBackgroundResource(2130837564);
//						this.flg = false;
//						//return;
//						if (paramView != this.ButtonNext)
//							break;
//						if ((this.zhuyinflg) && (!this.PlayABFlg)) {
//							System.out.println("------------dianji---------------");
//							this.SendZhuYin();
//							return;
//						}
//						if ((!this.zhuyinflg) && (!this.PlayABFlg)) {
//							mtrack.Pause();
//							this.StartIndex = mtrack.getXiaojieIndex();
//							MusicActivity localMusicActivity4 = this;
//							localMusicActivity4.StartIndex = (1 + localMusicActivity4.StartIndex);
//							if (this.StartIndex > mtrack.getXiaoJieNum())
//								this.StartIndex = mtrack.getXiaoJieNum();
//							mtrack.mLAnownoteindex = 0;
//							mtrack.mLBnownoteindex = 0;
//							mtrack.mRAnownoteindex = 0;
//							mtrack.mRBnownoteindex = 0;
//							System.out.println("StartIndexStartIndexStartIndexStartIndexStartIndex"
//									+ this.StartIndex);
//							mtrack.Start(ap, this.StartIndex,
//									mtrack.getXiaoJieNum(), false);
//							this.ButtonStart.setBackgroundResource(2130837564);
//							this.flg = false;
//							return;
//						}
//						if ((!this.zhuyinflg) && (this.PlayABFlg)) {
//							mtrack.Pause();
//							this.StartIndex = mtrack.getXiaojieIndex();
//							MusicActivity localMusicActivity3 = this;
//							localMusicActivity3.StartIndex = (1 + localMusicActivity3.StartIndex);
//							if (this.StartIndex > mtrack.getXiaoJieNum())
//								this.StartIndex = mtrack.getXiaoJieNum();
//							mtrack.mLAnownoteindex = 0;
//							mtrack.mLBnownoteindex = 0;
//							mtrack.mRAnownoteindex = 0;
//							mtrack.mRBnownoteindex = 0;
//							if (this.StartIndex > this.StartBindex)
//								this.StartIndex = this.StartAindex;
//							mtrack.Start(ap, this.StartIndex,
//									this.StartBindex, false);
//							this.ButtonStart.setBackgroundResource(2130837564);
//							this.flg = false;
//							return;
//						}
//					} while ((!this.zhuyinflg) || (!this.PlayABFlg));
//					this.StartIndex = mtrack.getXiaojieIndex();
//					if (this.StartIndex > mtrack.getXiaoJieNum())
//						this.StartIndex = mtrack.getXiaoJieNum();
//					if (this.StartIndex > this.StartBindex)
//						this.StartIndex = this.StartAindex;
//					this.SendZhuYinAndAB(this.StartIndex, this.StartBindex);
//					//return;
//
//
//				} while (paramView != this.ButtonVoiceFlg);
//				MusicActivity localMusicActivity1;
//				boolean bool2;
//				if (this.voiceflg) {
//					this.ButtonVoiceFlg.setBackgroundResource(2130837560);
//					localMusicActivity1 = this;
//					boolean bool1 = this.voiceflg;
//					bool2 = false;
//					if (!bool1) {
//					//	break label1857;
//					}
//				}
//				while (true) {
//					//localMusicActivity1.voiceflg = bool2;
//				//	return;
//					this.ButtonVoiceFlg.setBackgroundResource(2130837559);
//					//break;
//					//label1857: bool2 = true;
//				}
//			}
			//Toast.makeText(this, "�ȴ������SD����ȡ����", 3);

	}


	class UpdateJiepai extends Thread {
		boolean flg = true;

		UpdateJiepai(boolean arg2) {
			this.flg = arg2;
		}

		public void run() {
			super.run();
			while (true) {
				if (!pressDown)
					return;
				try {
					sleep(100L);
				} catch (InterruptedException localInterruptedException) {
					localInterruptedException.printStackTrace();
				}
			}
		}
	}
}
