package com.uxiu.activity;

import java.util.LinkedList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

public class VideoChooseActivity extends Activity
{
  private static int height;
  private static int width;
  private LayoutInflater mInflater;
  private LinkedList<VideoPlayerActivity.MovieInfo> mLinkedList;
  View root;

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    getWindow().requestFeature(1);
    setContentView(2130903044);
    this.mLinkedList = VideoPlayerActivity.playList;
    this.mInflater = getLayoutInflater();
    ((ImageButton)findViewById(2131296277)).setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        VideoChooseActivity.this.finish();
      }
    });
    ListView localListView = (ListView)findViewById(2131296278);
    localListView.setAdapter(new BaseAdapter()
    {
      public int getCount()
      {
        return VideoChooseActivity.this.mLinkedList.size();
      }

      public Object getItem(int paramAnonymousInt)
      {
        return Integer.valueOf(paramAnonymousInt);
      }

      public long getItemId(int paramAnonymousInt)
      {
        return paramAnonymousInt;
      }

      public View getView(int paramAnonymousInt, View paramAnonymousView, ViewGroup paramAnonymousViewGroup)
      {
        if (paramAnonymousView == null)
          paramAnonymousView = VideoChooseActivity.this.mInflater.inflate(2130903047, null);
        ((TextView)paramAnonymousView.findViewById(2131296287)).setText(((VideoPlayerActivity.MovieInfo)VideoChooseActivity.this.mLinkedList.get(paramAnonymousInt)).displayName);
        return paramAnonymousView;
      }
    });
    localListView.setOnItemClickListener(new AdapterView.OnItemClickListener()
    {
      public void onItemClick(AdapterView<?> paramAnonymousAdapterView, View paramAnonymousView, int paramAnonymousInt, long paramAnonymousLong)
      {
        Intent localIntent = new Intent();
        localIntent.putExtra("CHOOSE", paramAnonymousInt);
        VideoChooseActivity.this.setResult(-1, localIntent);
        VideoChooseActivity.this.finish();
      }
    });
  }
}

/* Location:           C:\Downloads\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.uxiu.activity.VideoChooseActivity
 * JD-Core Version:    0.6.2
 */