package com.uxiu.activity;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.hardware.usb.UsbManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.MessageQueue;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Display;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.SeekBar;
import android.widget.TextView;

import com.uxiu.scpark.usbserial.driver.UsbSerialDriver;
import com.uxiu.scpark.usbserial.driver.UsbSerialProber;
import com.uxiu.scpark.usbserial.util.Constant;
import com.uxiu.scpark.usbserial.util.SerialInputOutputManager;
import com.uxiu.scpark.view.RangeSeekBar;
import com.uxiu.scpark.view.SoundView;
import com.uxiu.scpark.view.VideoView;

public class VideoPlayerActivity extends Activity
{
  private static final int HIDE_CONTROLER = 1;
  private static final int PROGRESS_CHANGED = 0;
  private static final int SCREEN_DEFAULT = 1;
  private static final int SCREEN_FULL = 0;
  private static final int TIME = 6868;
  private static int controlHeight = 0;
  public static LinkedList<MovieInfo> playList = new LinkedList();
  private static int position;
  private static int screenHeight;
  private static int screenWidth = 0;
  RangeSeekBar<Integer> ABseekBar = null;
  private ImageView ImageViewConn = null;
  private final String TAG = VideoPlayerActivity.class.getSimpleName();
  private TextView TextViewPeiShu = null;
  private LinearLayout abSelectBar = null;
  private boolean backFlg = false;
  private ImageButton bn1 = null;
  private ImageButton bn2 = null;
  private ImageButton bn3 = null;
  private ImageButton bn4 = null;
  private ImageButton bn5 = null;
  private Button buttonAB = null;
  private Button buttonADD = null;
  private Button buttonRec = null;
  public boolean connectflg = true;
  private View controlView = null;
  private PopupWindow controler = null;
  private int currentVolume = 0;
  private TextView durationTextView = null;
  private View extralSoundView = null;
  private View extralView = null;
  private PopupWindow extralWindow = null;
  private boolean isAbBarShow = false;
  private boolean isBack = false;
  private boolean isControllerShow = true;
  private boolean isFW = false;
  private boolean isFullScreen = false;
  private boolean isPaused = false;
  private boolean isSilent = false;
  private boolean isSoundShow = false;
  private int last = 0;
  private AudioManager mAudioManager = null;
  private final ExecutorService mExecutor = Executors.newSingleThreadExecutor();
  private GestureDetector mGestureDetector = null;
  private final SerialInputOutputManager.Listener mListener = new SerialInputOutputManager.Listener()
  {
    public void onNewData(final byte[] paramAnonymousArrayOfByte)
    {
      runOnUiThread(new Runnable()
      {
        public void run()
        {
          updateReceivedData(paramAnonymousArrayOfByte);
        }
      });
    }

    public void onRunError(Exception paramAnonymousException)
    {
     // Log.d(TAG, "Runner stopped.");
    }
  };
  public UsbSerialDriver mSerialDevice;
  private SerialInputOutputManager mSerialIoManager;
  private SoundView mSoundView = null;
  private PopupWindow mSoundWindow = null;
  private UsbManager mUsbManager;
  private int maxVolume = 0;
  Handler myHandler = new Handler()
  {
    public void handleMessage(Message paramAnonymousMessage)
    {
      switch (paramAnonymousMessage.what)
      {
      case 2:
      default:
      case 0:
      case 1:
      case 3:
      case 4:
      }
      while (true)
      {
        super.handleMessage(paramAnonymousMessage);
        //return;
        int i1 = vv.getCurrentPosition();
        if (((i1 != seekbarHasplayed) && (i1 > last)) || (isBack))
        {
          seekBar.setProgress(i1);
          last = i1;
          int i2 = i1 / 1000;
          int i3 = i2 / 60;
          i3 =  (i3 / 60);
          int i4 = i2 % 60;
          int i5 = i3 % 60;
          TextView localTextView2 = playedTextView;
          Object[] arrayOfObject2 = new Object[2];
          arrayOfObject2[0] = Integer.valueOf(i5);
          arrayOfObject2[1] = Integer.valueOf(i4);
          localTextView2.setText(String.format("%02d:%02d", arrayOfObject2));
        }
        sendEmptyMessage(0);
      //  continue;
        hideController();
       // continue;
        try
        {
          last = 0;
          System.out.println("playlistsize:" + playlistsize);
          System.out.println("videopathString():" + videopathString);
          if (playlistsize > 0)
            vv.setVideoPath(videopathString);
          if ((controler != null) && (vv.isShown()))
          {
            controler.showAtLocation(vv, 80, 0, 0);
            controler.update(0, 0, VideoPlayerActivity.screenWidth, VideoPlayerActivity.controlHeight);
          }
          if ((extralWindow == null) || (!vv.isShown()))
            continue;
          extralWindow.showAtLocation(vv, 48, 0, 0);
          extralWindow.update(0, 0, VideoPlayerActivity.screenWidth, 50);
        }
        catch (Exception localException)
        {
        }
     //   continue;
        int i = paramAnonymousMessage.arg1;
        last = (i - 10);
        seekBar.setProgress(i);
        int j = i / 1000;
        int k = j / 60;
       // (k / 60);
        int m = j % 60;
        int n = k % 60;
        TextView localTextView1 = playedTextView;
        Object[] arrayOfObject1 = new Object[2];
        arrayOfObject1[0] = Integer.valueOf(n);
        arrayOfObject1[1] = Integer.valueOf(m);
        localTextView1.setText(String.format("%02d:%02d", arrayOfObject1));
      }
    }
  };
  private int mymaxValue = 0;
  private int myminValue = 0;
  private TextView playedTextView = null;
  private int playedTime;
  int playlistsize = 0;
  private SeekBar seekBar = null;
  private int seekbarHasplayed = 0;
  private double size = 1.0D;
  private Uri videoListUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
  String videopathString = null;
  private VideoView vv = null;

  static
  {
    screenHeight = 0;
  }

  private void cancelDelayHide()
  {
    myHandler.removeMessages(1);
  }

  private int findAlphaFromSound()
  {
    if (mAudioManager != null)
      return 85 + 119 * currentVolume / maxVolume;
    return 204;
  }

  private void getScreenSize()
  {
    Display localDisplay = getWindowManager().getDefaultDisplay();
    screenHeight = localDisplay.getHeight();
    screenWidth = localDisplay.getWidth();
    controlHeight = 92;
  }

  private void getVideoFile(final LinkedList<MovieInfo> paramLinkedList, File paramFile)
  {
    paramFile.listFiles(new FileFilter()
    {
      public boolean accept(File paramAnonymousFile)
      {
        String str1 = paramAnonymousFile.getName();
        int i = str1.indexOf('.');
        if (i != -1)
        {
          String str2 = str1.substring(i);
          if ((str2.equalsIgnoreCase(".mp4")) || (str2.equalsIgnoreCase(".3gp")) || (str2.equalsIgnoreCase(".wma")))
          {
            VideoPlayerActivity.MovieInfo localMovieInfo = new VideoPlayerActivity.MovieInfo();
            localMovieInfo.displayName = paramAnonymousFile.getName();
            localMovieInfo.path = paramAnonymousFile.getAbsolutePath();
            paramLinkedList.add(localMovieInfo);
            return true;
          }
        }
        else if (paramAnonymousFile.isDirectory())
        {
          getVideoFile(paramLinkedList, paramAnonymousFile);
        }
        return false;
      }
    });
  }

  private void hideController()
  {
    if (controler.isShowing())
      isControllerShow = false;
    if (mSoundWindow.isShowing())
    {
      mSoundWindow.dismiss();
      isSoundShow = false;
    }
  }

  private void hideControllerDelay()
  {
    myHandler.sendEmptyMessageDelayed(1, 6868L);
  }

  private void newseekbar(int paramInt)
  {
    abSelectBar.removeAllViews();
    myminValue = 0;
    mymaxValue = paramInt;
    ABseekBar = new RangeSeekBar(Integer.valueOf(0), Integer.valueOf(paramInt), this);
    abSelectBar.addView(ABseekBar);
    ABseekBar.setOnRangeSeekBarChangeListener(new RangeSeekBar.OnRangeSeekBarChangeListener()
    {

      public void onRangeSeekBarValuesChanged(RangeSeekBar<?> paramAnonymousRangeSeekBar, Integer paramAnonymousInteger1, Integer paramAnonymousInteger2)
      {
        System.out.println("seekBar.getSelectedMinValue(1);" + ABseekBar.getSelectedMinValue());
        Log.i(TAG, "User selected new range values: MIN=" + paramAnonymousInteger1 + ", MAX=" + paramAnonymousInteger2);
        if ((paramAnonymousInteger1.intValue() != myminValue) && (mymaxValue == paramAnonymousInteger2.intValue()))
          myminValue = paramAnonymousInteger1.intValue();
        while (true)
        {
          System.out.println("myminValue:" + myminValue);
          System.out.println("mymaxValue:" + mymaxValue);
          last = (-10 + myminValue);
          vv.seekTo(myminValue);
          myHandler.obtainMessage(4, myminValue, 0).sendToTarget();
          cancelDelayHide();
        //  return;
          mymaxValue = paramAnonymousInteger2.intValue();
        }
      }

	@Override
	public void onRangeSeekBarValuesChanged(RangeSeekBar paramRangeSeekBar, Object paramT1, Object paramT2) {
		// TODO Auto-generated method stub

	}
    });
  }

  private void onDeviceStateChange()
  {
    stopIoManager();
    startIoManager();
  }

  private void setVideoScale(int paramInt)
  {
    vv.getLayoutParams();
    switch (paramInt)
    {
    default:
      return;
    case 0:
      Log.d(TAG, "screenWidth: " + screenWidth + " screenHeight: " + screenHeight);
      vv.setVideoScale(screenWidth, screenHeight);
      getWindow().addFlags(1024);
      return;
    case 1:
    }
    int i = vv.getVideoWidth();
    int j = vv.getVideoHeight();
    int k = screenWidth;
    int m = -25 + screenHeight;
    if ((i > 0) && (j > 0))
    {
      if (i * m <= k * j) {
    	  k = m * i / j;
      }
      m = k * j / i;
    }
    while (true)
    {
      vv.setVideoScale(k, m);
      getWindow().clearFlags(1024);
      return;

    }
  }

  private void showController()
  {
    controler.update(0, 0, screenWidth, controlHeight);
    if (isFullScreen)
      extralWindow.update(0, 0, screenWidth, 50);
    while (true)
    {
      isControllerShow = true;
     // return;
      extralWindow.update(0, 0, screenWidth, 50);
    }
  }

  private void startIoManager()
  {
    if (mSerialDevice != null)
    {
      Log.i(TAG, "Starting io manager ..");
      mSerialIoManager = new SerialInputOutputManager(mSerialDevice, mListener);
      mExecutor.submit(mSerialIoManager);
    }
  }

  private void stopIoManager()
  {
    if (mSerialIoManager != null)
    {
      Log.i(TAG, "Stopping io manager ..");
      mSerialIoManager.stop();
      mSerialIoManager = null;
    }
  }

  private void updateVolume(int paramInt)
  {
    if (mAudioManager != null)
    {
      if (!isSilent) {
    	  mAudioManager.setStreamVolume(3, paramInt, 0);
      }

      mAudioManager.setStreamVolume(3, 0, 0);
    }
    while (true)
    {
      currentVolume = paramInt;
      bn5.setAlpha(findAlphaFromSound());
      return;
    }
  }

  public Common getApplicationContext()
  {
    return (Common)super.getApplicationContext();
  }

  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    if ((paramInt1 == 0) && (paramInt2 == -1))
    {
      int i = paramIntent.getIntExtra("CHOOSE", -1);
     // Log.d("RESULT", i);
      if (i != -1)
      {
        System.out.println(((MovieInfo)playList.get(i)).path);
        vv.setVideoPath(((MovieInfo)playList.get(i)).path);
        position = i;
      }
      return;
    }
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
  }

  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    getScreenSize();
    if (isControllerShow)
    {
      cancelDelayHide();
      hideController();
      showController();
      hideControllerDelay();
    }
    super.onConfigurationChanged(paramConfiguration);
  }

  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903056);
    getWindow().setFlags(128, 128);
    mUsbManager = ((UsbManager)getSystemService("usb"));
    Log.d("OnCreate", getIntent().toString());
    Looper.myQueue().addIdleHandler(new MessageQueue.IdleHandler()
    {
      public boolean queueIdle()
      {
        if ((controler != null) && (vv.isShown()))
        {
          controler.showAtLocation(vv, 80, 0, 0);
          controler.update(0, 0, VideoPlayerActivity.screenWidth, VideoPlayerActivity.controlHeight);
        }
        if ((extralWindow != null) && (vv.isShown()))
        {
          extralWindow.showAtLocation(vv, 48, 0, 0);
          extralWindow.update(0, 25, VideoPlayerActivity.screenWidth, 50);
        }
        return false;
      }
    });
    String str = Common.TrackPath;
    controlView = getLayoutInflater().inflate(2130903043, null);
    controler = new PopupWindow(controlView);
    playedTextView = ((TextView)controlView.findViewById(2131296263));
    durationTextView = ((TextView)controlView.findViewById(2131296264));
    buttonAB = ((Button)controlView.findViewById(2131296274));
    buttonAB.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {

        boolean bool2 = false;
        if (!isAbBarShow)
        {
          buttonAB.setBackgroundResource(2130837526);
          abSelectBar.setVisibility(0);
          last = 0;

          boolean bool1 = isAbBarShow;
          bool2 = false;
          if (!bool1) {
        	  bool2 = true;
          }
        }
        while (true)
        {
         isAbBarShow = bool2;
          if (isAbBarShow)
          {
            vv.pause();
            bn3.setImageResource(2130837527);
            isPaused = true;
            return;
          }

          buttonAB.setBackgroundResource(2130837525);
          abSelectBar.setVisibility(4);
          break;
        }
      }
    });
    abSelectBar = ((LinearLayout)controlView.findViewById(2131296265));
    ABseekBar = new RangeSeekBar(Integer.valueOf(0), Integer.valueOf(10), this);
    abSelectBar.addView(ABseekBar);
    ABseekBar.setOnRangeSeekBarChangeListener(new RangeSeekBar.OnRangeSeekBarChangeListener()
    {
      public void onRangeSeekBarValuesChanged(RangeSeekBar<?> paramAnonymousRangeSeekBar, Integer paramAnonymousInteger1, Integer paramAnonymousInteger2)
      {
        System.out.println("seekBar.getSelectedMinValue(1);" + ABseekBar.getSelectedMinValue());
        Log.i(TAG, "User selected new range values: MIN=" + paramAnonymousInteger1 + ", MAX=" + paramAnonymousInteger2);
      }

	@Override
	public void onRangeSeekBarValuesChanged(RangeSeekBar paramRangeSeekBar, Object paramT1, Object paramT2) {
		// TODO Auto-generated method stub

	}
    });
    mSoundView = new SoundView(this);
    mSoundView.setOnVolumeChangeListener(new SoundView.OnVolumeChangedListener()
    {
      public void setYourVolume(int paramAnonymousInt)
      {
        cancelDelayHide();
        updateVolume(paramAnonymousInt);
        hideControllerDelay();
      }
    });
    extralSoundView = getLayoutInflater().inflate(2130903046, null);
    ((LinearLayout)extralSoundView.findViewById(2131296286)).addView(mSoundView);
    mSoundWindow = new PopupWindow(extralSoundView);
    extralView = getLayoutInflater().inflate(2130903045, null);
    extralWindow = new PopupWindow(extralView);
    ((Button)extralView.findViewById(2131296280)).setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        Intent localIntent = new Intent();
        localIntent.setClass(null, MusicActivity.class);
        startActivity(localIntent);
        finish();
      }
    });
    ((Button)extralView.findViewById(2131296281)).setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        Intent localIntent = new Intent();
        localIntent.setClass(null, SelectActivity.class);
        startActivity(localIntent);
        finish();
      }
    });
    ((Button)extralView.findViewById(2131296282)).setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        Intent localIntent = new Intent();
        localIntent.setAction("android.intent.action.VIEW");
        localIntent.setData(Uri.parse("http://ushowpiano.taobao.com/"));
        startActivity(localIntent);
      }
    });
    position = -1;
    bn1 = ((ImageButton)controlView.findViewById(2131296276));
    bn2 = ((ImageButton)controlView.findViewById(2131296268));
    bn3 = ((ImageButton)controlView.findViewById(2131296269));
    bn4 = ((ImageButton)controlView.findViewById(2131296270));
    bn5 = ((ImageButton)controlView.findViewById(2131296275));
    ImageViewConn = ((ImageView)controlView.findViewById(2131296267));
    buttonAB = ((Button)controlView.findViewById(2131296274));
    buttonRec = ((Button)controlView.findViewById(2131296271));
    buttonADD = ((Button)controlView.findViewById(2131296273));
    TextViewPeiShu = ((TextView)controlView.findViewById(2131296272));
    TextViewPeiShu.setText(size + "��");
    System.out.println("-----------------mypath----------------------" + str);
    getVideoFile(playList, new File(str + "/"));
    Cursor localCursor = getContentResolver().query(videoListUri, new String[] { "_display_name", "_data" }, null, null, null);
    int i = localCursor.getCount();
    localCursor.moveToFirst();
    LinkedList localLinkedList = new LinkedList();
    int j = 0;
    int k = 0;
    if (j == i)
    {
      if (localLinkedList.size() > playList.size())
        playList = localLinkedList;
      vv = ((VideoView)findViewById(2131296326));
      playlistsize = playList.size();
      System.out.println("-----------------path---------1-----------");
      k = 0;
      label794: if (k < playList.size())
       // break label1243;
      label805: System.out.println("-----------------path----------2----------");
      Uri localUri = getIntent().getData();
      if (localUri == null)
     //   break label1316;
      if (vv.getVideoHeight() == 0)
        vv.setVideoURI(localUri);
      bn3.setImageResource(2130837564);
    }
    while (true)
    {
      vv.setMySizeChangeLinstener(new VideoView.MySizeChangeLinstener()
      {
        public void doMyThings()
        {
          setVideoScale(1);
        }
      });
      bn1.setAlpha(187);
      bn2.setAlpha(187);
      bn3.setAlpha(187);
      bn4.setAlpha(187);
      mAudioManager = ((AudioManager)getSystemService("audio"));
      maxVolume = mAudioManager.getStreamMaxVolume(3);
      currentVolume = mAudioManager.getStreamVolume(3);
      bn5.setAlpha(findAlphaFromSound());
      bn1.setOnClickListener(new View.OnClickListener()
      {
        public void onClick(View paramAnonymousView)
        {
          Intent localIntent = new Intent();
          localIntent.setClass(null, VideoChooseActivity.class);
          startActivityForResult(localIntent, 0);
          cancelDelayHide();
        }
      });

      bn4.setOnClickListener(new View.OnClickListener()
      {
        public void onClick(View paramAnonymousView)
        {
          if (isBack)
          {
            bn2.setImageResource(2130837531);
            isBack = false;
          }

          boolean bool2 = false;
          if (!isFW)
          {
            vv.pause();
            isPaused = true;
            if (isPaused)
              vv.start(40);
            isPaused = false;
            bn4.setImageResource(2130837541);
            bn3.setImageResource(2130837527);
            backFlg = false;

            boolean bool1 = isFW;
            bool2 = false;
            if (!bool1) {
            	bool2 = true;
            }
          }
          while (true)
          {
            isFW = bool2;
           // return;
            vv.pause();
            isPaused = true;
            bn3.setImageResource(2130837527);
            bn4.setImageResource(2130837540);
            break;
          }
        }
      });

      bn3.setOnClickListener(new View.OnClickListener()
      {
        public void onClick(View paramAnonymousView)
        {
          cancelDelayHide();
          backFlg = false;
          System.out.println("----------1-----------");
          if ((isBack) || (isFW))
          {
            System.out.println("----------2-----------" + size);
            vv.pause();
            vv.start((int)(10.0D * size));
            bn3.setImageResource(2130837564);
            isPaused = false;
            if (isBack)
              bn2.setImageResource(2130837531);
            if (isFW)
              bn4.setImageResource(2130837540);
            isBack = false;
            isFW = false;
            return;
          }
          System.out.println("----------3-----------");

          if (isPaused)
          {
            vv.start((int)(10.0D * size));
            bn3.setImageResource(2130837564);
            hideControllerDelay();

            if (!isPaused) {
                for (boolean bool = false; ; bool = true)
                {
                  isPaused = bool;
                 // break;
                  vv.pause();
                  bn3.setImageResource(2130837527);
                }
            }
          }

        }
      });
      bn2.setOnClickListener(new View.OnClickListener()
      {
        public void onClick(View paramAnonymousView)
        {
          if (isFW)
          {
            bn4.setImageResource(2130837540);
            isFW = false;
          }
          VideoPlayerActivity localVideoPlayerActivity;
          boolean bool2 = false;
          if (!isBack)
          {
            vv.pause();
            isPaused = true;
            backFlg = true;
            if (isPaused)
              vv.start(-10);
            isPaused = false;
            bn2.setImageResource(2130837532);
            bn3.setImageResource(2130837527);

            boolean bool1 = isBack;
            bool2 = false;
            if (!bool1) {
            	 bool2 = true;
            }
          }
          while (true)
          {
            isBack = bool2;

            vv.pause();
            isPaused = true;
            bn3.setImageResource(2130837527);
            bn2.setImageResource(2130837531);
            break;
          }
        }
      });
      bn5.setOnClickListener(new View.OnClickListener()
      {
        public void onClick(View paramAnonymousView)
        {
          cancelDelayHide();

          if (isSoundShow)
          {
            mSoundWindow.dismiss();

            if (!isSoundShow) {
                 for (boolean bool = false; ; bool = true)
                {
                  isSoundShow = bool;
                  hideControllerDelay();

                  if (mSoundWindow.isShowing())
                  {
                    mSoundWindow.update(30, 50, 44, 163);
                    break;
                  }
                  mSoundWindow.showAtLocation(vv, 85, 30, 50);
                  mSoundWindow.update(30, 50, 44, 163);
                  break;
                }
            }
          }

        }
      });
      bn5.setOnLongClickListener(new View.OnLongClickListener()
      {
        public boolean onLongClick(View paramAnonymousView)
        {

          if (isSilent)
          {
            bn5.setImageResource(2130837559);

            if (!isSilent) {
                for (boolean bool = false; ; bool = true)
                {
                  isSilent = bool;
                  updateVolume(currentVolume);
                  cancelDelayHide();
                  hideControllerDelay();

                  bn5.setImageResource(2130837560);
                  break;
                }
            }
          }
          return true;
        }
      });
      buttonADD.setOnClickListener(new View.OnClickListener()
      {
        public void onClick(View paramAnonymousView)
        {
          if (isBack)
          {
            bn2.setImageResource(2130837531);
            isBack = false;
          }
          if (isFW)
          {
            bn4.setImageResource(2130837540);
            isFW = false;
          }

          size = (0.1D + size);
          if (size > 1.0D)
            size = (1.0D + size - 0.1D);
          System.out.println("size======================" + size);
          size = (Math.round(100.0D * size) / 100.0D);
          TextViewPeiShu.setText(size + "��");
          vv.pause();
          isPaused = true;
          if (isPaused)
            vv.start((int)(10.0D * size));
          isPaused = false;
          bn3.setImageResource(2130837564);
          backFlg = false;
          cancelDelayHide();
        }
      });
      buttonRec.setOnClickListener(new View.OnClickListener()
      {
        public void onClick(View paramAnonymousView)
        {
          if (isBack)
          {
            bn2.setImageResource(2130837531);
            isBack = false;
          }
          if (isFW)
          {
            bn4.setImageResource(2130837540);
            isFW = false;
          }

          if (size > 1.0D)

          for (size -= 1.0D; ; size -= 0.1D)
          {
            if (size <= 0.1D)
              size = 0.1D;
            size = (Math.round(10.0D * size) / 10.0D);
            TextViewPeiShu.setText(size + "��");
            vv.pause();
            isPaused = true;
            if (isPaused)
              vv.start((int)(10.0D * size));
            isPaused = false;
            bn3.setImageResource(2130837564);
            backFlg = false;
            cancelDelayHide();
            return;
          }
        }
      });
      seekBar = ((SeekBar)controlView.findViewById(2131296266));
      seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener()
      {
        public void onProgressChanged(SeekBar paramAnonymousSeekBar, int paramAnonymousInt, boolean paramAnonymousBoolean)
        {
          if (paramAnonymousBoolean)
          {
            vv.seekTo(paramAnonymousInt);
            last = (paramAnonymousInt - 10);
            seekbarHasplayed = vv.getCurrentPosition();
          }
          if ((isAbBarShow) && (paramAnonymousInt - mymaxValue > 90))
          {
            vv.seekTo(myminValue);
            myHandler.obtainMessage(4, myminValue, 0).sendToTarget();
          }
        }

        public void onStartTrackingTouch(SeekBar paramAnonymousSeekBar)
        {
          myHandler.removeMessages(1);
        }

        public void onStopTrackingTouch(SeekBar paramAnonymousSeekBar)
        {
          myHandler.sendEmptyMessageDelayed(1, 6868L);
        }
      });
      getScreenSize();
      mGestureDetector = new GestureDetector(new GestureDetector.SimpleOnGestureListener()
      {
        public boolean onDoubleTap(MotionEvent paramAnonymousMotionEvent)
        {

          if (isFullScreen)
          {
            setVideoScale(1);

            if (!isFullScreen) {
                for (boolean bool = false; ; bool = true)
                {
                  isFullScreen = bool;
                  Log.d(TAG, "onDoubleTap");
                  if (isControllerShow) {
                    showController();
                  return true;
                  }
                  setVideoScale(1);
                  break;
                }
            }
          }
          return true;
        }

        public void onLongPress(MotionEvent paramAnonymousMotionEvent)
        {

          if (isPaused)
          {
            vv.start();
            bn3.setImageResource(2130837564);
            cancelDelayHide();
            hideControllerDelay();

            if (!isPaused) {
                for (boolean bool = false; ; bool = true)
                {
                  isPaused = bool;

                  vv.pause();
                  bn3.setImageResource(2130837527);
                  cancelDelayHide();
                  showController();
                }
            }
          }

        }

        public boolean onSingleTapConfirmed(MotionEvent paramAnonymousMotionEvent)
        {
          if (!isControllerShow)
          {
            showController();
            hideControllerDelay();
          }

            cancelDelayHide();
            hideController();
            return true;

        }
      });
      vv.setOnPreparedListener(new MediaPlayer.OnPreparedListener()
      {
        public void onPrepared(MediaPlayer paramAnonymousMediaPlayer)
        {
          setVideoScale(1);
          isFullScreen = false;
          if (isControllerShow)
            showController();
          int i = vv.getDuration();
         // Log.d("onCompletion", i);
          seekBar.setMax(i);
          newseekbar(i);
          int j = i / 1000;
          int k = j / 60;
        k =  (k / 60);
          int m = j % 60;
          int n = k % 60;
          TextView localTextView = durationTextView;
          Object[] arrayOfObject = new Object[2];
          arrayOfObject[0] = Integer.valueOf(n);
          arrayOfObject[1] = Integer.valueOf(m);
          localTextView.setText(String.format("%02d:%02d", arrayOfObject));
          vv.start();
          bn3.setImageResource(2130837564);
          hideControllerDelay();
          myHandler.sendEmptyMessage(0);
        }
      });
      vv.setOnCompletionListener(new MediaPlayer.OnCompletionListener()
      {
        public void onCompletion(MediaPlayer paramAnonymousMediaPlayer)
        {
          last = 0;
          myHandler.obtainMessage(4, 0, 0).sendToTarget();
          System.out.println("setOnCompletionListenersetOnCompletionListener");
          new VideoPlayerActivity.OpenVideo().start();
          if (size >= 1.0D)
          {
            size = 1.0D;
            TextViewPeiShu.setText(size + "��");
          }
          bn4.setImageResource(2130837540);

          boolean bool1 = isFW;
          boolean bool2 = false;
          if (bool1);
          while (true)
          {
            isFW = bool2;
           // return;
            bool2 = true;
          }
        }
      });
     // return;
      MovieInfo localMovieInfo = new MovieInfo();
      localMovieInfo.displayName = localCursor.getString(localCursor.getColumnIndex("_display_name"));
      localMovieInfo.path = localCursor.getString(localCursor.getColumnIndex("_data"));
      localLinkedList.add(localMovieInfo);
      localCursor.moveToNext();
      j++;
     // break;
      // TODO --
      //int k = 0;
      label1243: System.out.println(((MovieInfo)playList.get(k)).path);
      if (((MovieInfo)playList.get(k)).path.contains(str))
      {
        videopathString = ((MovieInfo)playList.get(k)).path;
        position = k;
       // break label805;
      }
      k++;
    //  break label794;
      label1316: bn3.setImageResource(2130837527);
    }
  }

  protected void onDestroy()
  {
    if (controler.isShowing())
    {
      controler.dismiss();
      extralWindow.dismiss();
    }
    if (mSoundWindow.isShowing())
      mSoundWindow.dismiss();
    myHandler.removeMessages(0);
    myHandler.removeMessages(1);
    playList.clear();
    super.onDestroy();
  }

  protected void onPause()
  {
    playedTime = vv.getCurrentPosition();
    vv.pause();
    bn3.setImageResource(2130837527);
    super.onPause();
    stopIoManager();
    if (mSerialDevice != null);
    try
    {
      mSerialDevice.close();
    }
    catch (IOException localIOException)
    {
    	 mSerialDevice = null;
    }
  }

  protected void onResume()
  {
    vv.seekTo(playedTime);
    vv.start();
    if (vv.getVideoHeight() != 0)
    {
      bn3.setImageResource(2130837564);
      hideControllerDelay();
    }
    Log.d("REQUEST", "NEW AD !");
    mSerialDevice = UsbSerialProber.acquire(mUsbManager);
    Log.d(TAG, "Resumed, mSerialDevice=" + mSerialDevice);
    if (mSerialDevice != null);
    try
    {
      mSerialDevice.open();
      onDeviceStateChange();
      super.onResume();
      System.out.println("controler.isShowing()" + controler.isShowing());
      new OpenVideo().start();
      sendTestConnData();
      return;
    }
    catch (IOException localIOException1)
    {
      Log.e(TAG, "Error setting up device: " + localIOException1.getMessage(), localIOException1);
    }
    try
    {
      mSerialDevice.close();
    }
    catch (IOException localIOException2)
    {
    	mSerialDevice = null;
    }
  }

  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    boolean bool = mGestureDetector.onTouchEvent(paramMotionEvent);
    if (!bool)
    {
      paramMotionEvent.getAction();
      bool = super.onTouchEvent(paramMotionEvent);
    }
    return bool;
  }

  void sendTestConnData()
  {
    try
    {
      mSerialDevice.write("TestConn".getBytes(), 5);
      ImageViewConn.setImageResource(2130837568);
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
      ImageViewConn.setImageResource(2130837567);
    }
  }

  public void updateReceivedData(byte[] paramArrayOfByte)
  {
    String str = null;
    if (paramArrayOfByte.length > 0)
    {
      str = new String(paramArrayOfByte);
      if (!str.equals(Constant.BK)) {
    	// TODO --

      }

      vv.pause();
      isPaused = true;
      backFlg = true;
      if (isPaused)
      {
        last = 0;
        vv.getDuration();
        int j = -3000 + vv.getCurrentPosition();
        if ((j < myminValue) && (isAbBarShow))
          j = myminValue;
        if (j >= 0) {
        	// TODO --
        }

        vv.seekTo(0);
        vv.start((int)(10.0D * size));
      }
      isPaused = false;
      bn3.setImageResource(2130837564);
    }

    while (!str.equals(Constant.FW))
      while (true)
      {
        int j = 0;

        vv.seekTo(j);
        return;
      }
    vv.pause();
    isPaused = true;
    backFlg = true;
    int i;
    if (isPaused)
    {
      vv.getDuration();
      i = 2000 + vv.getCurrentPosition();
      if (i <= vv.getDuration()) {
    	  vv.seekTo(i);
      }

      vv.seekTo(vv.getDuration());
    }
    while (true)
    {
      vv.start((int)(10.0D * size));
      isPaused = false;
      bn3.setImageResource(2130837564);
      return;

    }
  }

  public class MovieInfo
  {
    String displayName;
    String path;

    public MovieInfo()
    {
    }
  }

  class OpenVideo extends Thread
  {
    OpenVideo()
    {
    }

    public void run()
    {
      super.run();
      System.out.println("thread start  --------------- ");
      try
      {
        sleep(100L);
        myHandler.obtainMessage(3).sendToTarget();
        return;
      }
      catch (InterruptedException localInterruptedException)
      {
        while (true)
          localInterruptedException.printStackTrace();
      }
    }
  }
}
