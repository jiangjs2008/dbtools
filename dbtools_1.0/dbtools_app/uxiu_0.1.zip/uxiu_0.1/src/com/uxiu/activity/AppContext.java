package com.uxiu.activity;

import java.io.File;

import android.app.Activity;

public final class AppContext {

	private static Activity innActivity = null;
	//private static Stack<Activity> baseActivity = new Stack<Activity>();

	private static ExceptionHandler sgeh = null;

	/**
	 * Retrieve the Activity that is currently running.
	 * 
	 * @return the currently running Activity
	 */
	public static void setCurrActivity(Activity activity) {
		innActivity = activity;
	}

	/**
	 * Retrieve the Activity that is currently running.
	 * 
	 * @return the currently running Activity
	 */
	public static Activity getCurrActivity() {
		return innActivity;
	}


	public static ExceptionHandler getExceptionHandler() {
		return sgeh;
	}

	public static void setExceptionHandler(ExceptionHandler eh) {
		sgeh = eh;
	}

	private static File musicFile = null;

	public static File getSelectMusicFile() {
		return musicFile;
	}

	public static void setSelectMusicFile(File musicName) {
		musicFile = musicName;
	}

}
