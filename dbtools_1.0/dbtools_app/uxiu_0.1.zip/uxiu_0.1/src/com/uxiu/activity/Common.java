package com.uxiu.activity;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import android.app.Application;
import android.os.Environment;

import com.uxiu.bean.Select1;
import com.uxiu.bean.ShowTarckName;
import com.uxiu.scpark.engine.Track;

public class Common extends Application {
	public static String TrackPath = "";
	public static Track mtrack = null;
	public static int selectindex = -1;
	public String CommonSDCard = "";
	public List<ShowTarckName> Tracks = new ArrayList();
	public List<String> allSelect1s = new ArrayList();
	public int maxXiaojie = 0;
	public int nowXiaojie = 0;

	// TODO --
	boolean CheckTrack(String paramString) {
		File localFile = new File(paramString);
		if (!localFile.exists()) {
			return false;
		}
		File[] arrayOfFile;
		do {

			arrayOfFile = localFile.listFiles();
		} while (arrayOfFile.length < 2);
		for (int i = 0;; i++) {
			if (i >= arrayOfFile.length)
				;
			while ((!arrayOfFile[i].isDirectory())
					&& ((arrayOfFile[i].getAbsolutePath().endsWith(".txt")) || (arrayOfFile[i].getAbsolutePath().endsWith(".TXT")))) {

				if (i == -1 + arrayOfFile.length) {
					return true;
				}
			}

		}
	}

	void GetSelct1(String paramString) throws Exception {
		this.Tracks.clear();
		File[] arrayOfFile = new File(paramString).listFiles();
		System.out.println(arrayOfFile.length);
		for (int i = 0;; i++) {
			if (i >= arrayOfFile.length)
				return;
			if (arrayOfFile[i].isDirectory()) {
				ShowTarckName localShowTarckName = new ShowTarckName();
				localShowTarckName.tarckname = arrayOfFile[i].getName();
				localShowTarckName.tarckpath = arrayOfFile[i].getAbsolutePath();
				this.Tracks.add(localShowTarckName);
			}
		}
	}

	public List<String> getAllSelect1s() {
		return this.allSelect1s;
	}

	public int getMaxXiaojie() {
		return this.maxXiaojie;
	}

	public int getNowXiaojie() {
		return this.nowXiaojie;
	}

	public boolean getSDPath() {
		if (Environment.getExternalStorageState().equals("mounted")) {
			this.CommonSDCard = Environment.getExternalStorageDirectory().toString();
			return true;
		}
		return false;
	}

	public String getYouXiuPath() {
		String str = this.CommonSDCard + "/�������";
		File localFile = new File(str);
		if (!localFile.exists())
			localFile.mkdirs();
		return str;
	}

	public void onCreate() {
		super.onCreate();
	}

	public void setAllSelect1s(List<String> paramList) {
		this.allSelect1s = paramList;
	}

	public void setMaxXiaojie(int paramInt) {
		this.maxXiaojie = paramInt;
	}

	public void setNowXiaojie(int paramInt) {
		this.nowXiaojie = paramInt;
	}

	List<Select1> showAllFiles(List<Select1> paramList, String paramString) throws Exception {
		paramList.clear();
		File[] arrayOfFile = new File(paramString).listFiles();
		for (int i = 0;; i++) {
			if (i >= arrayOfFile.length)
				return paramList;
			if (arrayOfFile[i].isDirectory()) {
				Select1 localSelect1 = new Select1();
				localSelect1.file = arrayOfFile[i];
				localSelect1.Selectname = arrayOfFile[i].getName();
				localSelect1.Selectpath = arrayOfFile[i].getAbsolutePath();
				paramList.add(localSelect1);
			}
		}
	}
}
