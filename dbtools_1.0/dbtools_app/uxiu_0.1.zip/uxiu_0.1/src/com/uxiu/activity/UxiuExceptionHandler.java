package com.uxiu.activity;

import org.apache.log4j.Logger;

import android.app.Activity;


public class UxiuExceptionHandler implements ExceptionHandler {

	private static Logger logger = new Logger(UxiuExceptionHandler.class);

	@Override
	public void uncaughtException(Thread thread, Throwable ex) {
		logger.error(ex);
		Activity sgAct = AppContext.getCurrActivity();
		sgAct.finish();
		android.os.Process.killProcess(android.os.Process.myPid());
	}

	public void execute(Throwable ex) {
		logger.error(ex);
	}

}
