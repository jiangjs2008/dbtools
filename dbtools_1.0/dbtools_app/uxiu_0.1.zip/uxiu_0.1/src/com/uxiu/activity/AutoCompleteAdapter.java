package com.uxiu.activity;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.uxiu.bean.Select1;

public class AutoCompleteAdapter extends BaseAdapter {

	private List<Select1> Selects;
	Context context;
	private LayoutInflater mInflater;

	AutoCompleteAdapter(Context paramContext) {
		this.context = paramContext;
		this.mInflater = ((LayoutInflater) paramContext.getSystemService("layout_inflater"));
	}

	public Common getApplicationContext() {
		return (Common) this.context.getApplicationContext();
	}

	public int getCount() {
		return this.Selects.size();
	}

	public Object getItem(int paramInt) {
		return this.Selects.get(paramInt);
	}

	public long getItemId(int paramInt) {
		return paramInt;
	}

	public View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
		View localView = this.mInflater.inflate(R.layout.search_item, null);
		((TextView) localView.findViewById(R.id.TextViewName)).setText(this.Selects.get(paramInt).Selectname);
		((TextView) localView.findViewById(R.id.TextViewPath)).setText(this.Selects.get(paramInt).Selectpath);
		return localView;
	}
}
