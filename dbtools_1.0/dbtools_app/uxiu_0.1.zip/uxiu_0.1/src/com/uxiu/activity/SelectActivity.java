package com.uxiu.activity;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import android.content.Intent;
import android.database.Cursor;
import android.media.SoundPool;
import android.media.SoundPool.OnLoadCompleteListener;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import com.uxiu.bean.MusicFileUtil;
import com.uxiu.bean.Select1;
import com.uxiu.database.StudyDataBaseAdapter;
import com.uxiu.scpark.engine.SoundPlayer;

public class SelectActivity extends BaseActivity {


	ListView List1;
	ListView List2;
	ListView List3;
	int SelectClass = 0;
	int SelectTrack = 0;
	public List<Select1> select1 = new ArrayList();

	public List<Select1> select2 = new ArrayList();

	public List<Select1> select3 = new ArrayList();

	StudyDataBaseAdapter studyDataBaseAdapter;

	private void initData() {
		try {
			this.select1 = getApplicationContext().showAllFiles(this.select1, getApplicationContext().getYouXiuPath());
			System.out.println(this.select1.size());
			Cursor localCursor = this.studyDataBaseAdapter.fetchAllData();
			int i = localCursor.getColumnIndex("TrackName");
			int j = localCursor.getColumnIndex("TrackPath");
			localCursor.getColumnIndex("Date");
			this.select3.clear();
			localCursor.moveToFirst();
			if (localCursor.isAfterLast())
				return;
		} catch (Exception localException) {
			localException.printStackTrace();
			// while (true) {
			// Cursor localCursor;
			// int i;
			// int j;
			// localException.printStackTrace();
			// continue;
			// Select1 localSelect1 = new Select1();
			// localSelect1.Selectname = localCursor.getString(i);
			// localSelect1.Selectpath = localCursor.getString(j);
			// this.select3.add(localSelect1);
			// localCursor.moveToNext();
			// }
		}
	}

	private void initview() {

		this.List1 = ((ListView) findViewById(2131296320));
		this.List2 = ((ListView) findViewById(2131296321));
		this.List3 = ((ListView) findViewById(2131296322));

		// ��������Ŀ¼һ��
		ArrayList<HashMap<String, Object>> dirList = MusicFileUtil.getMusicFile(MusicFileUtil.getYouXiuPath());
		SimpleAdapter select1Adapter = new SimpleAdapter(this, dirList, R.layout.list1, new String[] { "Selectname" }, new int[] { R.id.TextDuration });

		this.List1.setAdapter(select1Adapter);
		this.List1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@SuppressWarnings("unchecked")
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				SimpleAdapter listItemAdapter = (SimpleAdapter) ((ListView) parent).getAdapter();
				HashMap<String, Object> famItem = (HashMap<String, Object>) listItemAdapter.getItem(position);

				ArrayList<HashMap<String, Object>> fileList = MusicFileUtil.getMusicFile((String) famItem.get("Selectpath"));

				SimpleAdapter select2Adapter = new SimpleAdapter(getBaseContext(), fileList, R.layout.list2, new String[] { "Selectname" }, new int[] { R.id.TextDuration });
				List2.setAdapter(select2Adapter);
			}
		});

		// ����������һ��
		if (dirList.size() > 0) {

			ArrayList<HashMap<String, Object>> fileList = MusicFileUtil.getMusicFile((String) dirList.get(0).get("Selectpath"));
			SimpleAdapter select2Adapter = new SimpleAdapter(this, fileList, R.layout.list2, new String[] { "Selectname" }, new int[] { R.id.TextDuration });

			this.List2.setAdapter(select2Adapter);
			this.List2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
					SimpleAdapter listItemAdapter = (SimpleAdapter) ((ListView) parent).getAdapter();
					HashMap<String, Object> famItem = (HashMap<String, Object>) listItemAdapter.getItem(position);
					

//						SelectActivity.this.getApplicationContext().select = ((Select1) SelectActivity.this.select2
//								.get(paramAnonymousInt));
//						Date localDate = new Date();
//						String str = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(localDate);
//						System.out.println("-------------path-------------------"
//								+ ((Select1) SelectActivity.this.select2.get(paramAnonymousInt)).Selectpath);
//						SelectActivity.this.getApplicationContext();
//						Common.TrackPath = ((Select1) SelectActivity.this.select2.get(paramAnonymousInt)).Selectpath;
//						SelectActivity.this.studyDataBaseAdapter.insert(
//								(Select1) SelectActivity.this.select2.get(paramAnonymousInt), str);
					AppContext.setSelectMusicFile((File) famItem.get("file"));
					toOtherActivity(MusicActivity.class, 3);
				}
			});
		}

		// ����ѧϰ��¼һ��
//		this.select3Adapter = new Select1Adapter(this, this.select3, 3);
//		this.List3.setAdapter(this.select3Adapter);
		this.List3.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			public void onItemClick(AdapterView<?> paramAnonymousAdapterView, View paramAnonymousView,
					int paramAnonymousInt, long paramAnonymousLong) {
				if (SelectActivity.this.getApplicationContext().CheckTrack(
						((Select1) SelectActivity.this.select3.get(paramAnonymousInt)).Selectpath)) {
//					SelectActivity.this.getApplicationContext().select = ((Select1) SelectActivity.this.select3
//							.get(paramAnonymousInt));
					File localFile = new File(
							((Select1) SelectActivity.this.select3.get(paramAnonymousInt)).Selectpath);
					if (localFile.exists()) {
						Date localDate = new Date();
//						SelectActivity.this.getApplicationContext().select.file = localFile;
						String str = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(localDate);
						System.out.println("------------path--------------------"
								+ ((Select1) SelectActivity.this.select3.get(paramAnonymousInt)).Selectpath);
						SelectActivity.this.getApplicationContext();
						Common.TrackPath = ((Select1) SelectActivity.this.select3.get(paramAnonymousInt)).Selectpath;
						SelectActivity.this.studyDataBaseAdapter.insert(
								(Select1) SelectActivity.this.select3.get(paramAnonymousInt), str);
						System.out.println("---------------------------------");
						SelectActivity.this.toOtherActivity(MusicActivity.class, 3);
						return;
					}
					Toast.makeText(SelectActivity.this, "��Ŀ���ݲ���ȷ����ѡ��������Ŀ", Toast.LENGTH_LONG).show();
					return;
				}
				Toast.makeText(SelectActivity.this, "��Ŀ���ݲ���ȷ����ѡ��������Ŀ", Toast.LENGTH_LONG).show();
			}
		});

	}

	private void loadsearch() {
		getApplicationContext().allSelect1s.clear();
		int i = this.select1.size();
		int j = 0;
		if (j >= i)
			return;
		File[] arrayOfFile = new File(((Select1) this.select1.get(j)).Selectpath).listFiles();
		for (int k = 0;; k++) {
			if (k >= arrayOfFile.length) {
				j++;
				break;
			}
			if (arrayOfFile[k].isDirectory())
				getApplicationContext().allSelect1s.add(arrayOfFile[k].getName());
		}
	}

	private boolean name() {
		SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Object localObject = new Date();
		try {
			Date localDate2 = localSimpleDateFormat.parse("2013-7-1");
			localObject = localDate2;
			Date localDate1 = new Date();
			localDate1.getTime();
			if (localDate1.getTime() - ((Date) localObject).getTime() > 0L) {
				Toast.makeText(this, "�����޷�ʹ��", Toast.LENGTH_LONG).show();
				return false;
			}
		} catch (ParseException localParseException) {
			localParseException.printStackTrace();
		}
		return true;
	}

	private void search(String paramString) {
		this.SelectClass = 0;
		this.SelectTrack = 0;
		int i = this.select1.size();
		int j = 0;
		if (j >= i)
			return;
		File[] arrayOfFile = new File(((Select1) this.select1.get(j)).Selectpath).listFiles();
		for (int k = 0;; k++) {
			if (k >= arrayOfFile.length) {
				j++;
				break;
			}
			System.out.println(paramString);
			System.out.println("fs[i].getName()" + arrayOfFile[k].getName());
			if ((arrayOfFile[k].isDirectory()) && (arrayOfFile[k].getName().contains(paramString))) {
				this.SelectClass = j;
				this.SelectTrack = k;
				try {
					this.select2 = getApplicationContext().showAllFiles(this.select2,
							((Select1) this.select1.get(j)).Selectpath);
//					this.select2Adapter = new Select1Adapter(this, this.select2, 2);
//					this.List2.setAdapter(this.select2Adapter);
					System.out.println("i" + j + "  j" + k);
					return;
				} catch (Exception localException) {
					localException.printStackTrace();
				}
			}
		}
	}

	@Override
	public Common getApplicationContext() {
		return (Common) super.getApplicationContext();
	}

	@Override
	protected void onCreate(Bundle paramBundle) {
		AppContext.setCurrActivity(this);
		super.onCreate(paramBundle);
		requestWindowFeature(1);
		setContentView(R.layout.select);
		getApplicationContext().getSDPath();
		this.studyDataBaseAdapter = new StudyDataBaseAdapter(this);
		if (!name())
			return;
		initData();
		initview();
		loadsearch();
	}

	void toOtherActivity(Class<?> paramClass, int paramInt) {
		Intent localIntent = new Intent();
		localIntent.setClass(this, paramClass);
		localIntent.putExtra("ViewID", paramInt);
		startActivity(localIntent);
		finish();
	}

	/**
	 * ���水ť�����¼�����
	 *
	 * @param v ���水ť����
	 */
	public void onClick(View v) {
		if (v.getId() == R.id.btn_search) {
			// ����������
			EditText nameText = ((EditText) findViewById(R.id.EditText1));
			String str = nameText.getText().toString();
			if (str == null || "".equals(str) || "".equals(str.replace(" ", ""))) {
				Toast.makeText(SelectActivity.this, "��������ȷ��������", Toast.LENGTH_LONG).show();
				return;
			}

			this.search(str);
			this.List1.setSelection(SelectActivity.this.SelectClass);
			this.List1.setSelected(true);
			this.List2.setSelection(SelectActivity.this.SelectTrack);
			this.List2.setSelected(true);

		} else if (v.getId() == R.id.btn_taobao) {
			// ת���Ա���ҳ
			Log.i("TOTAOBAO", "TOTAOBAO");
//			Intent localIntent = new Intent();
//			localIntent.setAction("android.intent.action.VIEW");
//			localIntent.setData(Uri.parse("http://ushowpiano.taobao.com/"));
//			SelectActivity.this.startActivity(localIntent);
			
			SoundPlayer.init(getBaseContext());
			
		}
	}


//	class PlayMusc extends Thread {
//		PlayMusc() {
//		}
//
//		public void run() {
//			super.run();
//			int i = 0;
//			while (true) {
//				if (i >= 50)
//					return;
//				MediaPlayer localMediaPlayer = MediaPlayer.create(SelectActivity.this, 2131099664);
//				localMediaPlayer.start();
//				try {
//					sleep(300L);
//					localMediaPlayer.stop();
//					localMediaPlayer.release();
//					i++;
//				} catch (InterruptedException localInterruptedException) {
//					localInterruptedException.printStackTrace();
//				}
//			}
//		}
//	}

}
