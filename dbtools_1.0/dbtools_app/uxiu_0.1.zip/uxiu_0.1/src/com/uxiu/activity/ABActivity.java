package com.uxiu.activity;

import kankan.wheel.widget.WheelView;
import kankan.wheel.widget.adapters.NumericWheelAdapter;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class ABActivity extends Activity {

	Button Button1;
	Button Button2;
	Spinner Spinner01;
	Spinner Spinner02;
	int max = 0;

	private void initview() {
		this.Button2 = ((Button) findViewById(R.id.ButtonComfirm));
		this.Button1 = ((Button) findViewById(R.id.ButtonCancle));
		final WheelView localWheelView1 = (WheelView) findViewById(R.id.FromA);
		localWheelView1.setViewAdapter(new NumericWheelAdapter(this, 1, this.max, "��%02d��"));
		System.out.println("A:" + getApplicationContext().getNowXiaojie());
		localWheelView1.setCurrentItem(-1 + getApplicationContext().getNowXiaojie());
		final WheelView localWheelView2 = (WheelView) findViewById(R.id.EndB);
		localWheelView2.setViewAdapter(new NumericWheelAdapter(this, 1, this.max, "��%02d��"));
		localWheelView2.setCurrentItem(-1 + getApplicationContext().getNowXiaojie());
		localWheelView2.setCyclic(true);
		this.Button2.setOnClickListener(new View.OnClickListener() {
			public void onClick(View paramAnonymousView) {
				int i = 1 + localWheelView1.getCurrentItem();
				int j = 1 + localWheelView2.getCurrentItem();
				System.out.println("A:" + i + "B:" + j);
				if (i > j) {
					Toast.makeText(ABActivity.this, "��ʼA����ֵ��ҪС�ڵ��ڽ���B��ֵ", Toast.LENGTH_LONG).show();
					return;
				}
				Intent localIntent = new Intent();
				localIntent.putExtra("startA", i);
				localIntent.putExtra("endB", j);
				ABActivity.this.setResult(-1, localIntent);
				ABActivity.this.finish();
			}
		});
		this.Button1.setOnClickListener(new View.OnClickListener() {
			public void onClick(View paramAnonymousView) {
				ABActivity.this.finish();
			}
		});
	}

	public Common getApplicationContext() {
		return (Common) super.getApplicationContext();
	}

	protected void onCreate(Bundle paramBundle) {
		super.onCreate(paramBundle);
		setContentView(R.layout.ab);
		this.max = getApplicationContext().getMaxXiaojie();
		if (this.max <= 0) {
			return;
		}
		initview();
	}
}
