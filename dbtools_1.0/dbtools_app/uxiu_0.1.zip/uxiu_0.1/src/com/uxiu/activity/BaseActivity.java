/**
 * Copyright c NTT DATA CORPORATION 2012 All Rights Reserved.
 * ShougaiActivity.java
 */
package com.uxiu.activity;

import org.apache.log4j.Logger;

import android.app.Activity;



public abstract class BaseActivity extends Activity {

	protected static Logger logger = new Logger(BaseActivity.class);

	static {
		AppContext.setExceptionHandler(new UxiuExceptionHandler());
		Thread.setDefaultUncaughtExceptionHandler(AppContext.getExceptionHandler());
	}

}
