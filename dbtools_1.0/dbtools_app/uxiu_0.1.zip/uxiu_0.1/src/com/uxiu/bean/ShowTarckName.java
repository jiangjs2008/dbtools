package com.uxiu.bean;

public class ShowTarckName
{
  public String tarckname = "";
  public String tarckpath = "";
}

/* Location:           C:\Downloads\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.uxiu.bean.ShowTarckName
 * JD-Core Version:    0.6.2
 */