package com.uxiu.bean;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import android.os.Environment;

public class MusicFileUtil {

	public static String getYouXiuPath() {
		String str = Environment.getExternalStorageDirectory().toString() + "/�������";
		File localFile = new File(str);
		if (!localFile.exists()) {
			localFile.mkdirs();
		}
		return str;
	}

	public static ArrayList<HashMap<String, Object>> getMusicFile(String pathName) {
		ArrayList<HashMap<String, Object>> paramList = new ArrayList<HashMap<String, Object>>();
		File[] arrayOfFile = new File(pathName).listFiles();
		Arrays.sort(arrayOfFile);
		for (File musicDir : arrayOfFile) {
			if (musicDir.isDirectory()) {
				HashMap<String, Object> item = new HashMap<String, Object>(4);
				Select1 localSelect1 = new Select1();
				localSelect1.file = musicDir;
				localSelect1.Selectname = musicDir.getName();
				localSelect1.Selectpath = musicDir.getAbsolutePath();
				item.put("file", musicDir);
				item.put("Selectname", localSelect1.Selectname);
				item.put("Selectpath", localSelect1.Selectpath);
				item.put("localSelect1", localSelect1);
				paramList.add(item);
			}
		}
		return paramList;
	}
}
