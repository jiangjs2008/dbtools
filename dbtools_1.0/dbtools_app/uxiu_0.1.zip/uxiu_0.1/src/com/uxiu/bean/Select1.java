package com.uxiu.bean;

import java.io.File;

public class Select1
{
  public String Selectname = "";
  public String Selectpath = "";
  public File file;
}

/* Location:           C:\Downloads\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.uxiu.bean.Select1
 * JD-Core Version:    0.6.2
 */