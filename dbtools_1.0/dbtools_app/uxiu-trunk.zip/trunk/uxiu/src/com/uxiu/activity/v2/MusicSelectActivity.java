package com.uxiu.activity.v2;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import android.app.Dialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.uxiu.bean.MusicTrack;
import com.uxiu.database.StudyDataBaseAdapter;
import com.uxiu.scpark.view.SelectedableListAdapter;
import com.uxiu.util.MusicFileUtil;

public class MusicSelectActivity extends BaseActivity {


	private ListView List1;
	private ListView List2;
	private ListView List3;

	private void initview() {

		this.List1 = ((ListView) findViewById(R.id.List1));
		this.List2 = ((ListView) findViewById(R.id.List2));
		this.List3 = ((ListView) findViewById(R.id.List3));

		// ��������Ŀ¼һ��
		ArrayList<HashMap<String, String>> dirList = MusicFileUtil.getMusicFile(MusicFileUtil.getYouXiuPath());
		SelectedableListAdapter select1Adapter = new SelectedableListAdapter(this, dirList, R.layout.list1, new String[] { "Selectname" }, new int[] { R.id.TextDuration });
		select1Adapter.setSelectedItem(0);

		this.List1.setAdapter(select1Adapter);
		this.List1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@SuppressWarnings("unchecked")
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				SelectedableListAdapter listItemAdapter = (SelectedableListAdapter) ((ListView) parent).getAdapter();
				HashMap<String, String> famItem = (HashMap<String, String>) listItemAdapter.getItem(position);

				ArrayList<HashMap<String, String>> fileList = MusicFileUtil.getMusicFile((String) famItem.get("Selectpath"));

				SelectedableListAdapter select2Adapter = new SelectedableListAdapter(getBaseContext(), fileList, R.layout.list2, new String[] { "Selectname" }, new int[] { R.id.TextDuration });
				List2.setAdapter(select2Adapter);
			}
		});

		// ����������һ��
		if (dirList.size() > 0) {

			ArrayList<HashMap<String, String>> fileList = MusicFileUtil.getMusicFile((String) dirList.get(0).get("Selectpath"));
			SelectedableListAdapter select2Adapter = new SelectedableListAdapter(this, fileList, R.layout.list2, new String[] { "Selectname" }, new int[] { R.id.TextDuration });

			this.List2.setAdapter(select2Adapter);
			this.List2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@SuppressWarnings("unchecked")
				@Override
				public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
					SelectedableListAdapter listItemAdapter = (SelectedableListAdapter) ((ListView) parent).getAdapter();
					HashMap<String, String> famItem = (HashMap<String, String>) listItemAdapter.getItem(position);

					String str = (String) famItem.get("Selectpath") + "/" + (String) famItem.get("Selectname") + ".txt";

					StudyDataBaseAdapter.insertData((String) famItem.get("Selectname"), (String) famItem.get("Selectpath"));
					AppContext.setMusicPath((String) famItem.get("Selectpath"));
					AppContext.setMusicName((String) famItem.get("Selectname"));

					new ProcAsyncTask().execute(str);
				}
			});
		}

		// ����ѧϰ��¼һ��
//		this.select3Adapter = new Select1Adapter(this, this.select3, 3);
//		this.List3.setAdapter(this.select3Adapter);
		this.List3.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			public void onItemClick(AdapterView<?> paramAnonymousAdapterView, View paramAnonymousView,
					int paramAnonymousInt, long paramAnonymousLong) {
//				if (MusicSelectActivity.this.getApplicationContext().CheckTrack(
//						((Select1) MusicSelectActivity.this.select3.get(paramAnonymousInt)).Selectpath)) {
////					SelectActivity.this.getApplicationContext().select = ((Select1) SelectActivity.this.select3
////							.get(paramAnonymousInt));
//					File localFile = new File(
//							((Select1) MusicSelectActivity.this.select3.get(paramAnonymousInt)).Selectpath);
//					if (localFile.exists()) {
//						Date localDate = new Date();
////						SelectActivity.this.getApplicationContext().select.file = localFile;
//						String str = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(localDate);
//						System.out.println("------------path--------------------"
//								+ ((Select1) MusicSelectActivity.this.select3.get(paramAnonymousInt)).Selectpath);
//						MusicSelectActivity.this.getApplicationContext();
//						Common.TrackPath = ((Select1) MusicSelectActivity.this.select3.get(paramAnonymousInt)).Selectpath;
//						MusicSelectActivity.this.studyDataBaseAdapter.insert(
//								(Select1) MusicSelectActivity.this.select3.get(paramAnonymousInt), str);
//						System.out.println("---------------------------------");
//						gotoOtherActivity(AudioPlayerActivity.class);
//						return;
//					}
//					Toast.makeText(MusicSelectActivity.this, "��Ŀ���ݲ���ȷ����ѡ��������Ŀ", Toast.LENGTH_LONG).show();
//					return;
//				}
				Toast.makeText(MusicSelectActivity.this, "��Ŀ���ݲ���ȷ����ѡ��������Ŀ", Toast.LENGTH_LONG).show();
			}
		});

	}

	private void loadsearch() {
//		getApplicationContext().allSelect1s.clear();
//		int i = this.select1.size();
//		int j = 0;
//		if (j >= i)
//			return;
//		File[] arrayOfFile = new File(((Select1) this.select1.get(j)).Selectpath).listFiles();
//		for (int k = 0;; k++) {
//			if (k >= arrayOfFile.length) {
//				j++;
//				break;
//			}
//			if (arrayOfFile[k].isDirectory())
//				getApplicationContext().allSelect1s.add(arrayOfFile[k].getName());
//		}
	}

	private boolean name() {
		SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Object localObject = new Date();
		try {
			Date localDate2 = localSimpleDateFormat.parse("2013-7-1");
			localObject = localDate2;
			Date localDate1 = new Date();
			localDate1.getTime();
			if (localDate1.getTime() - ((Date) localObject).getTime() > 0L) {
				Toast.makeText(this, "�����޷�ʹ��", Toast.LENGTH_LONG).show();
				return false;
			}
		} catch (ParseException localParseException) {
			localParseException.printStackTrace();
		}
		return true;
	}

	private void search(String paramString) {
//		this.SelectClass = 0;
//		this.SelectTrack = 0;
//		int i = this.select1.size();
//		int j = 0;
//		if (j >= i)
//			return;
//		File[] arrayOfFile = new File(((StudyData) this.select1.get(j)).Selectpath).listFiles();
//		for (int k = 0;; k++) {
//			if (k >= arrayOfFile.length) {
//				j++;
//				break;
//			}
//			System.out.println(paramString);
//			System.out.println("fs[i].getName()" + arrayOfFile[k].getName());
//			if ((arrayOfFile[k].isDirectory()) && (arrayOfFile[k].getName().contains(paramString))) {
//				this.SelectClass = j;
//				this.SelectTrack = k;
//				try {
////					this.select2 = getApplicationContext().showAllFiles(this.select2,
////							((Select1) this.select1.get(j)).Selectpath);
////					this.select2Adapter = new Select1Adapter(this, this.select2, 2);
////					this.List2.setAdapter(this.select2Adapter);
//					System.out.println("i" + j + "  j" + k);
//					return;
//				} catch (Exception localException) {
//					localException.printStackTrace();
//				}
//			}
//		}
	}

	private Handler handler = null;

	@Override
	protected void onCreate(Bundle paramBundle) {
		AppContext.setCurrActivity(this);
		super.onCreate(paramBundle);

		// ���ػ���
		setContentView(R.layout.musicselect);
		
		// TODO this.studyDataBaseAdapter = new StudyDataBaseAdapter(this);
//		if (!name()) {
//			return;
//		}

		initview();
		loadsearch();
	}

	/**
	 * ���水ť�����¼�����
	 *
	 * @param v ���水ť����
	 */
	public void onClick(View v) {
		if (v.getId() == R.id.btn_search) {
			// ����������
			EditText nameText = ((EditText) findViewById(R.id.EditText1));
			String str = nameText.getText().toString();
			if (str == null || "".equals(str) || "".equals(str.replace(" ", ""))) {
				Toast.makeText(MusicSelectActivity.this, "��������ȷ��������", Toast.LENGTH_LONG).show();
				return;
			}

//			this.search(str);
//			this.List1.setSelection(MusicSelectActivity.this.SelectClass);
//			this.List1.setSelected(true);
//			this.List2.setSelection(MusicSelectActivity.this.SelectTrack);
//			this.List2.setSelected(true);

		} else if (v.getId() == R.drawable.sty_mbtn_taobao) {
			// ת���Ա���ҳ
			gotoShopWebpage();
		}
	}

	
	/**
	 * ��ͬ�ڄI��
	 */
	private class ProcAsyncTask extends AsyncTask<String, Void, Void> {

		private Dialog msgDialog = null;

		@Override
	    protected void onPreExecute() {
			msgDialog = new Dialog(AppContext.getCurrActivity(), R.style.custom_dialog);
			msgDialog.setContentView(R.layout.hlp_proc);
			msgDialog.setCancelable(false);
			msgDialog.show();
	    }

		@Override
		protected Void doInBackground(String... params) {
			AppContext.setMusicTrack(new MusicTrack(params[0]));
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			if (msgDialog != null) {
				msgDialog.dismiss();
			}
			gotoOtherActivity(AudioPlayerActivity.class);
		}
	}
}
