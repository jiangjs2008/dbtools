package com.uxiu.util;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.StringTokenizer;

public class StringUtil {

	public static String[] split(String str, String sep) {
		if (str == null || sep == null) {
			return null;
		}
		if (str.length() == 0 || sep.length() == 0) {
			return null;
		}
		StringTokenizer token = new StringTokenizer(str, sep);
		String[] array = new String[token.countTokens()];
		for (int i = 0; token.hasMoreTokens(); i++) {
			array[i] = token.nextToken();
		}
		return array;
	}

	public static String encodeString(String strs, String from, String to) {
		if (strs == null || strs.length() == 0) {
			return strs;
		}
		
		try {
			return new String(strs.getBytes(from), to);
		} catch (UnsupportedEncodingException exp) {
			exp.printStackTrace();
			return null;
		}
	}

	public static String encodeString(String strs, String from) {
		if (strs == null || strs.length() == 0) {
			return strs;
		}
		
		try {
			return new String(strs.getBytes(from));
		} catch (UnsupportedEncodingException exp) {
			exp.printStackTrace();
			return null;
		}
	}

	/**
	 * <p>Convert a <code>String</code> to an <code>int</code>, returning
	 * <code>zero</code> if the conversion fails.</p>
	 *
	 * <p>If the string is <code>null</code>, <code>zero</code> is returned.</p>
	 *
	 * <pre>
	 *   NumberUtils.toInt(null) = 0
	 *   NumberUtils.toInt("")   = 0
	 *   NumberUtils.toInt("1")  = 1
	 * </pre>
	 *
	 * @param str  the string to convert, may be null
	 * @return the int represented by the string, or <code>zero</code> if conversion fails
	 */
	public static int parseInt(String str) {
		return parseInt(str, 0);
	}

	public static float parseFloat(String str) {
		return parseFloat(str, 0F);
	}

	/**
	 * <p>Convert a <code>String</code> to an <code>int</code>, returning a
	 * default value if the conversion fails.</p>
	 *
	 * <p>If the string is <code>null</code>, the default value is returned.</p>
	 *
	 * <pre>
	 *   NumberUtils.toInt(null, 1) = 1
	 *   NumberUtils.toInt("", 1)   = 1
	 *   NumberUtils.toInt("1", 0)  = 1
	 * </pre>
	 *
	 * @param str  the string to convert, may be null
	 * @param defaultValue  the default value
	 * @return the int represented by the string, or the default if conversion fails
	 */
	public static int parseInt(String str, int defaultValue) {
		if (str == null) {
			return defaultValue;
		}
		str = str.trim();
		if (str.length() == 0) {
			return defaultValue;
		}
		try {
			return Integer.parseInt(str);
		} catch (NumberFormatException nfe) {
			return defaultValue;
		}
	}
	
	public static float parseFloat(String str, float defaultValue) {
		if (str == null) {
			return defaultValue;
		}
		str = str.trim();
		if (str.length() == 0) {
			return defaultValue;
		}
		try {
			return Float.parseFloat(str);
		} catch (NumberFormatException nfe) {
			return defaultValue;
		}
	}

	/**
	 * get time
	 *
	 * @param dateFormat "yyyy-MM-dd HH:mm:ss.SSS"
	 *
	 * @return String time
	 */
	public static String getCurrentTime(String dateFormat) {
		Calendar now = Calendar.getInstance();
		SimpleDateFormat yearAndMonth = new SimpleDateFormat(dateFormat);
		return yearAndMonth.format(now.getTime());
	}
}
