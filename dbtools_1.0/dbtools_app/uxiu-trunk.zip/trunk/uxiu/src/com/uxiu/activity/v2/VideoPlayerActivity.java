package com.uxiu.activity.v2;

import io.vov.vitamio.LibsChecker;
import io.vov.vitamio.MediaPlayer;
import io.vov.vitamio.MediaPlayer.OnCompletionListener;
import io.vov.vitamio.MediaPlayer.OnPreparedListener;
import io.vov.vitamio.widget.VideoView;

import java.text.DecimalFormat;
import java.util.TimerTask;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import android.content.Context;
import android.hardware.usb.UsbManager;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.uxiu.bean.PlayerState;
import com.uxiu.error.MsgDialog;
import com.uxiu.scpark.usbserial.driver.UsbSerialDriver;
import com.uxiu.scpark.usbserial.util.SerialInputOutputManager;
import com.uxiu.scpark.view.RangeSeekBar;
import com.uxiu.scpark.view.RangeSeekBar.OnRangeSeekBarChangeListener;
import com.uxiu.scpark.view.RangeSeekBar.OnThumbTouchListener;
import com.uxiu.scpark.view.RangeSeekBar.Thumb;

public class VideoPlayerActivity extends BaseActivity
		implements OnPreparedListener, OnCompletionListener, OnRangeSeekBarChangeListener, OnThumbTouchListener {

	private ImageView ImageViewConn = null;
	private final String TAG = VideoPlayerActivity.class.getSimpleName();

	public boolean connectflg = true;


	private final ExecutorService mExecutor = Executors.newSingleThreadExecutor();

	private final SerialInputOutputManager.Listener mListener = new SerialInputOutputManager.Listener() {
		public void onNewData(final byte[] paramAnonymousArrayOfByte) {
			runOnUiThread(new Runnable() {
				public void run() {
					//updateReceivedData(paramAnonymousArrayOfByte);
				}
			});
		}

		public void onRunError(Exception paramAnonymousException) {
			// Log.d(TAG, "Runner stopped.");
		}
	};
	public UsbSerialDriver mSerialDevice;
	private SerialInputOutputManager mSerialIoManager;

	private UsbManager mUsbManager;
	

	private Button buttonPlay = null;
	private Button buttonPause = null;
	private Button buttonBackward = null;
	private Button buttonForward = null;
   
	private VideoView mVideoView = null;
	private RangeSeekBar seekBar = null;
	private static PlayerState videoSts = null;

	private boolean canPlayFlg = false;

	private Handler myHandler = new Handler() {
		@Override
		public void handleMessage(Message paramAnonymousMessage) {
			switch (paramAnonymousMessage.what) {
			case PlayerState.MusicActivitySeekBar :
				// ������
				Log.i("", "" + mVideoView.getCurrentPosition());
				seekBar.setProgress((int) mVideoView.getCurrentPosition());
				break;

			case 0:
			case 1:
			case 3:
			case 4:
				
			default:
				break;
			}
		}
	};


	private void onDeviceStateChange() {
		stopIoManager();
		startIoManager();
	}

	private void startIoManager() {
		if (mSerialDevice != null) {
			Log.i(TAG, "Starting io manager ..");
			mSerialIoManager = new SerialInputOutputManager(mSerialDevice, mListener);
			mExecutor.submit(mSerialIoManager);
		}
	}

	private void stopIoManager() {
		if (mSerialIoManager != null) {
			Log.i(TAG, "Stopping io manager ..");
			mSerialIoManager.stop();
			mSerialIoManager = null;
		}
	}


	private TextView musicTime = null;
	private TextView textViewJiepai = null;
	private ImageView imageViewConn = null;

	private ImageButton buttonABPlay = null;
	
	private void initView() {

		this.imageViewConn = (ImageView) findViewById(R.drawable.pic_usb1);

		this.seekBar = (RangeSeekBar) findViewById(R.id.seekBar1);

		this.textViewJiepai = (TextView) findViewById(R.id.TextViewJiepai);
		textViewJiepai.setText("1.0��");
		musicTime = (TextView) findViewById(R.id.musicTime);

		buttonABPlay = (ImageButton) findViewById(R.drawable.pic_ab1);
		buttonPlay = (Button) findViewById(R.drawable.sty_play);
		buttonPause = (Button) findViewById(R.drawable.sty_pause);
		buttonBackward = (Button) findViewById(R.drawable.sty_play_last);
		buttonForward = (Button) findViewById(R.drawable.sty_play_next);
	}

	private MediaPlayer mPlayer = null;
	@Override
	public void onPrepared(MediaPlayer mp) {
		mPlayer = mp;
		canPlayFlg = true;
		// ������
		int i = (int) mVideoView.getDuration();
		i = i / 1000;
		// ��
		int s = i % 60;
		// ����
		int m = 0;
		int k = i / 60;
		if (k > 0) {
			m = k % 60;
		}
		// Сʱ
		int h = 0;
		h = m / 60;
		if (h == 0) {
			musicTime.setText(String.format("00:00/%02d:%02d", m, s));
		} else {
			musicTime.setText(String.format("0:00:00/%d:%02d:%02d", h, m, s));
		}

		seekBar.setProgressThumbValue(0, (int) mVideoView.getDuration());

    	// ��ȡ�ֻ���ǰ����ֵ
		AudioManager audioMng = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
    	int volume = audioMng.getStreamVolume(AudioManager.STREAM_MUSIC);
    	int maxVolume = audioMng.getStreamMaxVolume(AudioManager.STREAM_MUSIC);

    	videoSts.currVolume = (float) volume / (float) maxVolume;
    	mp.setVolume(videoSts.currVolume, videoSts.currVolume);

		doPerformClick(R.drawable.sty_play);
		try {
			Thread.sleep(500);
		} catch (InterruptedException exp) {
		}
		doPerformClick(R.drawable.sty_pause);
		mVideoView.seekTo(0);
	}

	@Override
	public void onCompletion(MediaPlayer mp) {
		// ���Ž������ص���ʼ״̬
		videoSts.isStop = true;
		if (mVideoView != null) {
			mVideoView.pause();
			mVideoView.seekTo(0);
		}
		playerThread = null;
		seekBar.setProgress(0);
		doPerformClick(R.drawable.sty_play);
		try {
			Thread.sleep(500);
		} catch (InterruptedException exp) {
		}
		doPerformClick(R.drawable.sty_pause);
		mVideoView.seekTo(0);
	}

	@Override
	public void onRangeSeekBarValuesChanged(RangeSeekBar bar, int minValue, int maxValue) {
		videoSts.playingNoteIdx = minValue;
		videoSts.startNodeIdx = minValue;
		videoSts.endNodeIdx = maxValue;
	}

	@Override
	public void onSeekBarValuesChanged(RangeSeekBar bar, int progressValue) {
		videoSts.playingNoteIdx = progressValue;
		videoSts.startNodeIdx = progressValue;
		videoSts.endNodeIdx = (int) mVideoView.getDuration();
	}

	@Override
	public void onThumbTouch(Thumb v) {
		doPerformClick(R.drawable.sty_pause);
	}

	public void onCreate(Bundle paramBundle) {
		AppContext.setCurrActivity(this);
		super.onCreate(paramBundle);
		if (!LibsChecker.checkVitamioLibs(this)) {
			Log.i("LibsChecker", "error");
			return;
		}
		setContentView(R.layout.videoplayer);
		initView();

		videoSts = new PlayerState();
		videoSts.defaultJiepaiMun = 1;
		videoSts.jiepaiMun = 1;

		// ������
		seekBar = (RangeSeekBar) findViewById(R.id.seekBar1);
		seekBar.setOnRangeSeekBarChangeListener(this);
		seekBar.setOnThumbTouchListener(this);

		mVideoView = (io.vov.vitamio.widget.VideoView) findViewById(R.id.videoView1);


		String fileName = AppContext.getMusicPath() + "/" + AppContext.getMusicName() + ".avi";
		mVideoView.setVideoPath(fileName);
		mVideoView.requestFocus();
		mVideoView.setOnPreparedListener(this);
		mVideoView.setOnCompletionListener(this);
	}

	private class SeekBarRunnable extends Thread {
		@Override
		public void run() {
			while (true) {
				if (videoSts != null) {
					while (!videoSts.isPlaying) {
						// ��ͣ����
					}
					if (videoSts.isStop) {
						// ֹͣ����
						break;
					}
				}

				// ��ʾ��Ƶ���Ž�����
				myHandler.sendEmptyMessage(PlayerState.MusicActivitySeekBar);

				try {
					Thread.sleep(500);
				} catch (InterruptedException exp) {
				}
			}
		}
	}

	/**
	 * ���水ť�����¼�����
	 *
	 * @param v ���水ť����
	 */
	public void onClick(View v) {
		doPerformClick(v.getId());
	}

	private SeekBarRunnable playerThread = null;
	private java.util.Timer abPlayTimer = null;

	private void doPerformClick(int viewId) {
		switch (viewId) {
		case R.drawable.sty_play :
			// ����
			if (canPlayFlg) {
				if (playerThread == null) {
					// ������Ƶ(��һ��)
					videoSts.isPlaying = true;
					buttonPlay.setVisibility(View.GONE);
					buttonPause.setVisibility(View.VISIBLE);

					if (videoSts.playingNoteIdx != 0) {
						// ������������ı�
						mVideoView.seekTo(videoSts.playingNoteIdx);
						videoSts.playingNoteIdx = 0;
					}
					mVideoView.start();
					// ����������
					playerThread = new SeekBarRunnable();
					playerThread.start();

				} else {
					// �������ͣ״̬
					if (videoSts.playingNoteIdx != 0) {
						// ������������ı�
						mVideoView.seekTo(videoSts.playingNoteIdx);
						videoSts.playingNoteIdx = 0;
					}
					videoSts.isPlaying = true;
					buttonPlay.setVisibility(View.GONE);
					buttonPause.setVisibility(View.VISIBLE);

					mVideoView.start();
				}
				
				if (videoSts.isABPlaying) {
					// �����ABѭ������״̬
					abPlayTimer = new java.util.Timer(true);
					TimerTask task = new TimerTask() {
						public void run() {
							mVideoView.seekTo(videoSts.startNodeIdx);
						}
					};
					abPlayTimer.schedule(task, 0, videoSts.endNodeIdx - videoSts.startNodeIdx);
				}
			} else {
				MsgDialog msg = new MsgDialog();
				msg.showMessage("���ڼ����У����Ե�...");
			}
			break;

		case R.drawable.sty_pause :
			// ��ͣ
			// ��ͣ����
			videoSts.isPlaying = false;
			mVideoView.pause();
			buttonPlay.setVisibility(View.VISIBLE);
			buttonPause.setVisibility(View.GONE);
			break;

		case R.drawable.pic_ab1 :
			// ABѭ������
			// ����ǲ���״̬,����ͣ����
			if (videoSts.isPlaying) {
				videoSts.isPlaying = false;
				mVideoView.pause();
				buttonPlay.setVisibility(View.VISIBLE);
				buttonPause.setVisibility(View.GONE);
			}

			if (videoSts.isABPlaying) {
				// ȡ��ABѭ������
				videoSts.isABPlaying = false;
				buttonABPlay.setBackgroundResource(R.drawable.pic_ab1);

				buttonBackward.setEnabled(true);
				buttonForward.setEnabled(true);

				if (abPlayTimer != null) {
					abPlayTimer.cancel();
				}
			} else {
				// �趨ΪABѭ������
				videoSts.isABPlaying = true;
				buttonABPlay.setBackgroundResource(R.drawable.pic_ab2);

				buttonBackward.setEnabled(false);
				buttonForward.setEnabled(false);
			}

			videoSts.startNodeIdx = (int) mVideoView.getCurrentPosition();
			videoSts.endNodeIdx = (int) mVideoView.getDuration();
			seekBar.setProgressThumbValue(videoSts.startNodeIdx, videoSts.endNodeIdx);
			seekBar.setSecondThumb(videoSts.isABPlaying);
			return;

		case R.drawable.sty_play_last :
			// ��������һ����
			mVideoView.seekTo(mVideoView.getCurrentPosition() - 5000);
			break;

		case R.drawable.sty_play_next :
			// ǰ������һ����
			mVideoView.seekTo(mVideoView.getCurrentPosition() + 5000);
			break;

		case R.drawable.sty_btn_sub :
			// ������Ƶ�����ٶ� - ����
			if (videoSts.jiepaiMun <= 0.5F) {
				break;
			}
			videoSts.jiepaiMun = videoSts.jiepaiMun - 0.1F;
			this.textViewJiepai.setText(myFormatter.format(videoSts.jiepaiMun) + "��");

			// ���ٲ���
			mPlayer.setPlaybackSpeed(videoSts.jiepaiMun);
			break;

		case R.drawable.sty_btn_add :
			// ������Ƶ�����ٶ� - ����
			if (videoSts.jiepaiMun >= 2) {
				break;
			}
			videoSts.jiepaiMun = videoSts.jiepaiMun + 0.1F;
			this.textViewJiepai.setText(myFormatter.format(videoSts.jiepaiMun) + "��");

			// ���ٲ���
			mPlayer.setPlaybackSpeed(videoSts.jiepaiMun);
			break;

		case R.drawable.sty_mbtn_audio:
			// �ص��������Ż���
			videoSts.isStop = true;
			gotoOtherActivity(AudioPlayerActivity.class);
			break;

		case R.drawable.sty_mbtn_catalog:
			// �ص���Ŀѡ����
			videoSts.isStop = true;
			gotoOtherActivity(MusicSelectActivity.class);
			break;

		case R.drawable.sty_mbtn_taobao:
			// ת���Ա���ҳ
			videoSts.isStop = true;
			gotoShopWebpage();
			break;

		default:
			break;
		}
	}

	private static DecimalFormat myFormatter = new DecimalFormat("0.0");

	@Override
	protected void onStop() {
		super.onStop();
		if (mVideoView != null) {
			mVideoView.stopPlayback();
		}
		videoSts = null;
	}


	void sendTestConnData() {
		try {
			mSerialDevice.write("TestConn".getBytes(), 5);
			ImageViewConn.setImageResource(2130837568);
			return;
		} catch (Exception localException) {
			localException.printStackTrace();
			ImageViewConn.setImageResource(2130837567);
		}
	}

}
