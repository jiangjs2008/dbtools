package com.uxiu.util;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import android.os.Environment;

public class MusicFileUtil {


	public static String getYouXiuPath() {
		String str = Environment.getExternalStorageDirectory().toString() + "/�������";
		File localFile = new File(str);
		if (!localFile.exists()) {
			localFile.mkdirs();
		}
		return str;
	}

	public static ArrayList<HashMap<String, String>> getMusicFile(String pathName) {
		ArrayList<HashMap<String, String>> paramList = new ArrayList<HashMap<String, String>>();
		File[] arrayOfFile = new File(pathName).listFiles();
		Arrays.sort(arrayOfFile);
		for (File musicDir : arrayOfFile) {
			if (musicDir.isDirectory()) {
				HashMap<String, String> item = new HashMap<String, String>(2);
				item.put("Selectname", musicDir.getName());
				item.put("Selectpath", musicDir.getAbsolutePath());
				paramList.add(item);
			}
		}
		return paramList;
	}
}
