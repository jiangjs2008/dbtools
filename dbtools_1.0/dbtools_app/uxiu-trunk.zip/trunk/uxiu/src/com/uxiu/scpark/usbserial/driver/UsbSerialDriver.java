package com.uxiu.scpark.usbserial.driver;

import java.io.IOException;

public abstract interface UsbSerialDriver
{
  public abstract void close()
    throws IOException;

  public abstract void open()
    throws IOException;

  public abstract int read(byte[] paramArrayOfByte, int paramInt)
    throws IOException;

  public abstract int setBaudRate(int paramInt)
    throws IOException;

  public abstract int write(byte[] paramArrayOfByte, int paramInt)
    throws IOException;
}

/* Location:           C:\Downloads\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.uxiu.scpark.usbserial.driver.UsbSerialDriver
 * JD-Core Version:    0.6.2
 */