package com.uxiu.activity.v2;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import com.uxiu.database.StudyDataBaseAdapter;
import com.uxiu.scpark.engine.SoundPlayer;

public class InitActivity extends BaseActivity {

	private Handler handler = null;

	@Override
	protected void onCreate(Bundle paramBundle) {
		AppContext.setCurrActivity(this);
		super.onCreate(paramBundle);
		setContentView(R.layout.hlp_init);
		
		// ��ʼ�������������ļ�
		Runnable initPlayer = new Runnable () {
			@Override
			public void run() {
				SoundPlayer.init(getBaseContext());
			}
		};
		new Thread(initPlayer).start();

		handler = new Handler() {
			@Override
			public void handleMessage(Message msg) {
				if (msg.what == 1) {
					gotoOtherActivity(MusicSelectActivity.class);
				}
			}
		};

		Runnable runnable = new Runnable() {
			@Override
			public void run() {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException exp) {
				}
				handler.sendEmptyMessage(1);
			}
		};
		new Thread(runnable).start();
		
		// ��ʼ�����ݿ�
		StudyDataBaseAdapter.init();
	}
}
