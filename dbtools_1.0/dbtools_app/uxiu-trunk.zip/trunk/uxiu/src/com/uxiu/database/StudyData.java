package com.uxiu.database;

public class StudyData {
	public int id = 0;
	public String selectName = null;
	public String selectPath = null;
	public String datatime = null;
}
