package com.uxiu.activity.v2;

import android.app.Activity;

import com.uxiu.bean.MusicTrack;
import com.uxiu.error.ExceptionHandler;

public final class AppContext {

	private static Activity innActivity = null;
	//private static Stack<Activity> baseActivity = new Stack<Activity>();

	private static ExceptionHandler sgeh = null;

	/**
	 * Retrieve the Activity that is currently running.
	 * 
	 * @return the currently running Activity
	 */
	public static void setCurrActivity(Activity activity) {
		innActivity = activity;
	}

	/**
	 * Retrieve the Activity that is currently running.
	 * 
	 * @return the currently running Activity
	 */
	public static Activity getCurrActivity() {
		return innActivity;
	}


	public static ExceptionHandler getExceptionHandler() {
		return sgeh;
	}

	public static void setExceptionHandler(ExceptionHandler eh) {
		sgeh = eh;
	}

	private static MusicTrack track = null;

	public static MusicTrack getMusicTrack() {
		return track;
	}

	public static void setMusicTrack(MusicTrack musicTrack) {
		track = musicTrack;
	}

	private static String musicPath = null;
	
	private static String musicName = null;

	public static String getMusicPath() {
		return musicPath;
	}

	public static void setMusicPath(String musicPathValue) {
		musicPath = musicPathValue;
	}

	public static String getMusicName() {
		return musicName;
	}

	public static void setMusicName(String musicNameValue) {
		musicName = musicNameValue;
	}

}
