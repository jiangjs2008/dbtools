package com.uxiu.database;

import java.util.ArrayList;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.uxiu.activity.v2.AppContext;
import com.uxiu.util.StringUtil;

public class StudyDataBaseAdapter {

	private static final String DB_CREATE = "CREATE TABLE study (_id INTEGER PRIMARY KEY, TrackName TEXT, TrackPath TEXT, DateTime TEXT)";
	private static String getTblList = "select tbl_name from sqlite_master where type='table' and tbl_name='study'";
	private static final String DB_NAME = "study.db";

	private static SQLiteDatabase mSQLiteDatabase = null;

	public static void init() {
		Cursor stmt = null;
		try {
			mSQLiteDatabase = AppContext.getCurrActivity().openOrCreateDatabase(DB_NAME, Context.MODE_WORLD_WRITEABLE, null);

			// �����Ƿ����
			stmt = mSQLiteDatabase.rawQuery(getTblList, null);
			if (stmt.getCount() == 0) {
				// ��������
				mSQLiteDatabase.execSQL(DB_CREATE);
			}
		} catch (Exception rtex) {
			rtex.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
			} catch (Exception rtex) {
				rtex.printStackTrace();
			}
		}
	}

	public static void close() {
		if (mSQLiteDatabase != null) {
			mSQLiteDatabase.close();
		}
	}

	public boolean deleteData(long paramLong) {
		return mSQLiteDatabase.delete("study", "_id=" + paramLong, null) > 0;
	}

	public static ArrayList<StudyData> getAllStudyData() {
		Cursor stmt = null;
		try {
			stmt = mSQLiteDatabase.rawQuery("select * from study order by DateTime desc", null);
			ArrayList<StudyData> dataList = new ArrayList<StudyData>(stmt.getCount());
			StudyData data = null;
			while (stmt.moveToNext()) {
				data = new StudyData();
				data.id = stmt.getInt(0);
				data.selectName = stmt.getString(1);
				data.selectPath = stmt.getString(2);
				data.datatime = stmt.getString(3);
				dataList.add(data);
			}
			return dataList;

		} catch (Exception rtex) {
			rtex.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
			} catch (Exception rtex) {
				rtex.printStackTrace();
			}
		}
		return new ArrayList<StudyData>(0);
	}


	private static int generateMaxId() {
		Cursor stmt = null;
		try {
			stmt = mSQLiteDatabase.rawQuery("select count(_id) as datacnt from study", null);
			int maxId = 0;
			if (stmt.moveToNext()) {
				maxId = stmt.getInt(0);
			}
			return maxId + 1;

		} catch (Exception rtex) {
			rtex.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
			} catch (Exception rtex) {
				rtex.printStackTrace();
			}
		}
		return 1;
	}

	public static void insertData(String selectName, String selectPath) {
		Object[] bindArgs = new Object[4];
		bindArgs[0] = generateMaxId();
		bindArgs[1] = selectName;
		bindArgs[2] = selectPath;
		bindArgs[3] = StringUtil.getCurrentTime("yyyyMMddHHmmssSSS");

		try {
			mSQLiteDatabase.execSQL("insert into study (_id, TrackName, TrackPath, DateTime) values (?, ?, ?, ?)", bindArgs);
		} catch (Exception rtex) {
			rtex.printStackTrace();
		}
	}

	public static void updateData(int param1, String paramString) {
		Object[] bindArgs = new Object[2];
		bindArgs[0] = param1;
		bindArgs[1] = paramString;

		try {
			mSQLiteDatabase.execSQL("update study set DateTime = ? where _id = ?", bindArgs);
		} catch (Exception rtex) {
			rtex.printStackTrace();
		}
	}

}
