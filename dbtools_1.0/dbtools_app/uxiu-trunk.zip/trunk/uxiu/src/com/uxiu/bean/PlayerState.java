package com.uxiu.bean;

public final class PlayerState {
	

	public static final int MusicActivitySeekBar = 2;
	public static final int MusicActivityPhotoInitMsg = 3;
	public static final int MusicActivityPhotoMsg = 4;
	public static final int MusicActivityPlayEnd = 5;

	public static final int MusicActivityConnect = 6;

	public static final int MusicActivitySignal = 9;

	public static final int PlayAB = 13;

	public static final int SetSatrtindex = 15;
	public static final int ViewTB1 = 11;
	public static final int ViewTB2 = 12;
		
	
	public static final float YOffset = 0.8533334F;
	

	public volatile int playingNoteIdx = 0;
	

	public boolean isPlaying = false;
	public boolean isStop = false;
	public boolean isLeftPlayable = false;
	public boolean isRightPlayable = false;
	public boolean isABPlaying = false;
	public boolean isZYPlaying = false;

	/**
	 * �Ƿ���FLG
	 */
	public boolean isMute = false;
	/**
	 * ��ǰ����
	 */
	public float currVolume = 0;
	

	public int startNodeIdx = 0;
	public int endNodeIdx = 0;

	/**
	 * ÿ���ӽ�����
	 */
	public float jiepaiMun = 0F;
	public float defaultJiepaiMun = 0F;
	/**
	 * ���ĵ���ʱ�ı��� 0.5~2.0
	 */
	public float noteSpanTimeScale = 0F;
	
	
	public int lastImgIndex = 0;
	public String lastImgFile = null;
}
