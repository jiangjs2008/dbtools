package com.uxiu.scpark.usbserial.util;

public class Constant
{
  public static String BK = "BK";
  public static String FW = "FW";
}

/* Location:           C:\Downloads\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.uxiu.scpark.usbserial.util.Constant
 * JD-Core Version:    0.6.2
 */