package com.uxiu.bean;

import java.util.ArrayList;

import android.content.res.Resources;
import android.graphics.Point;

import com.uxiu.activity.v2.AppContext;
import com.uxiu.util.StringUtil;

/**
 * ������������Ӧ�������ٰ���������
 */
public class MusicNote {

	//private static Logger logger = new Logger(MusicNote.class);

	public static enum NoteType { NOTE_LA, NOTE_LB, NOTE_RA, NOTE_RB, NOTE_GROUP };

	/**
	 * ��������
	 */
	private NoteType noteType = null;
	private int sectionNum = 0;
	private int noteNum = 0;
	// TODO --private String degree = null;

	/**
	 * ������������ֵ
	 */
	private float jiepaiValue = 0F;
	/**
	 * ��������ʱ��(����)
	 */
	private int jiepaiTime = 0;
	/**
	 * ������λʱ���ߣ����룩
	 */
	private float jiepaiAddup = 0F;


	private int subNoteCnt = 0;
	private String[] subNoteList = null;
	private ArrayList<Integer> musicRawIdList = null;

	private String imageName = null;
	private int imgListIdx = 0;

	private Point coordinate = null;

	private static final String packageName = AppContext.getCurrActivity().getPackageName();
	private static Resources appRes = AppContext.getCurrActivity().getResources();

	public void setNoteInfo(NoteType noteType, String noteInfo) {

		String[] items = StringUtil.split(noteInfo, "=");
		String[] header = StringUtil.split(items[0], ",");

		this.noteType = noteType;

		sectionNum = StringUtil.parseInt(header[0].substring(2));
		noteNum = StringUtil.parseInt(header[1]);

		String[] infos = StringUtil.split(items[1], "+");
		// TODO --degree = infos[0];
		String jiepai = infos[1];
		String[] jiepaiInfo = StringUtil.split(jiepai, "/");
		if ("0".equals(jiepaiInfo[1])) {
			jiepaiValue = StringUtil.parseInt(jiepaiInfo[0]);
		} else {
			jiepaiValue = StringUtil.parseFloat(jiepaiInfo[0]) / StringUtil.parseFloat(jiepaiInfo[1]);
		}

		subNoteCnt = StringUtil.parseInt(infos[3]);
		subNoteList = StringUtil.split(infos[4], ",");
		musicRawIdList = new ArrayList<Integer>(subNoteCnt);
		for (int i = 0; i < subNoteCnt; i ++) {
			if ("0".equals(subNoteList[i])) {
				continue;
			}
			String[] paramString = StringUtil.split(subNoteList[i], "/");
			String musicFile = "a" + paramString[0].toLowerCase().replace("#", "_");
			musicRawIdList.add(appRes.getIdentifier(musicFile, "raw", packageName));
		}

		String[] picInfo = StringUtil.split(infos[5], ",");
		imageName = picInfo[0];
		coordinate = new Point(StringUtil.parseInt(picInfo[1]), StringUtil.parseInt(picInfo[2]));
	}
	
	private String sendData(String paramString1, String paramString2, String paramString3, int paramInt) {
		if (paramInt == 0) {
			return "ST+L+" + paramString3 + "+" + paramString2 + "+" + paramString1 + "+OV";
		} else {
			return "ST+R+" + paramString3 + "+" + paramString2 + "+" + paramString1 + "+OV";
		}
	}


	public NoteType getNoteType() {
		return this.noteType;
	}

	public int getSectionNum() {
		return this.sectionNum;
	}

	public int getNoteNum() {
		return this.noteNum;
	}

	public ArrayList<Integer> getMusicRawIdList() {
		return this.musicRawIdList;
	}

	public float getJiepaiValue() {
		return jiepaiValue;
	}

	public String getImageName() {
		return imageName;
	}

	public Point getCoordinate() {
		return coordinate;
	}

	public int getJiepaiTime() {
		return jiepaiTime;
	}

	public void setJiepaiTime(int jiepaiTime) {
		this.jiepaiTime = jiepaiTime;
	}


	public float getJiepaiAddup() {
		return jiepaiAddup;
	}

	public void setJiepaiAddup(float jiepaiAddup) {
		this.jiepaiAddup = jiepaiAddup;
	}


	public int getImgListIdx() {
		return imgListIdx;
	}

	public void setImgListIdx(int imgListIdx) {
		this.imgListIdx = imgListIdx;
	}

}
