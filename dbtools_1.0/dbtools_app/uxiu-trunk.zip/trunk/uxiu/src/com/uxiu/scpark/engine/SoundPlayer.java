package com.uxiu.scpark.engine;

import java.lang.reflect.Field;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import android.content.Context;
import android.media.AudioManager;
import android.media.SoundPool;
import android.media.SoundPool.OnLoadCompleteListener;
import android.util.SparseIntArray;

import com.uxiu.activity.v2.R;
import com.uxiu.bean.GroupNote;
import com.uxiu.bean.MusicNote;
import com.uxiu.bean.MusicNote.NoteType;

/**
 * ����������
 * 
 */
public class SoundPlayer {

	private static Logger logger = new Logger(MusicNote.class);

	private static SoundPool soundPool;
	private static SparseIntArray soundMap; // ��Ч��Դid����ع������Դid��ӳ���ϵ��


	private static boolean canPlay = false;

	public boolean canPlay() {
		return canPlay;
	}

	/**
	 * ��ʼ������
	 * 
	 * @param c
	 */
	public static void init(Context c) {
		soundPool = new SoundPool(10, AudioManager.STREAM_SYSTEM, 100);
		soundPool.setOnLoadCompleteListener(new OnLoadCompleteListener() {
			@Override
			public void onLoadComplete(SoundPool soundPool, int sampleId, int status) {
				canPlay = true;
			}
		});

		try {
			Field[] field = R.raw.class.getFields();
			soundMap = new SparseIntArray(field.length);
			for (int i = 0; i < field.length; i++) {
				int str = field[i].getInt(null);
				soundMap.put(str, soundPool.load(c, str, 1));
			}
		} catch (Exception exp) {
			logger.error(exp);
		}
	}

	private float leftVolume = 0.5F;
	private float rightVolume = 0.5F;

	public void setSoundVolume(float leftVolume, float rightVolume) {
		this.leftVolume = leftVolume;
		this.rightVolume = rightVolume;
	}

	/**
	 * ������Ч
	 * 
	 * @param resId ��Ч��Դid
	 */
	public int play(int resId) {
		int soundId = soundMap.get(resId);
		return soundPool.play(soundId, leftVolume, rightVolume, 1, 0, 1);
	}

	public void pause(int playId) {
		soundPool.pause(playId);
	}

	/**
	 * ������Ч
	 *
	 * @param groupNote     ����
	 * @param isLeftUnable  ��������������
	 * @param isRightUnable ��������������
	 */
	public void playSound(GroupNote groupNote, boolean isLeftUnable, boolean isRightUnable) {
		int playId = 0;
		ArrayList<Integer> rawIdList = null;

		ArrayList<MusicNote> refNotesList = groupNote.getRefNoteList();
		if (refNotesList.size() == 1) {
			// ��ͨ(����)����
			MusicNote note = refNotesList.get(0);
			if ((isLeftUnable && note.getNoteType() == NoteType.NOTE_LA)
					|| (isRightUnable  && note.getNoteType() == NoteType.NOTE_RA)) {
				return;
			}
			rawIdList = note.getMusicRawIdList();
			
			if (rawIdList.size() == 1 && rawIdList.get(0) != 0) {
				// ���ŵ�������
				playId = play(rawIdList.get(0));
				new SoundTimerTask(playId, note.getJiepaiTime()).start();

			} else if (rawIdList.size() > 1) {
				// ͬʱ���Ŷ������
				for (int rawId : rawIdList) {
					playId = play(rawId);
					new SoundTimerTask(playId, note.getJiepaiTime()).start();
				}
			}
		} else {
			// ���(���)����
			for (MusicNote single : refNotesList) {
				if ((isLeftUnable && single.getNoteType() == NoteType.NOTE_LA)
						|| (isRightUnable  && single.getNoteType() == NoteType.NOTE_RA)) {
					continue;
				}
				rawIdList = single.getMusicRawIdList();
				if (rawIdList.size() == 1 && rawIdList.get(0) != 0) {
					// ���ŵ�������
					playId = play(rawIdList.get(0));
					new SoundTimerTask(playId, single.getJiepaiTime()).start();

				} else if (rawIdList.size() > 1) {
					// ͬʱ���Ŷ������
					for (int rawId : rawIdList) {
						playId = play(rawId);
						new SoundTimerTask(playId, single.getJiepaiTime()).start();
					}
				}
			}
		}
	}

	private static class SoundTimerTask extends Thread {

		private int playId = 0;
		private long jiepaiTime = 0;

		SoundTimerTask(int playId, long jiepaiTime) {
			this.playId = playId;
			this.jiepaiTime = jiepaiTime;
		}

		@Override
		public void run() {
			try {
				Thread.sleep(jiepaiTime);
			} catch (InterruptedException exp) {
			}
			soundPool.pause(playId);
		}
	}
}
