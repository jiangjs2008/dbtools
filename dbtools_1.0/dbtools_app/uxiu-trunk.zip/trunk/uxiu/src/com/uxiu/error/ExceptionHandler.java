package com.uxiu.error;

import java.lang.Thread.UncaughtExceptionHandler;


public interface ExceptionHandler extends UncaughtExceptionHandler {

	public void execute(Throwable ex);

}
