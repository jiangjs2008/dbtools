package com.uxiu.bean;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Stack;

import org.apache.log4j.Logger;

import com.uxiu.bean.MusicNote.NoteType;
import com.uxiu.util.StringUtil;

public class MusicTrack {

	public String getTitle() {
		return title;
	}

	private static Logger logger = new Logger(MusicTrack.class);

	private String title = null;
	private String author = null;
	private String aDAuthor = null;
	// �����Ľ���
	private int phythm = 0;

	// ÿ���ӽ�����
	private int jiepaiValue = 0;
	// ÿ�����ĵ�ʱ��(��λ:����)
	private float jiepaiTime = 0F;

	// ����С����
	private int sectionCnt = 1000;
	// ��������
	private String contentString = null;

	private ArrayList<MusicNote> mLAnoteList = new ArrayList<MusicNote>();
	private ArrayList<MusicNote> mRAnoteList = new ArrayList<MusicNote>();

	private Stack<String> musicImgList = new Stack<String>();

	ArrayList<GroupNote> singleTrack = null;

	private int[] sectionIdArr = null;
//	SparseArray<Subsection> tabanOpeList = null;

	public MusicTrack(String paramString) {
		logger.debug("create Track start");
		loadData(paramString);
		checkData();
		logger.debug("create Track end");
	}

	public 	ArrayList<GroupNote> getMusicTrack() {
		return singleTrack;
	}

	private void checkData() {
		if (sectionIdArr == null) {
			// ������
			
		}
		for (int secId : sectionIdArr) {
			if (secId == 0) {
				// ȱ��С��
				
			}
		}

		// ��������ͼƬ�б�
		musicImgList.add(mLAnoteList.get(0).getImageName());
		for (MusicNote note : mLAnoteList) {
			if (!musicImgList.peek().equals(note.getImageName())) {
				musicImgList.add(note.getImageName());
			}
			note.setImgListIdx(musicImgList.size() - 1);
		}

		// ������������ʱ����
		float timelineValue = 0F;
		float noteTime = 0F;
		for (MusicNote note : mLAnoteList) {
			noteTime = note.getJiepaiValue() * jiepaiTime;
			note.setJiepaiTime(new BigDecimal(Float.toString(noteTime)).intValue());
			note.setJiepaiAddup(timelineValue);
			timelineValue += noteTime;
		}

		// ������������ʱ����
		timelineValue = 0;
		for (MusicNote note : mRAnoteList) {
			noteTime = note.getJiepaiValue() * jiepaiTime;
			note.setJiepaiTime(new BigDecimal(Float.toString(noteTime)).intValue());
			note.setJiepaiAddup(timelineValue);
			timelineValue += noteTime;
		}

		// �ϲ�����
		MusicNote[] allNoteArr = new MusicNote[mLAnoteList.size() + mRAnoteList.size()];
		System.arraycopy(mLAnoteList.toArray(), 0, allNoteArr, 0, mLAnoteList.size());
		System.arraycopy(mRAnoteList.toArray(), 0, allNoteArr, mLAnoteList.size(), mRAnoteList.size());
		Arrays.sort(allNoteArr, NATURAL_ORDER);

		singleTrack = new ArrayList<GroupNote>(allNoteArr.length);
		int j = 0;
		MusicNote note2 = null;
		for (int i = 0, lens = allNoteArr.length - 1; i < lens; ) {
			note2 = allNoteArr[i];
			float curr = note2.getJiepaiAddup();
			j = 1;

			GroupNote newNote = new GroupNote(note2);
			while (true) {
				if (i + j == lens) {
					break;
				}
				if (!note2.getImageName().equals(allNoteArr[i + j].getImageName())) {
					break;
				}
				if (allNoteArr[i + j].getJiepaiAddup() - curr < 50) {
					newNote.addRefNote(allNoteArr[i + j]);
					j ++;
				} else {
					break;
				}
			}

			newNote.setJiepaiAddup(curr);
			singleTrack.add(newNote);
			i += j;
		}

		// ���¼�����������ʱ��
		singleTrack.trimToSize();
		for (int i =0, lens = singleTrack.size() - 2; i < lens; i ++) {
			singleTrack.get(i).setNoteSpanTime((int) (singleTrack.get(i + 1).getJiepaiAddup() - singleTrack.get(i).getJiepaiAddup()));
		}
	}

	private static final Comparator<MusicNote> NATURAL_ORDER = new Comparator<MusicNote>() {
		@Override
		public int compare(MusicNote first, MusicNote second) {
			return new BigDecimal(Float.toString(first.getJiepaiAddup()))
				.compareTo(new BigDecimal(Float.toString(second.getJiepaiAddup())));
//			if (first.getJiepaiAddup() < second.getJiepaiAddup()) {
//				return -1;
//			} else if (first.getJiepaiAddup() == second.getJiepaiAddup()) {
//				return 0;
//			} else {
//				return 1;
//			}
		}
	};

	private void loadData(String fileName) {
		File musicFile = new File(fileName);
		if (!musicFile.exists()) {
			logger.debug("file not exists");
			return;
		}
		BufferedReader bufread = null;
		try {
			bufread = new BufferedReader(new InputStreamReader(new FileInputStream(musicFile), Charset.forName("GBK")));
			String lineStr = bufread.readLine();
			if (lineStr != null) {
				// TITLE
				this.title = lineStr.substring(lineStr.indexOf('=') + 1, lineStr.length() - 1);
			}

			lineStr = bufread.readLine();
			if (lineStr != null) {
				// AUTHOR
				this.author = lineStr.substring(lineStr.indexOf('=') + 1, lineStr.length() - 1);
			}

			lineStr = bufread.readLine();
			if (lineStr != null) {
				// RHYTHM
				String item = lineStr.substring(lineStr.indexOf('=') + 1, lineStr.length() - 1);
				String[] rhyInfo = StringUtil.split(item, "/");
				if (rhyInfo == null || rhyInfo.length == 0) {
					this.phythm = 0;
				} else {
					this.phythm = StringUtil.parseInt(rhyInfo[0]);
				}
			}

			lineStr = bufread.readLine();
			if (lineStr != null) {
				// JIEPAI
				String item = lineStr.substring(lineStr.indexOf('=') + 1, lineStr.length() - 1);
				this.jiepaiValue = StringUtil.parseInt(item);
				this.jiepaiTime = (float) 60000 / (float) this.jiepaiValue;
			}

			lineStr = bufread.readLine();
			if (lineStr != null) {
				// MAXSECTION
				String item = lineStr.substring(lineStr.indexOf('=') + 1, lineStr.length() - 1);
				this.sectionCnt = StringUtil.parseInt(item);
				this.sectionIdArr = new int[this.sectionCnt];
			}

			lineStr = bufread.readLine();
			if (lineStr != null) {
				// ADAPTOR
				this.aDAuthor = lineStr.substring(lineStr.indexOf('=') + 1, lineStr.length() - 1);
			}

			lineStr = bufread.readLine();
			if (lineStr != null) {
				// DES
				this.contentString = lineStr.substring(lineStr.indexOf('=') + 1, lineStr.length() - 2);
			}

			while ((lineStr = bufread.readLine()) != null) {

				if (lineStr.indexOf("LA") == 0) {
					MusicNote note = new MusicNote();
					note.setNoteInfo(NoteType.NOTE_LA, lineStr);
					sectionIdArr[note.getSectionNum() - 1] = 1;
					mLAnoteList.add(note);

				} else 	if (lineStr.indexOf("RA") == 0) {
					MusicNote note = new MusicNote();
					note.setNoteInfo(NoteType.NOTE_RA, lineStr);
					sectionIdArr[note.getSectionNum() - 1] = 1;
					mRAnoteList.add(note);

				} else if (lineStr.indexOf("LB") == 0 || lineStr.indexOf("RB") == 0) {
					
				} else if (lineStr.indexOf("TABAN ON") == 0) {

					// if (tabanOpeList == null) {
					// tabanOpeList = new SparseArray<Subsection>();
					// }
					// Subsection section = new
					// Subsection(SectionType.SEC_TBNON);
					// tabanOpeList.put(sectionList.size(), section);

				} else if (lineStr.indexOf("TABAN OFF") == 0) {

					// if (tabanOpeList == null) {
					// tabanOpeList = new SparseArray<Subsection>();
					// }
					// Subsection section = new
					// Subsection(SectionType.SEC_TBNOFF);
					// tabanOpeList.put(sectionList.size(), section);
				}
			}
		} catch (Exception exp) {
			exp.printStackTrace();
		} finally {
			if (bufread != null) {
				try {
					bufread.close();
				} catch (IOException exp2) {
					exp2.printStackTrace();
				}
			}
		}
	}


	public int getJiepaiValue() {
		return jiepaiValue;
	}

	public Stack<String> getMusicImgList() {
		return musicImgList;
	}
}
