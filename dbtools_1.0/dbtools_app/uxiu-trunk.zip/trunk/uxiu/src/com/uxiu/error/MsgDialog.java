package com.uxiu.error;

import android.app.Dialog;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import com.uxiu.activity.v2.AppContext;
import com.uxiu.activity.v2.R;

public class MsgDialog {

	private Dialog msgDialog = null;

	public MsgDialog() {
		msgDialog = new Dialog(AppContext.getCurrActivity(), R.style.custom_dialog);
		msgDialog.setContentView(R.layout.hlp_msg);
		msgDialog.setCancelable(false);

		Button btn = (Button) msgDialog.findViewById(R.id.button1);
		btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (msgDialog != null) {
					msgDialog.dismiss();
				}
			}
		});

		msgDialog.show();
	}

	public void showMessage(String msg) {
		TextView text = (TextView) msgDialog.findViewById(R.string.hello);
		text.setText(msg);
	}
}
