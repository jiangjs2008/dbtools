package com.uxiu.activity.v2;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.hardware.usb.UsbManager;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.uxiu.bean.GroupNote;
import com.uxiu.bean.MusicNote;
import com.uxiu.bean.MusicNote.NoteType;
import com.uxiu.bean.MusicTrack;
import com.uxiu.bean.PlayerState;
import com.uxiu.error.MsgDialog;
import com.uxiu.scpark.engine.SoundPlayer;
import com.uxiu.scpark.usbserial.driver.UsbSerialDriver;
import com.uxiu.scpark.usbserial.driver.UsbSerialProber;
import com.uxiu.scpark.usbserial.util.SerialInputOutputManager;
import com.uxiu.scpark.view.RangeSeekBar;
import com.uxiu.scpark.view.RangeSeekBar.OnRangeSeekBarChangeListener;
import com.uxiu.scpark.view.RangeSeekBar.OnThumbTouchListener;
import com.uxiu.scpark.view.RangeSeekBar.Thumb;

public class AudioPlayerActivity extends BaseActivity implements OnRangeSeekBarChangeListener, OnThumbTouchListener {


	private volatile AudioManager audioMng = null;


	private LinearLayout upImgLayout = null;
	private LinearLayout downImgLayout = null;

	private ImageButton buttonLeft = null;
	private ImageButton buttonRight = null;

	private ImageButton buttonABPlay = null;
	private ImageButton buttonZYPlay = null;
	private ImageButton buttonVoice = null;

	private Button buttonPlay = null;
	private Button buttonPause = null;

	private ImageView imageViewConn = null;
	private ImageView imageViewTaban = null;
	// ���������źŵ�
	private ImageView imageViewGreen = null;
	// ���������źŵ�
	private ImageView imageViewRed = null;

	private RangeSeekBar seekBar;


	private boolean Restart = false;

	private final String TAG = AudioPlayerActivity.class.getSimpleName();

	
	private TextView textViewJiepai = null;
	private TextView textViewTitle = null;


	//ClickEvent clickEvent;
	private boolean connectflg = true;

	/**
	 * ����
	 */
	public static MusicTrack musicTrack = null;
	
	private static PlayerState audioSts = null;

	@Override
	public void onRangeSeekBarValuesChanged(RangeSeekBar bar, int minValue, int maxValue) {
		audioSts.playingNoteIdx = minValue;
		audioSts.startNodeIdx = minValue;
		audioSts.endNodeIdx = maxValue;
	}

	@Override
	public void onSeekBarValuesChanged(RangeSeekBar bar, int progressValue) {
		audioSts.playingNoteIdx = progressValue;
		audioSts.startNodeIdx = progressValue;
		audioSts.endNodeIdx = musicTrack.getMusicTrack().size();
	}

	@Override
	public void onThumbTouch(Thumb v) {
		doPerformClick(R.drawable.sty_pause);
	}

	private Handler handler = new Handler() {
		@Override
		public void handleMessage(Message messagePara) {
			switch (messagePara.what) {
			case 8:
				if (musicTrack != null) {
//					getApplicationContext().setMaxXiaojie(mtrack.getXiaoJieNum());
//					TextViewJiepai.setText(jiepaiMun + "��/����");
//					TextViewTitle.setText(file.getName());
//					if (temjiepaiMun != 0) {
//						jiepaiMun = temjiepaiMun;
//						mtrack.setJiepai(jiepaiMun);
//						TextViewJiepai.setText(jiepaiMun + "��/����");
//					}
//					System.out.println("mtrack.getJiepai()" + mtrack.getJiepai());
				//	seekBar.setMax(max);
					//Showphoto(0);
					initSerialDevice();
				}
				//OnclickAble = true;
				break;

			case 0:
				break;
			case PlayerState.MusicActivitySeekBar:
				// ������
				seekBar.setProgress(audioSts.playingNoteIdx);
				break;

			case PlayerState.MusicActivityPhotoInitMsg:
				// ��ʾ����ͼƬ
				int currImgIndex = musicTrack.getMusicTrack().get(audioSts.startNodeIdx).getRefNoteList().get(0).getImgListIdx();
				audioSts.lastImgIndex = currImgIndex;
				audioSts.lastImgFile = musicTrack.getMusicImgList().get(audioSts.lastImgIndex);
				if (audioSts.lastImgIndex + 1 < musicTrack.getMusicImgList().size()) {
					showStaffPicture(musicTrack.getMusicImgList().get(audioSts.lastImgIndex), musicTrack.getMusicImgList().get(audioSts.lastImgIndex + 1));
				} else {
					if (audioSts.lastImgIndex >= musicTrack.getMusicImgList().size()) {
						break;
					}
					showStaffPicture(musicTrack.getMusicImgList().get(audioSts.lastImgIndex), null);
				}
				break;

			case PlayerState.MusicActivityPhotoMsg:
				// ��ʾ����ͼƬ
				audioSts.lastImgIndex ++;
				if (audioSts.lastImgIndex + 1 < musicTrack.getMusicImgList().size()) {
					showStaffPicture(musicTrack.getMusicImgList().get(audioSts.lastImgIndex), musicTrack.getMusicImgList().get(audioSts.lastImgIndex + 1));
				} else {
					if (audioSts.lastImgIndex >= musicTrack.getMusicImgList().size()) {
						break;
					}
					showStaffPicture(musicTrack.getMusicImgList().get(audioSts.lastImgIndex), null);
				}
				break;

			case PlayerState.MusicActivityPlayEnd:
				// ���Ž���
				playerThread = null;
				audioSts.isPlaying = false;
				audioSts.isStop = false;
				buttonPlay.setVisibility(View.VISIBLE);
				buttonPause.setVisibility(View.GONE);

				// ��ʾ����ͼƬ
				audioSts.lastImgIndex = 0;
				audioSts.lastImgFile = musicTrack.getMusicImgList().get(0);
				String imgFile2 = null;
				if (musicTrack.getMusicImgList().size() > 1) {
					imgFile2 = musicTrack.getMusicImgList().get(1);
				}
				showStaffPicture(audioSts.lastImgFile, imgFile2);
				imageViewGreen.setX(15.0F);
				imageViewRed.setX(15.0F);

				// ���������趨Ϊȱʡֵ
				audioSts.noteSpanTimeScale = 1F;
				audioSts.jiepaiMun = audioSts.defaultJiepaiMun;
				textViewJiepai.setText((int) audioSts.jiepaiMun + "��/����");

				// ������
				seekBar.setProgress(0);
				break;

			case 6:
//				if (paramAnonymousMessage.obj != null) {
//					ShowphotoString(paramAnonymousMessage.obj.toString());
//				}
				break;
			case 7:
				if (messagePara.arg1 == 0) {
					imageViewConn.setImageResource(R.drawable.pic_usb1);
				} else {
					imageViewConn.setImageResource(R.drawable.pic_usb2);
				}
				break;

			case PlayerState.MusicActivitySignal :
				// ��������ָʾ��
				GroupNote groupNote = (GroupNote) messagePara.obj;
				ArrayList<MusicNote> refNotesList = groupNote.getRefNoteList();
				if (refNotesList.size() == 1) {
					// ��ͨ����
					MusicNote note = refNotesList.get(0);
					if (note.getNoteType() == NoteType.NOTE_LA) {
						imageViewRed.setX(15.0F + note.getCoordinate().x * PlayerState.YOffset);
						//imageViewRed.setY(y);
					} else {
						imageViewGreen.setX(15.0F + note.getCoordinate().x * PlayerState.YOffset);
						//imageViewGreen.setY(y);
					}
				} else {
					// �������
					for (MusicNote single : refNotesList) {
						if (single.getNoteType() == NoteType.NOTE_LA) {
							imageViewRed.setX(15.0F + single.getCoordinate().x * PlayerState.YOffset);
							//imageViewRed.setY(y);
						} else {
							imageViewGreen.setX(15.0F + single.getCoordinate().x * PlayerState.YOffset);
							//imageViewGreen.setY(y);
						}
					}
				}
				break;

			case 11:
				imageViewTaban.setImageResource(R.drawable.pic_tb2);
				break;
			case 12:
				imageViewTaban.setImageResource(R.drawable.pic_tb1);
				break;
			case 13:

				if (audioSts.isABPlaying && !audioSts.isZYPlaying) {
//					mtrack.Pause();
//					mtrack.mLAnownoteindex = 0;
//					mtrack.mLBnownoteindex = 0;
//					mtrack.mRAnownoteindex = 0;
//					mtrack.mRBnownoteindex = 0;
//					mtrack.Start((MusicActivity) getBaseContext(), StartAindex, StartBindex, false);
//					ButtonStart.setBackgroundResource(2130837564);
//					flg = false;
				}
				break;

			case 14:
			//	StartIndex = messagePara.arg1;
				break;

			default:
				break;
			}
		}
	};

	private final ExecutorService mExecutor = Executors.newSingleThreadExecutor();
	private final SerialInputOutputManager.Listener mListener = new SerialInputOutputManager.Listener() {
		public void onNewData(final byte[] paramAnonymousArrayOfByte) {
			runOnUiThread(new Runnable() {
				public void run() {
					// TODO --updateReceivedData(paramAnonymousArrayOfByte);
				}
			});
		}

		public void onRunError(Exception paramAnonymousException) {
			Log.d(TAG, "Runner stopped.");
		}
	};
	private UsbSerialDriver mSerialDevice;
	private SerialInputOutputManager mSerialIoManager;

	private UsbManager mUsbManager;

	private final static SoundPlayer trackPlayer = new SoundPlayer();

	private class TrackRunnable extends Thread {

		public TrackRunnable() {
			audioSts.isStop = false;
		}

		public void run() {
			ArrayList<GroupNote> noteList = musicTrack.getMusicTrack();
			GroupNote note = null;
			do {
				// ��ʾ����ͼƬ
				handler.sendEmptyMessage(PlayerState.MusicActivityPhotoInitMsg);

				for (audioSts.playingNoteIdx = audioSts.startNodeIdx; audioSts.playingNoteIdx < audioSts.endNodeIdx; audioSts.playingNoteIdx ++) {
					while (!audioSts.isPlaying) {
						// ��ͣ����
					}
					if (audioSts.isStop) {
						// ֹͣ����
						break;
					}
					note = noteList.get(audioSts.playingNoteIdx);

					// ��ʾ����ͼƬ
					// ��������������ͼƬ�뵱ǰ����ͼƬ��һ�£���ˢ��ͼƬ
					if (!audioSts.lastImgFile.equals(note.getRefNoteList().get(0).getImageName())) {
						handler.sendEmptyMessage(PlayerState.MusicActivityPhotoMsg);
					}

					// ��������
					trackPlayer.playSound(note, !audioSts.isLeftPlayable, !audioSts.isRightPlayable);

					// ��ʾ����λ���źŵ�
					handler.obtainMessage(PlayerState.MusicActivitySignal, note).sendToTarget();

					// ��ʾ�������Ž�����
					handler.sendEmptyMessage(PlayerState.MusicActivitySeekBar);

					// ���Ϳ����źŵ�USB
					

					// ��������ʱ��
					try {
						Thread.sleep((long) (note.getNoteSpanTime() / audioSts.noteSpanTimeScale));
					} catch (InterruptedException exp) {
					}
				}
			} while (audioSts.isABPlaying && !audioSts.isStop);

			// ���Ž������������ø�����־λ
			handler.sendEmptyMessageDelayed(PlayerState.MusicActivityPlayEnd, 3000);
		}
	}

	private void initView() {
		upImgLayout = (LinearLayout) findViewById(R.id.imgLayout01);
		downImgLayout = (LinearLayout) findViewById(R.id.imgLayout02);
		
		this.imageViewGreen = (ImageView) findViewById(R.drawable.green);
		this.imageViewRed = (ImageView) findViewById(R.drawable.red);

		this.imageViewConn = (ImageView) findViewById(R.drawable.pic_usb1);
		this.imageViewTaban = (ImageView) findViewById(R.drawable.pic_tb2);
		this.imageViewGreen.setX(15.0F);
		this.imageViewGreen.setY(90.0F);
		this.imageViewRed.setX(15.0F);
		this.imageViewRed.setY(180.0F);
		
		this.buttonVoice = (ImageButton) findViewById(R.drawable.pic_voice_on);

		this.seekBar = (RangeSeekBar) findViewById(R.id.seekBar1);

		this.textViewTitle = (TextView) findViewById(R.string.musicName);
		this.textViewJiepai = (TextView) findViewById(R.id.TextViewJiepai);

		this.buttonLeft = (ImageButton) findViewById(R.drawable.pic_l2);
		this.buttonRight = (ImageButton) findViewById(R.drawable.pic_r2);
		this.buttonABPlay = (ImageButton) findViewById(R.drawable.pic_ab1);
		this.buttonZYPlay = (ImageButton) findViewById(R.drawable.pic_zy1);

		buttonPlay = (Button) findViewById(R.drawable.sty_play);
		buttonPause = (Button) findViewById(R.drawable.sty_pause);

		//this.buttonshiping.getHeight();
	}

	private void onDeviceStateChange() {
		stopIoManager();
		startIoManager();
	}

	private void startIoManager() {
		if (this.mSerialDevice != null) {
			Log.i(this.TAG, "Starting io manager ..");
			this.mSerialIoManager = new SerialInputOutputManager(this.mSerialDevice, this.mListener);
			this.mExecutor.submit(this.mSerialIoManager);
		}
	}

	private void stopIoManager() {
		if (this.mSerialIoManager != null) {
			Log.i(this.TAG, "Stopping io manager ..");
			this.mSerialIoManager.stop();
			this.mSerialIoManager = null;
		}
	}


	public void showStaffPicture(String imgFile1, String imgFile2) {
		// ��ʾ��ǰһҳ����
		audioSts.lastImgFile = imgFile1;
		imgFile1 = AppContext.getMusicPath() + "/" + musicTrack.getTitle() + "/" + imgFile1;

		String s1 = new StringBuilder(imgFile1).append(".bmp").toString();
		upImgLayout.setBackgroundDrawable(Drawable.createFromPath(s1));

		// ��ʾ��һҳ����
		if (imgFile2 == null) {
			// ���һҳ
			downImgLayout.setBackgroundResource(R.drawable.track_youxiu);

		} else {
			imgFile2 = AppContext.getMusicPath() + "/" + musicTrack.getTitle() + "/" + imgFile2;

			String s2 = new StringBuilder(imgFile2).append(".bmp").toString();
			downImgLayout.setBackgroundDrawable(Drawable.createFromPath(s2));
		}
	}


	public void finish() {
		super.finish();
		//this.PlayABFlg = false;
//		if (mtrack != null) {
//			mtrack.Pause();
//			mtrack.Clean();
//		}
	}


	void initSerialDevice() {
		this.mSerialDevice = UsbSerialProber.acquire(this.mUsbManager);
		Log.d(this.TAG, "Resumed, mSerialDevice=" + this.mSerialDevice);
		if (this.mSerialDevice == null) {
			return;
		}
		try {
			this.mSerialDevice.open();
			if (musicTrack != null) {
//				sendjiepai(mtrack.getJiepai());
//				onDeviceStateChange();
				return;
			}
		} catch (IOException localIOException1) {
			Log.e(this.TAG, "Error setting up device: " + localIOException1.getMessage(), localIOException1);
		} finally {
			try {
				this.mSerialDevice.close();
			} catch (IOException localIOException2) {
				 this.mSerialDevice = null;
			}
		}

	}

	@Override
	protected void onCreate(Bundle paramBundle) {
		AppContext.setCurrActivity(this);
		super.onCreate(paramBundle);
		setContentView(R.layout.audioplayer);

		this.mUsbManager = (UsbManager) getSystemService(Context.USB_SERVICE);
    	audioMng = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

		initView();
		musicTrack = AppContext.getMusicTrack();
		if (musicTrack != null) {
			audioSts = new PlayerState();
			audioSts.noteSpanTimeScale = 1F;
			audioSts.defaultJiepaiMun = musicTrack.getJiepaiValue();
			audioSts.jiepaiMun = audioSts.defaultJiepaiMun;
			textViewJiepai.setText((int) audioSts.jiepaiMun + "��/����");
			textViewTitle.setText(musicTrack.getTitle());

			audioSts.isLeftPlayable = true;
			audioSts.isRightPlayable = true;

			audioSts.endNodeIdx = musicTrack.getMusicTrack().size();
			seekBar.setProgressThumbValue(0, audioSts.endNodeIdx);
			seekBar.setOnRangeSeekBarChangeListener(this);
			seekBar.setOnThumbTouchListener(this);

			// ��ʾ����ͼƬ
			audioSts.lastImgIndex = 0;
			audioSts.lastImgFile = musicTrack.getMusicImgList().get(0);
			String imgFile2 = null;
			if (musicTrack.getMusicImgList().size() > 1) {
				imgFile2 = musicTrack.getMusicImgList().get(1);
			}
			showStaffPicture(audioSts.lastImgFile, imgFile2);

	    	// ��ȡ�ֻ���ǰ����ֵ
	    	int volume = audioMng.getStreamVolume(AudioManager.STREAM_MUSIC);
	    	int maxVolume = audioMng.getStreamMaxVolume(AudioManager.STREAM_MUSIC);

	    	audioSts.currVolume = (float) volume / (float) maxVolume;

			// ��ʼ��USB�豸
			initSerialDevice();
		}

		//this.OnclickAble = true;
	}

	@Override
	public boolean onKeyDown (int keyCode, KeyEvent event) {
	    if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            // ������С/��������
        	// ��ȡ�ֻ���ǰ����ֵ
        	int volume = audioMng.getStreamVolume(AudioManager.STREAM_MUSIC);
        	int maxVolume = audioMng.getStreamMaxVolume(AudioManager.STREAM_MUSIC);

        	if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
        		volume --;
        	} else {
        		volume ++;
        	}
        	audioMng.setStreamVolume(AudioManager.STREAM_MUSIC, volume, 0); 

        	audioSts.currVolume = (float) volume / (float) maxVolume;
        	trackPlayer.setSoundVolume(audioSts.currVolume, audioSts.currVolume);
        	return true;

	    } else {
		    return super.onKeyDown (keyCode, event);
	    }
	}

	@Override
	protected void onPause() {
		super.onPause();
		stopIoManager();
		if (this.mSerialDevice == null) {
			return;
		}
		try {
			this.mSerialDevice.close();
		} catch (IOException localIOException) {
			this.mSerialDevice = null;
		}
	}

	@Override
	protected void onResume() {
		super.onResume();
		if (this.Restart) {
			initSerialDevice();
			return;
		}
	}

	@Override
	protected void onStop() {
		super.onStop();
		System.out.println("--------onStop----------------");
		//this.PlayABFlg = false;
		this.buttonABPlay.setBackgroundResource(2130837524);
//		if (mtrack != null) {
//			System.out.println("--------onStop--1--------------");
//			mtrack.Pause();
//			mtrack.Clean();
//		}
	}


	void sendjiepai(int paramInt) {
		String str = "ST+JP=" + 60000 / paramInt + "M+OV" + "\n";
		System.out.println("abc" + paramInt);
		try {
			this.mSerialDevice.write(str.getBytes(), 5);
			this.imageViewConn.setImageResource(2130837568);
			return;
		} catch (Exception localException) {
			localException.printStackTrace();
			this.imageViewConn.setImageResource(2130837567);
		}
	}

	private Thread playerThread = null;

	/**
	 * ���水ť�����¼�����
	 *
	 * @param v ���水ť����
	 */
	public void onClick(View v) {
		doPerformClick(v.getId());
	}

	private void doPerformClick(int viewId) {
		switch (viewId) {
		case R.drawable.sty_play :
			// ����
			if (playerThread == null) {
				// ��������(��һ��)
				if (trackPlayer.canPlay()) {
					buttonPlay.setVisibility(View.GONE);
					buttonPause.setVisibility(View.VISIBLE);

		        	// ��ȡ�ֻ���ǰ����ֵ
		        	int volume = audioMng.getStreamVolume(AudioManager.STREAM_MUSIC);
		        	int maxVolume = audioMng.getStreamMaxVolume(AudioManager.STREAM_MUSIC);

		        	audioSts.currVolume = (float) volume / (float) maxVolume;
		        	trackPlayer.setSoundVolume(audioSts.currVolume, audioSts.currVolume);

		        	audioSts.isPlaying = true;
					playerThread = new TrackRunnable();
					playerThread.start();
				} else {
					MsgDialog msg = new MsgDialog();
					msg.showMessage("���ڼ����У����Ե�...");
				}
			} else {
				// �������ͣ״̬
				buttonPlay.setVisibility(View.GONE);
				buttonPause.setVisibility(View.VISIBLE);

				if (audioSts.isABPlaying) {
					// �����ѭ������״̬
					if (audioSts.startNodeIdx == audioSts.playingNoteIdx) {
						// �Ƚ�������
						audioSts.isStop = true;
						audioSts.isPlaying = true;
						try {
							Thread.sleep(100);
						} catch (InterruptedException exp) {
						}
						// ���¿�ʼ����
						playerThread = new TrackRunnable();
						playerThread.start();
					} else {
						audioSts.isPlaying = true;
					}

				} else {
					// �������ͨ����
					// �Ƚ�������
					audioSts.isStop = true;
					audioSts.isPlaying = true;
					try {
						Thread.sleep(100);
					} catch (InterruptedException exp) {
					}
					// ���¿�ʼ����
					audioSts.startNodeIdx = audioSts.playingNoteIdx;
					audioSts.endNodeIdx = musicTrack.getMusicTrack().size();
					playerThread = new TrackRunnable();
					playerThread.start();
				}
			}
			break;

		case R.drawable.sty_pause :
			// ��ͣ
			// ��ͣ����
			audioSts.isPlaying = false;
			buttonPlay.setVisibility(View.VISIBLE);
			buttonPause.setVisibility(View.GONE);
			break;

		case R.drawable.sty_play_last :
			// ��������һ����
			audioSts.playingNoteIdx --;
			
			break;
			
		case R.drawable.sty_play_next :
			// ǰ������һ����
			audioSts.playingNoteIdx ++;
			
			break;

		case R.drawable.sty_btn_sub :
			// ����ÿ����(��Ƶ����)�ٶ� - ����
			if (audioSts.jiepaiMun <= audioSts.defaultJiepaiMun / 2) {
				break;
			}
			audioSts.jiepaiMun --;
			audioSts.noteSpanTimeScale = (float) audioSts.jiepaiMun / (float) audioSts.defaultJiepaiMun;

			this.textViewJiepai.setText((int) audioSts.jiepaiMun + "��/����");
			break;

		case R.drawable.sty_btn_add :
			// ����ÿ����(��Ƶ����)�ٶ� - ����
			if (audioSts.jiepaiMun >= audioSts.defaultJiepaiMun * 2) {
				break;
			}
			audioSts.jiepaiMun ++;
			audioSts.noteSpanTimeScale = (float) audioSts.jiepaiMun / (float) audioSts.defaultJiepaiMun;

			this.textViewJiepai.setText((int) audioSts.jiepaiMun + "��/����");
			break;

		case R.drawable.sty_mbtn_video :
			// ���Ÿ���Ŀ����Ƶ
			audioSts.isStop = true;
			gotoOtherActivity(VideoPlayerActivity.class);
			break;

		case R.drawable.sty_mbtn_catalog :
			// �ص���Ŀѡ����
			audioSts.isStop = true;
			gotoOtherActivity(MusicSelectActivity.class);
			break;

		case R.drawable.sty_mbtn_taobao :
			// ת���Ա���ҳ
			// ��ֹͣ����
			audioSts.isStop = true;
			// ת���Ա���ҳ
			gotoShopWebpage();
			break;

		case R.drawable.pic_l2 :
			// �������ֵ������
			if (audioSts.isLeftPlayable) {
				buttonLeft.setBackgroundResource(R.drawable.pic_l1);
				audioSts.isLeftPlayable = false;
			} else {
				buttonLeft.setBackgroundResource(R.drawable.pic_l2);
				audioSts.isLeftPlayable = true;
			}
			return;

		case R.drawable.pic_r2 :
			// �������ֵ������
			if (audioSts.isRightPlayable) {
				buttonRight.setBackgroundResource(R.drawable.pic_r1);
				audioSts.isRightPlayable = false;
			} else {
				buttonRight.setBackgroundResource(R.drawable.pic_r2);
				audioSts.isRightPlayable = true;
			}
			return;

		case R.drawable.pic_ab1 :
			// ABѭ������
			// ����ͣ����
			if (audioSts.isPlaying) {
				audioSts.isPlaying = false;
				buttonPlay.setVisibility(View.VISIBLE);
				buttonPause.setVisibility(View.GONE);
			}

			if (audioSts.isABPlaying) {
				// ȡ��ABѭ������
				audioSts.isABPlaying = false;
				buttonABPlay.setBackgroundResource(R.drawable.pic_ab1);
			} else {
				// �趨ΪABѭ������
				audioSts.isABPlaying = true;
				buttonABPlay.setBackgroundResource(R.drawable.pic_ab2);
			}

			audioSts.startNodeIdx =audioSts. playingNoteIdx;
			audioSts.endNodeIdx = musicTrack.getMusicTrack().size();
			seekBar.setProgressThumbValue(audioSts.startNodeIdx, audioSts.endNodeIdx);
			seekBar.setSecondThumb(audioSts.isABPlaying);
			return;

		case R.drawable.pic_zy1 :
			// ������ڲ���
			if (audioSts.isZYPlaying) {
				buttonZYPlay.setBackgroundResource(R.drawable.pic_zy1);
				audioSts.isZYPlaying = false;
			} else {
				buttonZYPlay.setBackgroundResource(R.drawable.pic_zy2);
				audioSts.isZYPlaying = true;
			}
			return;

		case R.drawable.pic_voice_on :
			// �������� - ����/����
			if (audioSts.isMute) {
				// ����Ѿ��Ǿ���״̬��������
				audioSts.isMute = false;
				buttonVoice.setBackgroundResource(R.drawable.pic_voice_on);
				if (audioSts.currVolume == 0) {
					trackPlayer.setSoundVolume(0.5F, 0.5F);
				} else {
					trackPlayer.setSoundVolume(audioSts.currVolume, audioSts.currVolume);
				}
			} else {
				// �ر�����
				audioSts.isMute = true;
				buttonVoice.setBackgroundResource(R.drawable.pic_voice_mute);

	        	trackPlayer.setSoundVolume(0, 0);
			}
			break;

		default :
			break;
		}
	}

}
