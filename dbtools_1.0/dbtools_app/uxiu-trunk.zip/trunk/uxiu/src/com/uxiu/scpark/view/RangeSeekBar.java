package com.uxiu.scpark.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

import com.uxiu.activity.v2.R;

/**
 * Widget that lets users select a minimum and maximum value on a given numerical range.<br />
 * The range value types can be one of Long, Double, Integer, Float, Short, Byte or BigDecimal.<br />
 * <br />
 * Improved {@link MotionEvent} handling for smoother use, anti-aliased painting for improved aesthetics.
 *
 * webpage: https://code.google.com/p/range-seek-bar/
 *
 * @see android.widget.SeekBar
 *
 * @author Stephan Tittel (stephan.tittel@kom.tu-darmstadt.de)
 * @author Peter Sinnott (psinnott@gmail.com)
 * @author Thomas Barrasso (tbarrasso@sevenplusandroid.org)
 */
public class RangeSeekBar extends View {

	private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
	private static Drawable thumbDrawable = null;

	private float thumbWidth = 0F;
	private float thumbHalfWidth = 0F;
	private float lineHeight = 0F;

	// ������ָʾ��Χ(���ڻ�ʱ�趨)
	// ��Сֵ�����ֵ progress bar base coordinate
	private int progressMinValue = 0;
	private int progressMaxValue = 0;
	private int progressValue = 0;

	// �϶�������ָʾ��Χ
	// ���ڳ��ڻ�ʱ�趨����������ʱ�ı��ֵ
	// ��Сֵ�����ֵ screen base coordinate
	private float screenMinValue = 0F;
	private float screenMaxValue = 0F;

	private Thumb pressedThumb = null;

	private OnRangeSeekBarChangeListener listener = null;
	private OnThumbTouchListener thumbListener = null;

	// ��Χָ����������ʾ��
	// ���趨Ϊtrue,���ʾ�������϶�������
	private boolean hasSecondThumb = false;

	private float mDownMotionX = 0F;

	private int mScaledTouchSlop;
	private boolean mIsDragging;


	/**
	 * @attr ref com.uxiu.act.R.styleable.RangeSeekBar_progressBarColor
	 */
	private int progressBarColor = 0;
	/**
	 * @attr ref com.uxiu.act.R.styleable.RangeSeekBar_primaryProgressColor
	 */
	private int primaryProgressColor = 0;
	/**
	 * @attr ref com.uxiu.act.R.styleable.RangeSeekBar_secondaryProgressColor
	 */
	private int secondaryProgressColor = 0;

	/**
     * Simple constructor to use when creating a view from code.
     *
     * @param context The Context the view is running in, through which it can
     *        access the current theme, resources, etc.
     */
    public RangeSeekBar(Context context) {
    	 this(context, null);
    }

    /**
     * Constructor that is called when inflating a view from XML. This is called
     * when a view is being constructed from an XML file, supplying attributes
     * that were specified in the XML file. This version uses a default style of
     * 0, so the only attribute values applied are those in the Context's Theme
     * and the given AttributeSet.
     *
     * <p>
     * The method onFinishInflate() will be called after all children have been
     * added.
     *
     * @param context The Context the view is running in, through which it can
     *        access the current theme, resources, etc.
     * @param attrs The attributes of the XML tag that is inflating the view.
     * @see #View(Context, AttributeSet, int)
     */
    public RangeSeekBar(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    /**
     * Perform inflation from XML and apply a class-specific base style. This
     * constructor of View allows subclasses to use their own base style when
     * they are inflating. For example, a Button class's constructor would call
     * this version of the super class constructor and supply
     * <code>R.attr.buttonStyle</code> for <var>defStyle</var>; this allows
     * the theme's button style to modify all of the base view attributes (in
     * particular its background) as well as the Button class's attributes.
     *
     * @param context The Context the view is running in, through which it can
     *        access the current theme, resources, etc.
     * @param attrs The attributes of the XML tag that is inflating the view.
     * @param defStyle The default style to apply to this view. If 0, no style
     *        will be applied (beyond what is included in the theme). This may
     *        either be an attribute resource, whose value will be retrieved
     *        from the current theme, or an explicit style resource.
     * @see #View(Context, AttributeSet)
     */
    public RangeSeekBar(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        if (isInEditMode()) {
        	return;
        }
		mScaledTouchSlop = ViewConfiguration.get(getContext()).getScaledTouchSlop();

		TypedArray m_TypedArray = context.obtainStyledAttributes(attrs, R.styleable.RangeSeekBar);

		thumbDrawable = m_TypedArray.getDrawable(R.styleable.RangeSeekBar_thumbDrawable);
		//thumbImage = BitmapFactory.decodeResource(getResources(), thumbDrawable);

		thumbWidth = thumbDrawable.getIntrinsicWidth();
		thumbHalfWidth = 0.5F * thumbWidth;
		mDownMotionX = thumbHalfWidth;
		lineHeight = 0.15F * thumbDrawable.getIntrinsicHeight();

		progressBarColor = m_TypedArray.getColor(R.styleable.RangeSeekBar_progressBarColor, Color.GRAY);
		// Default color #FF33B5E5. This is also known as "Ice Cream Sandwich" blue.
		primaryProgressColor = m_TypedArray.getColor(R.styleable.RangeSeekBar_primaryProgressColor, 0xFF33B5E5);
		secondaryProgressColor = m_TypedArray.getColor(R.styleable.RangeSeekBar_secondaryProgressColor, Color.YELLOW);

		// make RangeSeekBar focusable. This solves focus handling issues in case EditText widgets are being used along with the RangeSeekBar within ScollViews.
		setFocusable(true);
		setFocusableInTouchMode(true);
    }

	private float coordScale = 0F;

	/**
	 * Set the minimum/maximum value of the selectable range.
	 *
	 * @param minValue The minimum value of the selectable range.
	 * @param maxValue The maximum value of the selectable range.
	 */
	public void setProgressThumbValue(int minValue, int maxValue) {
		this.progressMinValue = minValue;
		this.progressMaxValue = maxValue;
		screenMinValue = normalizedToScreen(minValue);
		screenMaxValue = normalizedToScreen(maxValue);
	}

	/**
	 * 
	 *
	 * @param haveFlg
	 */
	public void setSecondThumb(boolean haveFlg) {
		if (this.hasSecondThumb != haveFlg) {
			this.hasSecondThumb = haveFlg;
			invalidate();
		}
	}

    /**
     * <p>Increase the progress bar's progress by the specified amount.</p>
     *
     * @param diff the amount by which the progress must be increased
     */
    public void setProgress(int diff) {
    	progressValue = diff;
    	invalidate();
    }

	/**
	 * Registers given listener callback to notify about changed selected values.
	 *
	 * @param listener The listener to notify about changed selected values.
	 */
	public void setOnRangeSeekBarChangeListener(OnRangeSeekBarChangeListener listener) {
		this.listener = listener;
	}


	public void setOnThumbTouchListener(OnThumbTouchListener listener) {
		thumbListener = listener;
	}

	/**
	 * Handles thumb selection and movement. Notifies listener callback on certain events.
	 */
	@Override
	public boolean onTouchEvent(MotionEvent event) {

		float x = 0F;

		if (hasSecondThumb) {
			switch (event.getAction()) {
			case MotionEvent.ACTION_DOWN :
				x = event.getX();
				pressedThumb = evalPressedThumb(x);
				if (pressedThumb == null) {
					return super.onTouchEvent(event);
				}
				mIsDragging = true;
				if (thumbListener != null) {
					thumbListener.onThumbTouch(pressedThumb);
				}
				break;

			case MotionEvent.ACTION_MOVE :
				// Only handle thumb presses.
				if (pressedThumb == null) {
					return super.onTouchEvent(event);
				}
				x = event.getX();
				if (Thumb.MIN.equals(pressedThumb)) {
					// Scroll to follow the motion event
					if ((Math.abs(x - screenMinValue) > mScaledTouchSlop) && (screenMaxValue - x) > (thumbWidth + mScaledTouchSlop)) {
						// ����������϶�
						// ������ڲ��ţ������������
						progressValue = 0;

						invalidate();
						this.progressMinValue = (int) screenToNormalized(x);
						screenMinValue = x;
					}
				} else {
					// Scroll to follow the motion event
					if ((Math.abs(x - screenMaxValue) > mScaledTouchSlop) && (x - screenMinValue) > (thumbWidth + mScaledTouchSlop)) {
						// �ҽ��������϶�
						// ������ڲ��ţ������������
						progressValue = 0;

						invalidate();
						this.progressMaxValue = (int) screenToNormalized(x);
						screenMaxValue = x;
					}
				}
				if (listener != null) {
					listener.onRangeSeekBarValuesChanged(this, progressMinValue, progressMaxValue);
				}
				break;

			default :
				pressedThumb = null;
				mIsDragging = false;
				if (thumbDrawable != null) {
					invalidate();
				}
				break;
			}

		} else {
			switch (event.getAction()) {
			case MotionEvent.ACTION_DOWN :
				// Remember where the motion event started
				x = event.getX();
				pressedThumb = evalPressedThumb(x);

				// Only handle thumb presses.
				if (pressedThumb == null) {
					return super.onTouchEvent(event);
				}
				mIsDragging = false;
				if (thumbListener != null) {
					thumbListener.onThumbTouch(pressedThumb);
				}
				break;

			case MotionEvent.ACTION_MOVE :
				if (pressedThumb == null) {
					return super.onTouchEvent(event);
				}
				x = event.getX();
				mIsDragging = true;

				if (Math.abs(x - mDownMotionX) > mScaledTouchSlop) {
					invalidate();
					mDownMotionX = x;
				}

				if (listener != null) {
					progressValue = (int) screenToNormalized(x);
					listener.onSeekBarValuesChanged(this, progressValue);
				}
				break;

			default :
				pressedThumb = null;
				if (mIsDragging) {
					mIsDragging = false;
					if (thumbDrawable != null) {
						invalidate();
					}
				} else {
					x = event.getX();

					if (Math.abs(x - mDownMotionX) > mScaledTouchSlop) {
						invalidate();
						mDownMotionX = x;
					}

					if (listener != null) {
						progressValue = (int) screenToNormalized(x);
						listener.onSeekBarValuesChanged(this, progressValue);
					}
				}
				break;
			}
		}
		return true;
	}

	/**
	 * Ensures correct size of the widget.
	 */
	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
       	super.onMeasure(widthMeasureSpec, heightMeasureSpec);

        if (!isInEditMode()) {
    		coordScale = (float) (getMeasuredWidth() - thumbWidth) / (progressMaxValue - progressMinValue);
        }
	}

	private final RectF rectRef = new RectF();

	/**
	 * Draws the widget on the given canvas.
	 */
	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);

		if (this.hasSecondThumb) {
			// draw seek bar background line
			rectRef.set(thumbHalfWidth, 0.5f * getHeight(), getWidth() - thumbHalfWidth, 0.5f * getHeight() + lineHeight);
			paint.setStyle(Style.FILL);
			paint.setColor(progressBarColor);
			paint.setAntiAlias(true);
			canvas.drawRect(rectRef, paint);

			// draw seek bar active range line
			rectRef.left = normalizedToScreen(progressMinValue);
			rectRef.right = normalizedToScreen(progressMaxValue);
			paint.setColor(primaryProgressColor);
			canvas.drawRect(rectRef, paint);

			if (progressValue > 0) {
				// draw second seek bar active range line
				rectRef.left = normalizedToScreen(progressMinValue);
				rectRef.right = normalizedToScreen(progressValue);
				paint.setColor(secondaryProgressColor);
				canvas.drawRect(rectRef, paint);
			}

			// draw minimum thumb
			drawThumb(normalizedToScreen(progressMinValue), Thumb.MIN.equals(pressedThumb), canvas);

			// draw maximum thumb
			drawThumb(normalizedToScreen(progressMaxValue), Thumb.MAX.equals(pressedThumb), canvas);
		} else {
			// draw seek bar background line
			rectRef.set(thumbHalfWidth, 0.5f * getHeight(), getWidth() - thumbHalfWidth, 0.5f * getHeight() + lineHeight);
			paint.setStyle(Style.FILL);
			paint.setColor(progressBarColor);
			paint.setAntiAlias(true);
			canvas.drawRect(rectRef, paint);

			// draw seek bar active range line
			//rectDef.left = normalizedToScreen(normalizedMinValue);
			rectRef.right = normalizedToScreen(progressValue);

			// orange color
			paint.setColor(primaryProgressColor);
			canvas.drawRect(rectRef, paint);

			// draw minimum thumb
			drawThumb(rectRef.right, true, canvas);
		}
	}

	/**
	 * Draws the "normal" resp. "pressed" thumb image on specified x-coordinate.
	 *
	 * @param screenCoord The x-coordinate in screen space where to draw the image.
	 * @param pressed     Is the thumb currently in "pressed" state?
	 * @param canvas      The canvas to draw upon.
	 */
	private void drawThumb(float screenCoord, boolean pressed, Canvas canvas) {
        if (thumbDrawable != null) {
			if (pressed && mIsDragging) {
				thumbDrawable.setState(new int[] { android.R.attr.state_pressed });
			} else {
				thumbDrawable.setState(getDrawableState());
			}

        	thumbDrawable.setBounds((int) (screenCoord - thumbHalfWidth), 0, (int) (screenCoord + thumbHalfWidth), (int) thumbDrawable.getIntrinsicHeight()-8);
            thumbDrawable.draw(canvas);
        }
	}

	/**
	 * Decides which (if any) thumb is touched by the given x-coordinate.
	 *
	 * @param touchX The x-coordinate of a touch event in screen space.
	 *
	 * @return The pressed thumb or null if none has been touched.
	 */
	private Thumb evalPressedThumb(float touchX) {
		Thumb result = null;
		if (hasSecondThumb) {
			boolean minThumbPressed = isInThumbRange(touchX, progressMinValue);
			boolean maxThumbPressed = isInThumbRange(touchX, progressMaxValue);
			if (minThumbPressed && maxThumbPressed) {
				// if both thumbs are pressed (they lie on top of each other), choose the one with more room to drag. this avoids "stalling" the thumbs in a corner, not being able to drag them apart anymore.
				result = (touchX / getWidth() > 0.5f) ? Thumb.MIN : Thumb.MAX;
			} else if (minThumbPressed) {
				result = Thumb.MIN;
			} else if (maxThumbPressed) {
				result = Thumb.MAX;
			}
		} else {
			result = Thumb.MIN;
		}
		return result;
	}

	/**
	 * Decides if given x-coordinate in screen space needs to be interpreted as "within" the normalized thumb x-coordinate.
	 *
	 * @param touchX               The x-coordinate in screen space to check.
	 * @param normalizedThumbValue The normalized x-coordinate of the thumb to check.
	 *
	 * @return boolean true if x-coordinate is in thumb range, false otherwise.
	 */
	private boolean isInThumbRange(float touchX, int normalizedThumbValue) {
		return Math.abs(touchX - normalizedToScreen(normalizedThumbValue)) <= thumbHalfWidth;
	}

	/**
	 * Converts a normalized value into screen space.
	 *
	 * @param normalizedCoord The normalized value to convert.
	 *
	 * @return float The converted value in screen space.
	 */
	private float normalizedToScreen(int normalizedCoord) {
		return (float) (thumbHalfWidth + normalizedCoord * coordScale);
	}

	/**
	 * Converts screen space x-coordinates into normalized values.
	 *
	 * @param screenCoord The x-coordinate in screen space to convert.
	 *
	 * @return float The normalized value.
	 */
	private float screenToNormalized(float screenCoord) {
		return (screenCoord - thumbHalfWidth) / coordScale;
	}

	/**
	 * Callback listener interface to notify about changed range values.
	 *
	 * @author Stephan Tittel (stephan.tittel@kom.tu-darmstadt.de)
	 */
	public interface OnRangeSeekBarChangeListener {
		void onRangeSeekBarValuesChanged(RangeSeekBar bar, int minValue, int maxValue);
		void onSeekBarValuesChanged(RangeSeekBar bar, int progressValue);
	}

	public interface OnThumbTouchListener {
		void onThumbTouch(Thumb v);
	}

	/**
	 * Thumb constants (min and max).
	 */
	public static enum Thumb {
		MIN, MAX
	};

}