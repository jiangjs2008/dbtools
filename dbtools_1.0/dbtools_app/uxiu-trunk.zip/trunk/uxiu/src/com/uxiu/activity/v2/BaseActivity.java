/**
 * Copyright c NTT DATA CORPORATION 2012 All Rights Reserved.
 * ShougaiActivity.java
 */
package com.uxiu.activity.v2;

import org.apache.log4j.Logger;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;

import com.uxiu.error.UxiuExceptionHandler;



public abstract class BaseActivity extends Activity {

	protected static Logger logger = new Logger(BaseActivity.class);

	static {
		AppContext.setExceptionHandler(new UxiuExceptionHandler());
		Thread.setDefaultUncaughtExceptionHandler(AppContext.getExceptionHandler());
	}

	protected void gotoOtherActivity(Class<?> paramClass) {
		Intent localIntent = new Intent(this, paramClass);
		startActivity(localIntent);
		finish();
	}

	protected void gotoShopWebpage() {
		Intent localIntent = new Intent();
		localIntent.setAction("android.intent.action.VIEW");
		localIntent.setData(Uri.parse("http://ushowpiano.taobao.com/"));
		startActivity(localIntent);
	}
}
