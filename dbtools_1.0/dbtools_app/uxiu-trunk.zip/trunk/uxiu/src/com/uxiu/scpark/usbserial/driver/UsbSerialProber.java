package com.uxiu.scpark.usbserial.driver;

import java.util.Iterator;

import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;

public enum UsbSerialProber
{
	FTDI_SERIAL {
		@Override
		public UsbSerialDriver getDevice(UsbManager paramUsbManager, UsbDevice paramUsbDevice) {
			// TODO Auto-generated method stub
			return null;
		}
	};
  static
  {
    UsbSerialProber[] arrayOfUsbSerialProber = new UsbSerialProber[1];
    arrayOfUsbSerialProber[0] = FTDI_SERIAL;
  }

  public static UsbSerialDriver acquire(UsbManager paramUsbManager)
  {
    Iterator localIterator = paramUsbManager.getDeviceList().values().iterator();
    UsbSerialDriver localUsbSerialDriver;
    do
    {
      if (!localIterator.hasNext())
        return null;
      localUsbSerialDriver = acquire(paramUsbManager, (UsbDevice)localIterator.next());
    }
    while (localUsbSerialDriver == null);
    return localUsbSerialDriver;
  }

  public static UsbSerialDriver acquire(UsbManager paramUsbManager, UsbDevice paramUsbDevice)
  {
    UsbSerialProber[] arrayOfUsbSerialProber = values();
    int i = arrayOfUsbSerialProber.length;
    for (int j = 0; ; j++)
    {
      UsbSerialDriver localUsbSerialDriver;
      if (j >= i)
        localUsbSerialDriver = null;
      do
      {
        return  arrayOfUsbSerialProber[j].getDevice(paramUsbManager, paramUsbDevice);
      }
      while (localUsbSerialDriver != null);
    }
  }

  public abstract UsbSerialDriver getDevice(UsbManager paramUsbManager, UsbDevice paramUsbDevice);
}

/* Location:           C:\Downloads\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.uxiu.scpark.usbserial.driver.UsbSerialProber
 * JD-Core Version:    0.6.2
 */